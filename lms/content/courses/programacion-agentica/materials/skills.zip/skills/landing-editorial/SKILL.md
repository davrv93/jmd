---
name: landing-editorial
description: Sistema para crear landings y páginas de marketing con estética editorial tipo Apple para cualquier negocio — papel blanco, tipografía grande y pesada, un solo color de marca, animaciones con una sola curva, secciones fijadas que el scroll va armando y un fondo animado configurable (figura × movimiento × formación). Trae menús para pedir por rubro, por intensidad, por código de animación y por tipo de figura o movimiento, más una plantilla HTML funcional sin dependencias. Úsala SIEMPRE que pidan una landing, una página de producto o de servicio, una sección de marketing, "algo tipo Apple", "con animaciones bonitas", "con scroll como Apple", o que mejoren el diseño, la legibilidad o el responsive de una página de este tipo.
---

# Landing editorial

Una revista de papel blanco que se mueve como un keynote de Apple. Mucho aire, paleta mínima,
tipografía grande y pesada, y todos los movimientos con la misma curva. Sirve igual para una
consultora, una cafetería, una clínica o una inmobiliaria: lo que cambia es el color, las figuras
del fondo, la intensidad y el texto.

La página resultante es **un solo `index.html`**, sin build, sin framework y sin librerías de
animación. CSS más unas 400 líneas de JavaScript vanilla.

## Cómo se pide (menú)

Quien pide puede elegir en cinco ejes. Lo que no diga se toma de la receta de su rubro.

| Eje | Opciones | Dónde está |
|---|---|---|
| **1. Rubro** | software, cafetería, restaurante, clínica, farmacia, belleza, inmobiliaria, educación, finanzas, logística, eventos, moda, legal, fitness… | [09-recetas-por-negocio.md](references/09-recetas-por-negocio.md) |
| **2. Intensidad** | `sobria` · `media` · `espectáculo` | tabla de abajo |
| **3. Animaciones** | por código, de `A01` a `A17` | [02-animaciones.md](references/02-animaciones.md) |
| **4. Fondo animado** | figura × movimiento × formación (11 × 6 × 4) | [05-fondo-figuras.md](references/05-fondo-figuras.md) |
| **5. Secciones** | por código, de `S0` a `S10` | anatomía de abajo |

Ejemplos de pedidos válidos:

- «Landing para mi cafetería, intensidad media, con granos que caen y se ordenan en espiral.»
- «Clínica dental, sobria, color verde azulado, sin intro, con cruces que suben despacio.»
- «Agencia de software, espectáculo completo, con vitrina de producto (A16) y módulos en rejilla.»
- «Mi landing ya existe: añádele A05, A06 y A08 y un fondo de burbujas que repelan el cursor.»

**Si el pedido es vago**, no preguntes por cada eje: aplica la receta del rubro y pregunta solo
lo que no se puede inventar — nombre de la marca, color si lo tiene, cifras reales, contacto
(WhatsApp, correo o formulario) y servicios. Muestra la receta elegida en una línea para que la
puedan corregir.

## Intensidad

| Nivel | Animaciones | Para quién |
|---|---|---|
| **Sobria** | A03, A05, A08, A09, A11, A12 · sin fondo animado, o fondo `quieto` muy tenue | Legal, finanzas, salud, gobierno: confianza antes que espectáculo |
| **Media** | Sobria + A02, A04, A06, A07, A10, A13 · fondo animado sin formación, o una sola | La mayoría de negocios. Opción por defecto |
| **Espectáculo** | Media + A01, A14, A15, A16, A17 con formación en secciones fijadas | Tecnología, creativos, lanzamientos, marcas que quieren impresionar |

## Anatomía (secciones)

| Código | Sección | Para qué sirve | Animación que la define |
|---|---|---|---|
| S0 | Intro de arranque | Presentar la marca como un equipo que enciende | A01 |
| S1 | Navegación de vidrio | Siempre a mano, sin tapar | A11 |
| S2 | Portada centrada | La promesa en 3–5 palabras | A02, A03, A04, A07 |
| S3 | Del problema a la solución (fijada) | El dolor del cliente, frase a frase | A15 + A17 con formación |
| S4 | Vitrina de producto (fijada) | Enseñar el producto sin capturas | A16 |
| S5 | Servicios en bento | Qué se ofrece | A05 + A13 |
| S6 | Cifras | Prueba social | A08 |
| S7 | Método en pasos | Cómo se trabaja | A09 |
| S8 | Persona o equipo | Confianza humana | A10 |
| S9 | Promesas | Objeciones resueltas | A09 |
| S10 | Cierre y contacto | Una sola acción | A06 + formulario |

Mínimo viable: S1, S2, S5, S10. Quita secciones antes que inventar otras nuevas. Cada encabezado
lleva un antetítulo numerado (`01 — Servicios`) y un titular `.h2`.

## Reglas que no se negocian

1. **Una sola curva para todo:** `--suave: cubic-bezier(.16, 1, .3, 1)` (expo-out). Arranca rápido
   y se posa lento. Es lo que da la sensación «Apple».
2. **Paleta corta:** blanco, tinta casi negra, dos grises, un color de línea y **un** color de marca
   con su degradado. Colores extra solo dentro de maquetas de producto.
3. **Titulares en Inter 600–700, `letter-spacing: -.045em`, `line-height` de .9 a 1.** Una serif fina
   sobre blanco se pierde. Si la marca exige serif, que sea de peso medio o más.
4. **Texto de lectura en gris (`#6b6b70`), de 1 a 1,25 rem, con `max-width` de 30 a 36 rem.**
5. **Todo tamaño se escribe con `clamp()`** y todo margen lateral con `var(--margen)`.
6. **Se animan solo `transform`, `opacity`, `filter` y `clip-path`.**
7. **Todo lo que depende del scroll se calcula en un único `requestAnimationFrame`.**
8. **`prefers-reduced-motion` deja la página entera legible:** sin intro, sin secciones fijadas,
   todo visible. Sin JavaScript, también.
9. **Sin librerías** (GSAP, AOS, Lenis, Framer…) salvo pedido explícito.
10. **Lenguaje llano y datos reales.** Ni cifras, ni testimonios, ni teléfonos inventados.

## Cómo trabajar

1. Lee la receta del rubro en [09](references/09-recetas-por-negocio.md) y ajústala con lo que pidieron.
2. Copia [plantilla/index.html](plantilla/index.html). Cambia `--azul`, `--azul-2` y `--azul-claro`
   en `:root`: degradados, botones, foco y fondo animado toman el color de ahí.
3. Configura el fondo en el objeto `FONDO` al principio del `<script>` ([05](references/05-fondo-figuras.md)).
4. Quita las secciones que no van y añade las animaciones elegidas de [02](references/02-animaciones.md).
   Para S3 y S4 lee [03](references/03-scroll-guiado.md); para componentes, [04](references/04-componentes.md).
5. Escribe el texto con [07](references/07-redaccion.md).
6. Revisa en 393 px, 768 px y 1440 px con [06](references/06-responsive-accesibilidad.md).
7. Pasa [08](references/08-checklist.md) antes de entregar.

## Mapa de referencias

- [01-tokens.md](references/01-tokens.md) — color, tipografía, escala `clamp`, radios, sombras, vidrio.
- [02-animaciones.md](references/02-animaciones.md) — catálogo A01–A17 con su CSS y JS.
- [03-scroll-guiado.md](references/03-scroll-guiado.md) — motor de scroll, secciones fijadas, vitrina con cámara.
- [04-componentes.md](references/04-componentes.md) — nav, botones, bento y escenas, cifras, pasos, retrato, formulario.
- [05-fondo-figuras.md](references/05-fondo-figuras.md) — fondo animado: figuras, movimientos, formaciones y cómo crear nuevos.
- [06-responsive-accesibilidad.md](references/06-responsive-accesibilidad.md) — cortes, móvil, movimiento reducido, rendimiento.
- [07-redaccion.md](references/07-redaccion.md) — voz, estructura de cada texto, legibilidad.
- [08-checklist.md](references/08-checklist.md) — revisión antes de publicar.
- [09-recetas-por-negocio.md](references/09-recetas-por-negocio.md) — combinaciones listas por rubro.
- [plantilla/index.html](plantilla/index.html) — página base funcional con todo lo anterior.

## Errores que ya se cometieron

- **Serif Didone fina en titulares sobre blanco:** ilegible a distancia. Se cambió por Inter 600.
- **Quitar el fondo animado al iterar.** Si una página ya tiene fondo y al cliente le gusta, se
  conserva al añadir secciones.
- **Clases construidas con plantilla de texto** (`'tj--' + tipo`): una purga de CSS se las lleva sin
  avisar. Escribe las clases completas.
- **`background-clip: text` en el padre de palabras `inline-block` transformadas:** el degradado no
  llega. Ponlo en cada palabra (A02).
- **Sección fijada sin plan B:** con movimiento reducido, un bloque de `420vh` vacío es un muro en
  blanco. Devuelve siempre `height: auto` y `position: static`.
