# 09 · Recetas por negocio

Combinaciones listas. Úsalas como punto de partida cuando el pedido no especifica, y ajústalas con
lo que pidan. Los colores cumplen contraste AA sobre blanco en texto pequeño; si la marca ya tiene
color, manda el de la marca (comprueba que llegue a 4.5:1, si no, oscurécelo para el texto).

## Resumen

| Rubro | Intensidad | `--azul` / `--azul-2` / `--azul-claro` | Fondo (figura · movimiento · formación) |
|---|---|---|---|
| Software, consultoría, agencia | espectáculo | `#2563eb` / `#1e3a8a` / `#60a5fa` | hoja o modulo · caer · espiral |
| Cafetería, panadería | media | `#8a4b2a` / `#4a2412` / `#c98a5e` | grano · caer · espiral |
| Restaurante | media | `#c2410c` / `#7c2d12` / `#fb923c` | chispa · deriva · — |
| Clínica, consultorio, dental | sobria | `#0f766e` / `#134e4a` / `#2dd4bf` | cruz · subir · anillo |
| Farmacia, botica | sobria | `#047857` / `#064e3b` / `#34d399` | cruz · subir · — |
| Belleza, spa, estética | media | `#be185d` / `#831843` / `#f472b6` | burbuja o chispa · subir · anillo |
| Joyería, productos premium | media | `#a16207` / `#713f12` / `#facc15` | chispa o anillo · deriva · espiral |
| Inmobiliaria, arquitectura | media | `#0369a1` / `#0c4a6e` / `#38bdf8` | modulo · quieto · rejilla |
| Educación, academia, cursos | media | `#7c3aed` / `#4c1d95` / `#a78bfa` | confeti o nodo · caer · espiral |
| Finanzas, contabilidad, seguros | sobria | `#1e40af` / `#172554` / `#60a5fa` | nodo · quieto · — |
| Legal, notaría | sobria | `#7f1d1d` / `#450a0a` / `#dc2626` | sin fondo |
| Logística, envíos, transporte | media | `#0e7490` / `#164e63` / `#22d3ee` | trazo · onda · onda |
| Datos, IA, telecomunicaciones | espectáculo | `#4f46e5` / `#312e81` / `#818cf8` | nodo · orbita · anillo |
| Eventos, fiestas, niños | media | `#db2777` / `#831843` / `#f9a8d4` | confeti · caer · espiral |
| Gimnasio, deporte | media | `#dc2626` / `#7f1d1d` / `#f87171` | trazo o anillo · onda · onda |
| Moda, tienda de ropa | media | `#18181b` / `#000000` / `#71717a` | chispa · caer · — (marca en blanco y negro) |
| Agro, alimentos naturales | media | `#4d7c0f` / `#365314` / `#a3e635` | hoja · caer · espiral |

Con esas tres variables cambian a la vez el degradado, los botones, el foco y el fondo animado.

## Software, consultoría, agencia digital

- **Secciones:** S0, S1, S2, S3, S4, S5, S6, S7, S8, S9, S10 (la página completa).
- **Animaciones:** todas, A01–A17.
- **Rueda (A04):** «Hacemos» software a medida · chatbots que venden · landings que convierten · equipos que aprenden.
- **Dolores (S3):** Pedidos que se pierden. / Clientes sin respuesta. / Equipos que no avanzan. / Lo ponemos *en orden.*
- **Escenas del bento:** módulos que encajan, chat que escribe, maqueta que se arma, dato que recorre una red.
- **Vitrina (A16):** panel con KPIs, editor de código, teléfono con asistente, chips de servicios.

## Cafetería, panadería

- **Secciones:** S1, S2, S3 (opcional), S5 como carta, S6, S8 (el barista o la familia), S10 con horario y mapa.
- **Animaciones:** A02, A03, A04, A05, A06, A08, A10, A11, A13, A17. Sin intro: quien busca un café quiere la dirección ya.
- **Rueda:** «Hoy hay» pan recién salido · café de origen · postres de la casa · desayunos hasta las 11.
- **Dolores:** El café de siempre. / La mesa que nunca está. / La prisa de la mañana. / Aquí, *sin apuro.*
- **Escenas del bento:** taza que se llena (barras A13 en vertical, color café), vapor que sube (`trazo` en CSS), reloj de horario.
- **Botón principal:** «Reservar mesa» o «Pedir por WhatsApp».

## Restaurante

- Como cafetería, con S5 como carta por categorías y una foto grande por plato con A10.
- Fondo: `chispa · deriva` muy tenue (`opacidad: .6`), sin formación: la comida es la protagonista.
- **Botón principal:** «Reservar» y, en el cierre, horario + dirección + WhatsApp.

## Clínica, consultorio, dental

- **Intensidad sobria.** Sin intro, sin vitrina, sin cursor.
- **Secciones:** S1, S2, S5 (especialidades), S7 (cómo es tu primera cita), S8 (el equipo médico, con colegiatura), S9, S10.
- **Animaciones:** A02, A03, A05, A08, A09, A10, A11, A12, A17 con `cruz · subir · anillo` y `opacidad: .7`.
- **Rueda:** no. La claridad gana a la novedad.
- **Promesas (S9):** Te explicamos todo antes de empezar · Precios claros desde la primera cita · Atención el mismo día.
- **Botón principal:** «Agendar cita».

## Farmacia, botica

- Como clínica, con S5 = categorías (recetas, cuidado personal, bebés, delivery) y S10 con WhatsApp para pedidos.
- Fondo `cruz · subir` sin formación. Escena del bento: una moto que recorre una ruta (`dato que recorre una red`).

## Belleza, spa, estética

- **Secciones:** S1, S2, S3, S5 (tratamientos con precio desde), S8, S9, S10.
- **Animaciones:** media + A14 en tarjetas.
- **Fondo:** `burbuja · subir · anillo` (spa) o `chispa · deriva · espiral` (maquillaje, uñas).
- **Rueda:** «Para» relajarte · verte bien · regalar · celebrar.
- **Botón principal:** «Reservar mi cita».

## Inmobiliaria, arquitectura

- **Secciones:** S1, S2, S4 (vitrina: plano que se arma pieza a pieza en lugar de panel), S5 (proyectos), S6, S7, S10.
- **Fondo:** `modulo · quieto · rejilla`, `opacidad: .6`. Evoca plano, lote, edificio.
- **A10** en cada foto de proyecto. Cifras: m² entregados, familias, años.

## Educación, academia, cursos

- **Secciones:** S1, S2, S3, S5 (cursos), S6 (alumnos, horas, empleabilidad), S7 (cómo aprendes), S8 (docentes), S10.
- **Fondo:** `confeti · caer · espiral` (niños, inicial) o `nodo · deriva · anillo` (adultos, tecnología).
- **Escena del bento:** barras que suben (el nivel del alumno), chat con el tutor.

## Finanzas, contabilidad, seguros · Legal, notaría

- **Intensidad sobria.** El movimiento resta confianza si sobra.
- **Secciones:** S1, S2, S5, S7, S8, S9, S10.
- **Animaciones:** A03, A05, A08, A09, A11. Finanzas puede llevar `nodo · quieto`; legal, sin fondo.
- **Promesas:** honorarios claros por escrito, respuesta en 24 h, confidencialidad.

## Logística, envíos, transporte

- **Fondo:** `trazo · onda · onda`: líneas que avanzan como rutas.
- **Escenas del bento:** dato que recorre una red (ruta de entrega), contador de envíos, mapa con puntos.
- **Rueda:** «Llevamos» paquetes · mercadería · documentos · tu tienda entera.

## Datos, IA, telecomunicaciones

- Como software, con fondo `nodo · orbita · anillo` y `cursor: 'repele'`.
- La vitrina muestra un panel de métricas y un asistente.

## Eventos, fiestas, niños

- **Fondo:** `confeti · caer · espiral` con `hueco: 0`. El confeti alterna color y claro.
- **Rueda:** «Organizamos» cumpleaños · bodas · graduaciones · eventos de empresa.
- **Escenas del bento:** calendario que se marca, globo que sube (`burbuja` en CSS).

## Gimnasio, deporte

- **Fondo:** `trazo · onda · onda` (energía) o `anillo · orbita` (discos, aros).
- **A08** en grande: socios, clases por semana, kilos perdidos (solo si son reales).
- Titulares cortos, de tres palabras. El tono más directo de todos.

## Moda, tienda de ropa

- Marca en blanco y negro: `--azul: #18181b`, `--degradado` de negro a gris.
- Fotos de producto grandes con A10; bento con fotos en vez de escenas.
- Fondo `chispa · caer` muy tenue o ninguno: la ropa manda.
