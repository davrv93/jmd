# 02 · Animaciones: catálogo A01–A17

Cada animación tiene un código para poder pedirla («ponle A06 y A08»). Todo movimiento de la
página sale de esta lista. Si algo nuevo no encaja, reutiliza una; solo si no hay forma, crea otra
con la misma curva y duraciones del mismo rango.

| Código | Nombre | Qué se ve | Disparo | Coste |
|---|---|---|---|---|
| A01 | Intro de arranque | Isotipo que se dibuja, letras que se enfocan, barra de carga, zoom de salida | carga | bajo |
| A02 | Titular que sube | Cada palabra sube desde una máscara y se enfoca | carga | bajo |
| A03 | Entrada escalonada | Bajada, botones y detalles aparecen en cascada | carga | bajo |
| A04 | Palabra que rota | «Hacemos ___» cambia cada 2,6 s con cursor parpadeante | tiempo | bajo |
| A05 | Revelado | Bloques suben 40 px, crecen de .97 a 1 y aparecen | entrar en pantalla | bajo |
| A06 | Titular que se enciende | Palabras de gris claro a tinta al ritmo del scroll | scroll | medio |
| A07 | Portada que se aleja | La portada sube, encoge y se desvanece al bajar | scroll | bajo |
| A08 | Contadores | Números que cuentan con frenada suave | entrar en pantalla | bajo |
| A09 | Trazo que se dibuja | Iconos de línea e hilos de progreso que se dibujan | entrar en pantalla | bajo |
| A10 | Foto que se descubre | Máscara que sube mientras la foto desescala | entrar en pantalla | bajo |
| A11 | Microinteracciones | Subrayado de nav, botón que sube, flecha que avanza, tarjeta que flota | hover | bajo |
| A12 | Indicador de scroll | Ratón dibujado con rueda que baja | bucle | bajo |
| A13 | Escenas en bucle | Mini animación que explica un servicio dentro de su tarjeta | bucle | bajo |
| A14 | Flotación | Piezas que respiran arriba y abajo | bucle | bajo |
| A15 | Sección fijada con relevo | La página se detiene y las frases se relevan con desenfoque | scroll | medio |
| A16 | Vitrina con cámara | Un producto hecho en HTML se arma pieza a pieza mientras una cámara se mueve | scroll | alto |
| A17 | Fondo animado | Figuras que se mueven detrás y se ordenan en una formación | continuo | medio |

A15 y A16 están en [03-scroll-guiado.md](03-scroll-guiado.md); A17, en [05-fondo-figuras.md](05-fondo-figuras.md).

## Gramática

- **Curva:** `var(--suave)` = `cubic-bezier(.16, 1, .3, 1)` para casi todo.
  `ease-in-out` solo en bucles de flotación. `steps(1)` solo en cursores que parpadean.
- **Duraciones:** micro (hover, color) `.3s–.5s` · entradas `.7s–1.1s` · revelados grandes `1.5s–2.2s`
  · bucles de escena `6s–9s`.
- **La entrada «Apple» combina tres cosas:** sube (`translateY`), se enfoca (`blur` → 0) y aparece
  (`opacity` 0 → 1). Si falta el desenfoque, parece una web cualquiera.
- **Escalonado:** el retraso se pasa por variable CSS en el HTML (`style="--i:2"`, `--d:120`) y el CSS
  lo multiplica con `calc()`. Nada de `nth-child` en cadena salvo para 5–6 elementos fijos.
- **Disparo:** la intro y la portada esperan la clase `.listo` en `<html>`; lo demás espera `.in`, que
  pone un `IntersectionObserver`; lo guiado por scroll se escribe en línea desde el rAF (ver 03).

---

## A01 · Intro de arranque (como un equipo que enciende)

Se decide **antes de pintar**, en el `<head>`, para que no se vea la página un instante y luego la intro:

```html
<script>
  if (!matchMedia('(prefers-reduced-motion: reduce)').matches) document.documentElement.classList.add('arranque');
</script>
```

Secuencia (total ≈ 2,75 s, saltable con clic o tecla):

| t | Qué pasa |
|---|---|
| 0,05 s | Se dibuja el marco del isotipo (`stroke-dashoffset` 200 → 0, 1 s) |
| 0,45 s | Se dibuja la letra del isotipo (120 → 0, .9 s) |
| 0,95–1,25 s | Seis letras del nombre suben y se enfocan, cada una 60 ms después |
| 1,05 s | Aparece la barra; a 1,2 s empieza a cargar (1,35 s, con pausa a 62 %) |
| 1,35 s | El subtítulo aparece **cerrando** su tracking de .9em a .46em |
| 2,75 s | Salida: la intro se desvanece y su contenido crece a 1.08 y se desenfoca |

```css
.boot { position: fixed; inset: 0; z-index: 100; display: none; place-items: center; background: var(--blanco); }
.arranque .boot { display: grid; }
.arranque body { overflow: hidden; }
.boot__iso .iso__marco { stroke-dasharray: 200; stroke-dashoffset: 200; animation: boot-trazo 1s .05s var(--suave) forwards; }
.boot__iso .iso__m     { stroke-dasharray: 120; stroke-dashoffset: 120; animation: boot-trazo .9s .45s var(--suave) forwards; }
.boot__texto span { opacity: 0; transform: translateY(.35em); filter: blur(8px); animation: boot-letra .7s var(--suave) forwards; }
.boot__texto span:nth-child(1) { animation-delay: .95s }  /* … +60 ms por letra … */
.boot__sub { letter-spacing: .9em; opacity: 0; animation: boot-sub 1s 1.35s var(--suave) forwards; }
.boot__barra   { width: clamp(150px, 22vw, 220px); height: 4px; border-radius: 4px; background: var(--linea); overflow: hidden; opacity: 0; animation: boot-aparece .4s 1.05s forwards; }
.boot__barra i { display: block; height: 100%; background: var(--tinta); transform: scaleX(0); transform-origin: left;
                 animation: boot-carga 1.35s 1.2s cubic-bezier(.65, 0, .25, 1) forwards; }
.boot.fuera { animation: boot-fuera .7s var(--suave) forwards; pointer-events: none; }
.boot.fuera .boot__c { animation: boot-zoom .7s var(--suave) forwards; }
@keyframes boot-trazo   { to { stroke-dashoffset: 0 } }
@keyframes boot-letra   { to { opacity: 1; transform: none; filter: blur(0) } }
@keyframes boot-sub     { to { opacity: 1; letter-spacing: .46em } }
@keyframes boot-aparece { to { opacity: 1 } }
@keyframes boot-carga   { 0% { transform: scaleX(0) } 55% { transform: scaleX(.62) } 100% { transform: scaleX(1) } }
@keyframes boot-fuera   { to { opacity: 0; visibility: hidden } }
@keyframes boot-zoom    { to { transform: scale(1.08); filter: blur(6px) } }
```

```js
var raiz = document.documentElement, boot = document.getElementById('boot'), hecho = false;
var quieto = matchMedia('(prefers-reduced-motion: reduce)').matches;
function terminar() {
  if (hecho) return; hecho = true;
  raiz.classList.add('listo');                         // dispara la portada
  if (!boot || !raiz.classList.contains('arranque')) return;
  boot.classList.add('fuera');
  setTimeout(function () { raiz.classList.remove('arranque'); boot.remove(); }, 720);
}
if (quieto || !raiz.classList.contains('arranque')) terminar();
else { setTimeout(terminar, 2750); boot.addEventListener('click', terminar); addEventListener('keydown', terminar, { once: true }); }
```

- El SVG del isotipo usa `stroke` (no `fill`) para que se pueda dibujar. El `dasharray` debe ser
  mayor o igual que el perímetro; mídelo con `path.getTotalLength()` si cambias el logo.
- La intro lleva `aria-hidden="true"`: es decoración, el lector de pantalla va directo al contenido.
- No pases de 3 s. Quien vuelve a la página no quiere esperar: siempre saltable.

## A02 · Titular que sube palabra a palabra

Cada palabra sube desde detrás de una máscara (`overflow: hidden` en la línea) mientras se enfoca.

```html
<h1 class="titular serif" aria-label="Tu café, como en casa.">
  <span class="linea" aria-hidden="true"><span class="pal" style="--i:0">Tu</span> <span class="pal" style="--i:1">café,</span></span>
  <span class="linea" aria-hidden="true"><em><span class="pal" style="--i:2">como</span> <span class="pal" style="--i:3">en</span> <span class="pal" style="--i:4">casa.</span></em></span>
</h1>
```

```css
.titular .linea { display: block; overflow: hidden; padding-bottom: .12em; margin-bottom: -.12em; } /* no corta descendentes */
.titular .pal   { display: inline-block; transform: translateY(110%); filter: blur(10px); opacity: 0; }
.listo .titular .pal { animation: sube 1.1s var(--suave) forwards; animation-delay: calc(var(--i) * 90ms + 80ms); }
.titular em .pal { background: var(--degradado); -webkit-background-clip: text; background-clip: text; color: transparent; }
@keyframes sube { to { transform: none; filter: blur(0); opacity: 1 } }
```

- `aria-label` en el `<h1>` y `aria-hidden` en los trozos: el lector lee la frase entera una vez.
- **El degradado va en cada `.pal`, no en el `<em>`:** un `inline-block` transformado no hereda el
  `background-clip: text` del padre.
- 90 ms entre palabras. Más de 4–5 palabras en portada se siente lento: acorta el titular.

## A03 · Entrada escalonada al cargar

```css
.entra { opacity: 0; transform: translateY(18px); }
.listo .entra { animation: entra 1s var(--suave) forwards; animation-delay: calc(var(--d, 0) * 1ms); }
@keyframes entra { to { opacity: 1; transform: none } }
```

Retrasos usados: ojo `--d:60`, bajada `650`, palabra rotatoria `800`, botones `950`, indicador de scroll `1400`.
Es decir: primero el titular (≈ 0,4 s), después todo lo demás en cascada.

## A04 · Palabra que rota («Hacemos ___»)

Cinco frases apiladas en la misma celda de grid; la que sale sube, la que entra viene de abajo.

```html
<p class="hacemos"><span>Hacemos</span>
  <span class="rueda" id="rueda" aria-live="off"><span class="on">[servicio uno]</span><span>[servicio dos]</span>…</span>
  <i class="cursor" aria-hidden="true"></i></p>
```

```css
.hacemos .rueda { position: relative; display: inline-grid; font-weight: 600; letter-spacing: -.02em; color: var(--tinta); }
.hacemos .rueda span { grid-area: 1 / 1; opacity: 0; transform: translateY(.5em); filter: blur(6px);
  transition: opacity .6s, transform .7s var(--suave), filter .6s; white-space: nowrap; }
.hacemos .rueda span.on   { opacity: 1; transform: none; filter: none; }
.hacemos .rueda span.sale { transform: translateY(-.5em); }
.cursor { width: 2px; height: 1.1em; background: var(--azul); align-self: center; animation: parpadea 1s steps(1) infinite; }
@keyframes parpadea { 50% { opacity: 0 } }
```

```js
var rueda = [].slice.call(document.querySelectorAll('#rueda span')), cual = 0;
if (!quieto && rueda.length > 1) setInterval(function () {
  var sale = rueda[cual]; cual = (cual + 1) % rueda.length;
  sale.classList.remove('on'); sale.classList.add('sale');
  rueda[cual].classList.add('on');
  setTimeout(function () { sale.classList.remove('sale'); }, 700);
}, 2600);
```

`inline-grid` con todas en la misma celda hace que el ancho sea el de la frase más larga: nada salta.

## A05 · Revelado al entrar en pantalla (`.rv`)

El caballo de batalla. Sube 40 px, crece de .97 a 1 y aparece.

```css
.rv { opacity: 0; transform: translateY(40px) scale(.97);
      transition: opacity 1s var(--suave), transform 1.1s var(--suave); transition-delay: calc(var(--d, 0) * 1ms); }
.rv.in { opacity: 1; transform: none; }
```

```js
var io = new IntersectionObserver(function (es) {
  es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
}, { threshold: 0.18, rootMargin: '0px 0px -6% 0px' });
document.querySelectorAll('.rv').forEach(function (el) { io.observe(el); });
```

- Escalonado en retículas: `style="--d:0"`, `--d:120`, `--d:240` (120 ms entre hermanos).
- Una vez dentro, se queda (`unobserve`). Repetir el revelado al volver a subir cansa.
- `.in` también la usan componentes compuestos (`.pasos.in`, `.retrato.in`, `.promesa.in`) para
  disparar animaciones internas. Un mismo observador para todo.

## A06 · Titular que se enciende con el scroll (`.luz`)

Las palabras empiezan gris claro y se pasan a tinta **según el scroll**, no por tiempo. Da la
sensación de que lees al ritmo en que bajas.

```css
.luz .w    { color: #d2d2d8; transition: color .45s; }
.luz .w.on { color: var(--tinta); }
.luz em .w.on { background: var(--degradado); -webkit-background-clip: text; background-clip: text; color: transparent; }
```

```js
if (!quieto) document.querySelectorAll('.luz').forEach(function (el) {
  (function partir(nodo) {                       // envuelve cada palabra en <span class="w">, respetando <em>
    [].slice.call(nodo.childNodes).forEach(function (n) {
      if (n.nodeType === 1) return partir(n);
      var f = document.createDocumentFragment();
      n.textContent.split(/(\s+)/).forEach(function (p) {
        if (/^\s*$/.test(p)) return f.appendChild(document.createTextNode(p));
        var w = document.createElement('span'); w.className = 'w'; w.textContent = p; f.appendChild(w);
      });
      nodo.replaceChild(f, n);
    });
  })(el);
  var pal = el.querySelectorAll('.w');
  tareas.push(function () {                      // se ejecuta en el rAF compartido (ver 03)
    var r = el.getBoundingClientRect(), a = innerHeight;
    var av = acota((a * 0.92 - r.top) / (a * 0.3 + r.height * 0.5));
    if (scrollY + a >= document.documentElement.scrollHeight - 8) av = 1;   // el último titular no tiene más scroll
    var hasta = Math.round(av * pal.length);
    for (var i = 0; i < pal.length; i++) pal[i].classList.toggle('on', i < hasta);
  });
});
```

- Empieza cuando el titular asoma por abajo (92 % de la altura) y termina cuando ha subido un 30 %
  de pantalla más media altura propia.
- La línea del final de página es obligatoria: sin ella, el titular del cierre se queda a medias.
- Sin JavaScript o con movimiento reducido no se parte nada y el titular se ve en tinta normal.

## A07 · La portada se aleja al bajar

```js
tareas.push(function () {
  var p = acota(scrollY / (innerHeight * 0.75));
  portada.style.opacity = 1 - p * 1.15;
  portada.style.transform = 'translateY(' + (-p * 46) + 'px) scale(' + (1 - p * 0.07) + ')';
});
```

Con `will-change: transform, opacity` en `.portada__c`. Se desvanece algo antes de terminar de subir (×1,15).

## A08 · Contadores

```js
var ioC = new IntersectionObserver(function (es) {
  es.forEach(function (e) {
    if (!e.isIntersecting) return; ioC.unobserve(e.target);
    var fin = +e.target.dataset.cuenta, t0 = performance.now(), dur = 1600;
    if (quieto) { e.target.textContent = fin; return; }
    (function paso(t) {
      var k = Math.min(1, (t - t0) / dur), s = 1 - Math.pow(1 - k, 4);   // ease-out quart
      e.target.textContent = Math.round(fin * s);
      if (k < 1) requestAnimationFrame(paso);
    })(t0);
  });
}, { threshold: 0.6 });
document.querySelectorAll('[data-cuenta]').forEach(function (el) { ioC.observe(el); });
```

HTML: `<b><span data-cuenta="500">0</span><sup>+</sup></b>`. El `+` queda fuera del número.

## A09 · Trazo que se dibuja (iconos y hilos)

```css
.promesa svg .tz { stroke-dasharray: 80; stroke-dashoffset: 80; transition: stroke-dashoffset 1.6s var(--suave) .3s; }
.promesa.in svg .tz { stroke-dashoffset: 0; }

.hilo i { display: block; height: 100%; background: var(--azul); transform: scaleX(0); transform-origin: left;
          transition: transform 2.2s var(--suave) .2s; }
.pasos.in .hilo i { transform: scaleX(1); }
```

Nodos que se encienden en cadena siguiendo al hilo: `transition-delay: calc(var(--p) * .45s + .3s)`.

## A10 · Foto que se descubre

```css
.retrato__m { border-radius: var(--radio); overflow: hidden; aspect-ratio: 4 / 5;
              clip-path: inset(100% 0 0 0 round var(--radio)); transition: clip-path 1.5s var(--suave); }
.retrato.in .retrato__m { clip-path: inset(0 0 0 0 round var(--radio)); }
.retrato img { transform: scale(1.18); transition: transform 2.2s var(--suave); }
.retrato.in img { transform: scale(1); }
.retrato figcaption { opacity: 0; transform: translateY(14px); transition: opacity .9s .9s, transform 1s var(--suave) .9s; }
.retrato.in figcaption { opacity: 1; transform: none; }
```

La máscara sube en 1,5 s mientras la foto desescala en 2,2 s: la imagen sigue moviéndose cuando ya
está entera. El pie llega al final (0,9 s de retraso).

## A11 · Microinteracciones (hover y nav)

```css
/* enlace de nav: subrayado que entra por la izquierda y sale por la derecha */
.nav__links a::after { content: ""; position: absolute; left: 0; right: 0; bottom: -4px; height: 1px; background: var(--tinta);
  transform: scaleX(0); transform-origin: right; transition: transform .5s var(--suave); }
.nav__links a:hover::after { transform: scaleX(1); transform-origin: left; }

/* botón: sube 2px, toma el color de marca y la flecha avanza */
.btn { transition: transform .5s var(--suave), background .3s, color .3s, box-shadow .5s; }
.btn--lleno:hover { background: var(--azul); border-color: var(--azul); transform: translateY(-2px);
                    box-shadow: 0 14px 30px -12px color-mix(in srgb, var(--azul) 60%, transparent); }
.btn svg { transition: transform .5s var(--suave); } .btn:hover svg { transform: translateX(4px); }

/* tarjeta: sube 6px con sombra larga */
.tj { transition: transform .7s var(--suave), box-shadow .7s var(--suave), background .5s; }
.tj:hover { transform: translateY(-6px); box-shadow: 0 40px 70px -40px rgba(11, 18, 32, .35); }
```

## A12 · Indicador de scroll

```css
.baja { position: absolute; left: 50%; bottom: clamp(1rem, 3vh, 2rem); translate: -50% 0; width: 22px; height: 36px;
        border: 1.5px solid var(--gris-2); border-radius: 12px; }
.baja::after { content: ""; position: absolute; left: 50%; top: 7px; width: 3px; height: 7px; margin-left: -1.5px;
               border-radius: 2px; background: var(--azul); animation: baja 1.8s var(--suave) infinite; }
@keyframes baja { 0% { opacity: 0; transform: translateY(-3px) } 30% { opacity: 1 } 100% { opacity: 0; transform: translateY(12px) } }
```

Usa `translate:` (propiedad independiente) para centrar, y deja `transform` libre para la animación de entrada.

## A13 · Escenas en bucle dentro de tarjetas

Cada tarjeta del bento cuenta su servicio con una mini animación de 6–9 s que entra, se queda ~60 %
del ciclo y sale. Recetas completas en [04-componentes.md](04-componentes.md#escenas-del-bento):
módulos que encajan, chat que escribe, maqueta que se arma, dato que recorre una red, barras que suben.
Para otros rubros, la misma técnica: una taza que se llena (cafetería), un calendario que se marca
(citas), una llave que gira (inmobiliaria), un recibo que se imprime línea a línea (finanzas).

Patrón común de fotogramas: `0–6 %` invisible y desplazado → `26 %` en su sitio → `84–88 %` aún quieto
→ `100 %` desvanecido. Así el bucle tiene una pausa larga legible y un reinicio limpio.

## A14 · Flotación

```css
.flota { animation: vit-flota 7s ease-in-out infinite; animation-delay: calc(var(--f, 0) * -1.3s); }
@keyframes vit-flota { 50% { transform: translateY(-7px) } }
```

Retraso **negativo**: cada pieza arranca ya en otra fase del ciclo, sin esperar. Aplícala a un
**hijo** de la pieza que mueve el scroll, nunca a la misma: las dos escribirían `transform`.
