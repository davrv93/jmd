# 07 · Redacción y legibilidad

La belleza de la página depende tanto del texto como del CSS. Un titular de doce palabras no se
salva con ninguna animación.

## Voz

- **Para el cliente final, no para el gremio.** Habla de lo que le pasa (tiempo, dinero, dolor, gusto),
  no de la jerga del rubro: ni «APIs» en software, ni «endodoncia» en el titular de una clínica.
- **Tuteo** («tu empresa», «te explicamos»), cálido y directo.
- **Concreto antes que abstracto:** «Pedidos que se pierden» y no «Ineficiencias operativas»;
  «Pan a las 7» y no «Productos frescos de calidad».
- **Honesto:** «Recibes una recomendación honesta, aunque la respuesta sea “no hace falta”». Este tipo de
  frase genera más confianza que cualquier superlativo.
- **El tono cambia con el rubro:** cálido en cafetería, sereno en salud, preciso en finanzas, directo en
  deporte. La estructura de abajo no cambia.
- **Cero datos inventados.** Cifras, nombres, años, número de WhatsApp y testimonios salen del cliente.
  Si faltan, se deja un marcador visible (`[CIFRA]`) y se avisa, nunca se rellena.

## Estructura de cada texto

| Pieza | Forma | Ejemplos |
|---|---|---|
| Titular de portada | 3–5 palabras, dos líneas, remate en `<em>` | Tu café, / *como en casa.* · Sonríe / *sin miedo.* · Tu negocio, / *más simple.* |
| Bajada | Una frase, ≤ 25 palabras, una idea en `<strong>` | Café de origen y pan del día en el centro de la ciudad, **abiertos desde las 7**. |
| Palabra rotatoria | «Hacemos / Hoy hay / Para» + 4–5 frases de 2–3 palabras | pan recién salido · café de origen · postres de la casa |
| Frases fijadas (S3) | Tres dolores de 3–4 palabras + una solución | El dolor de muelas. / La cita que nunca llega. / El miedo al sillón. / Aquí, *sin esperas.* |
| Ojo | Número + raya + una o dos palabras | **01** — Servicios · **02** — Carta · **03** — Equipo |
| Titular de sección | Dos frases: lo que hay + remate en `<em>` | Cuatro especialidades. *Un solo lugar.* |
| Tarjeta | Título de 1–3 palabras + una frase de ≤ 25 palabras | Ortodoncia — Brackets o alineadores, con un plan de pagos que se ajusta a ti. |
| Paso | Detalle en mono + verbo + frase | 01 · 20 minutos — Te escuchamos — Nos cuentas qué te molesta, sin apuro. |
| Cifra | Número + `+` + etiqueta de 2–3 palabras en mayúsculas | 1200+ PACIENTES · 15 AÑOS ABIERTOS · 40+ PROYECTOS |
| Cierre | Pregunta de 2–3 palabras, gigante | ¿Lo *hablamos?* · ¿Te *esperamos?* · ¿*Empezamos?* |
| Botón principal | Verbo + qué recibe + condición | Agendar mi primera cita · Reservar mesa para hoy · Pedir un diagnóstico sin costo |

## Legibilidad

- **Ancho de lectura:** párrafos de 30–36 rem (≈ 60–75 caracteres). Titulares limitados con `ch`.
- **Jerarquía por tamaño y peso, no por color:** tinta para titulares, gris para lectura, color de marca
  solo para remates (`<em>`), números de ojo y foco.
- **El `<em>` en degradado se usa una vez por titular** y siempre al final: es donde cae la vista.
- **Nada de texto sobre imagen** salvo el pie de foto con vidrio.
- **Alinear:** portada, frases fijadas, cifras y cierre centrados; secciones de contenido alineadas a la
  izquierda. No mezcles dentro de una misma sección.
- **Signos del castellano:** comillas latinas «», raya —, apertura de interrogación ¿, «a. m.», separador
  `·` entre datos. Da textura editorial.
- **Mayúsculas solo en textos ≤ 4 palabras** y siempre con tracking abierto (.16–.2em).
