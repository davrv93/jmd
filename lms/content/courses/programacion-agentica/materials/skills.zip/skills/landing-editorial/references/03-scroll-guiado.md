# 03 · Scroll guiado: secciones fijadas y vitrina con cámara

Es lo que más se parece a apple.com: la página deja de desplazarse, se queda fija y el scroll pasa
a ser una línea de tiempo. Se hace con `position: sticky`, sin librerías.

## El motor: un solo rAF para todo

```js
function acota(v) { return v < 0 ? 0 : v > 1 ? 1 : v; }          // recorta a [0, 1]
function suave(v) { v = acota(v); return v * v * (3 - 2 * v); }  // smoothstep: entra y sale suave
var tareas = [], pend = false;
function alScroll() {
  if (!pend) { pend = true; requestAnimationFrame(function () { pend = false; tareas.forEach(function (f) { f(); }); }); }
}
addEventListener('scroll', alScroll, { passive: true });
addEventListener('resize', alScroll);
// … cada efecto hace tareas.push(función) …
alScroll();   // primer pintado, al final del script
```

Reglas:

- **Un solo listener de scroll** para la página entera. Cada efecto registra su función en `tareas`.
- Las funciones solo **leen** `getBoundingClientRect()`/`scrollY` y **escriben** `style`. Nada de
  crear nodos, medir texto ni consultar el DOM con selectores dentro del rAF: todo eso se cachea fuera.
- Toda salida se pasa por `suave()`: los valores lineales se notan mecánicos.
- `tr(p, a, b) = suave((p - a) / (b - a))` convierte el progreso global `p` en el progreso de un tramo.
  Con esa sola función se coreografía toda una sección.

```js
function tr(p, a, b) { return suave((p - a) / (b - a)); }
```

## A15 · Sección fijada: la estructura

```html
<section class="orden" id="orden" aria-label="Lo que resolvemos">
  <div class="orden__pin">
    <p class="orden__f"><small>Lo que te quita tiempo</small>[Dolor uno.]</p>
    <p class="orden__f">[Dolor dos.]</p>
    <p class="orden__f">[Dolor tres.]</p>
    <p class="orden__f"><small>[Marca]</small>[Solución] <span class="az">[remate.]</span></p>
    <div class="orden__av" aria-hidden="true"><i></i><i></i><i></i><i></i></div>
  </div>
</section>
```

```css
.orden      { height: 420vh; padding: 0; }                         /* largo = duración */
.orden__pin { position: sticky; top: 0; height: 100vh; height: 100svh; display: grid; place-items: center; overflow: hidden; }
.orden__f   { grid-area: 1 / 1;                                    /* todas apiladas en la misma celda */
              text-align: center; font-weight: 600; letter-spacing: -.045em; line-height: .98;
              font-size: clamp(2.2rem, 7vw, 6.4rem); max-width: 12ch; padding-inline: var(--margen);
              opacity: 0; transform: translateY(24px) scale(.96); filter: blur(10px); will-change: opacity, transform, filter; }
.orden__f small { display: block; margin-bottom: 1rem; font-size: .72rem; font-weight: 500; letter-spacing: .2em; text-transform: uppercase; color: var(--gris); }
.orden__av   { position: absolute; bottom: clamp(1.25rem, 4vh, 2.5rem); left: 50%; translate: -50% 0; display: flex; gap: 6px; }
.orden__av i { width: 22px; height: 3px; border-radius: 3px; background: var(--linea); }
.orden__av i.on { background: var(--azul); }
```

- **Altura de la sección ≈ 100vh × (número de estados) + 20 %.** Cuatro frases → `420vh`.
  La vitrina, con cinco tramos y mucho detalle, usa `600vh`.
- El progreso es `p = acota(-r.top / (r.height - innerHeight))`: 0 cuando el pin toca arriba, 1 cuando
  está a punto de soltarse.
- **El indicador de avance** (rayitas abajo) es obligatorio: sin él, el usuario cree que la página se colgó.

## Relevo de frases

Cada frase ocupa un tramo de `1/n`. Dentro de su tramo entra en el primer 30 %, se queda, y sale
en el último 28 %. La primera ya está visible al llegar; la última se queda.

```js
var orden = document.getElementById('orden'), ordenP = 0;
if (orden && !quieto) {
  var frases = orden.querySelectorAll('.orden__f'), av = orden.querySelectorAll('.orden__av i'), n = frases.length;
  tareas.push(function () {
    var r = orden.getBoundingClientRect();
    ordenP = acota(-r.top / (r.height - innerHeight));
    for (var i = 0; i < n; i++) {
      var x = ordenP * n - i;                                        // progreso dentro del tramo de la frase i
      var o = i === n - 1 ? suave(x / 0.35) : suave(x / 0.3) * (1 - suave((x - 0.72) / 0.28));
      if (i === 0) o = (1 - suave((x - 0.72) / 0.28));
      var sale = i === n - 1 ? 0 : suave((x - 0.72) / 0.28);
      frases[i].style.opacity = o;
      frases[i].style.transform = 'translateY(' + ((1 - suave(x / 0.3)) * 28 - sale * 28) + 'px) scale(' + (0.96 + 0.04 * o) + ')';
      frases[i].style.filter = 'blur(' + ((1 - o) * 10) + 'px)';
      av[i].classList.toggle('on', x >= 0);
    }
  });
}
```

Movimiento resultante: la frase entra **subiendo desde abajo**, se enfoca, y sale **subiendo más**
mientras se desenfoca. La siguiente ya está entrando: hay un cruce breve, nunca un hueco en blanco.

Narrativa que funciona: tres frases de dolor, cortas y concretas, y una cuarta con la solución y la
marca (con `.az` en el remate). Ver [07-redaccion.md](07-redaccion.md).

## A16 · Vitrina: el producto se arma con el scroll

En vez de capturas de pantalla, el producto se **construye en HTML/CSS** sobre un lienzo de tamaño
fijo y el scroll lo va montando pieza a pieza.

### Lienzo fijo escalado

```html
<section class="vit" id="vitrina" aria-label="Así se ve el producto">
  <div class="vit__pin">
    <div class="vit__velo" id="vitVelo"></div>          <!-- tapa el lienzo bajo los titulares en móvil -->
    <div class="vit__cap">
      <p class="ojo"><b>Así se ve</b> — [el producto]</p>
      <h2 class="vit__t" style="--a:#2563eb;--b:#06b6d4">Tu negocio, <span>en una sola pantalla.</span></h2>
      <h2 class="vit__t" style="--a:#7c3aed;--b:#ec4899">Hecho a tu medida, <span>línea por línea.</span></h2>
      …
    </div>
    <div class="lienzo" id="lienzo" aria-hidden="true"> … piezas con position:absolute en px … </div>
  </div>
</section>
```

```css
.vit     { height: 600vh; padding: 0; }
.vit__pin { position: sticky; top: 0; height: 100vh; height: 100svh; overflow: hidden; }
.vit__cap { position: absolute; z-index: 4; inset: clamp(4.4rem, 10vh, 6rem) var(--margen) auto;
            display: grid; justify-items: center; text-align: center; pointer-events: none; }
.vit__t   { grid-area: 2 / 1; font-weight: 600; letter-spacing: -.045em; line-height: 1;
            font-size: clamp(1.7rem, 4.6vw, 3.9rem); max-width: 17ch; opacity: 0; will-change: opacity, transform, filter; }
.vit__t:first-of-type { opacity: 1; }
.vit__t span { background: linear-gradient(100deg, var(--a), var(--b)); -webkit-background-clip: text; background-clip: text; color: transparent; }
.vit__velo { position: absolute; z-index: 3; inset: 0 0 auto 0; background: linear-gradient(#fff 0%, #fff 74%, rgba(255,255,255,0)); pointer-events: none; }
.lienzo  { position: absolute; left: 0; top: 0; width: 1280px; height: 760px; transform-origin: 0 0; will-change: transform; font-size: 12px; line-height: 1.35; }
.pz      { position: absolute; will-change: transform, opacity; }
```

- **Todo dentro del lienzo se mide en píxeles reales** sobre 1280 × 760, como en Figma. Luego un solo
  `scale()` lo adapta a cualquier pantalla. Así la maqueta nunca se descoloca.
- Cada titular de tramo tiene su propio par de colores (`--a`, `--b`) para el degradado.
- Halos de color difuminados detrás de cada pieza (`filter: blur(70px)`, `radial-gradient`) se
  encienden en su tramo: azul con el panel, violeta con el código, verde con el teléfono, ámbar con las conexiones.

### Cámara por fotogramas clave

La cámara es `[p, centroX, centroY, zoom]` en coordenadas del lienzo. Entre fotogramas se interpola con `suave`.

```js
function camara(K, p) {
  for (var i = 1; i < K.length; i++) if (p <= K[i][0]) {
    var a = K[i - 1], b = K[i], t = suave((p - a[0]) / ((b[0] - a[0]) || 1));
    return [a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t, a[3] + (b[3] - a[3]) * t];
  }
  var u = K[K.length - 1]; return [u[1], u[2], u[3]];
}

function pintar() {
  var r = vit.getBoundingClientRect(), W = innerWidth, H = innerHeight;
  var p = quieto ? 1 : acota(-r.top / (r.height - H));
  var cap = Math.max(150, H * 0.25), area = H - cap - 20;          // espacio que dejan los titulares
  var S = Math.min(W * 0.95 / 1280, area / 760), K;                // escala para que quepa entero
  if (W < 820) {                                                    // teléfono: acercarse a cada pieza
    var zp = (W * 0.94 / 700) / S, zc = Math.min(W * 0.9 / 350, area * 0.9 / 280) / S, zf = Math.min(W * 0.84 / 275, area * 0.96 / 540) / S;
    K = [[0, 590, 380, zp], [0.22, 590, 380, zp], [0.32, 204, 555, zc], [0.44, 204, 555, zc],
         [0.54, 1093, 402, zf], [0.66, 1093, 402, zf], [0.8, 640, 380, 1], [1, 640, 380, 1]];
  } else K = [[0, 590, 380, 1.3], [0.2, 610, 385, 1.1], [0.62, 640, 382, 1.02], [1, 640, 380, 1]];  // escritorio: abrir plano
  var c = camara(K, p), s = S * c[2];
  var medio = cap + Math.min(area / 2, 760 * s / 2 + 28);
  lz.style.transform = 'translate(' + (W / 2 - c[0] * s) + 'px,' + (medio - c[1] * s) + 'px) scale(' + s + ')';
  // … coreografía de piezas (abajo) …
}
tareas.push(pintar); pintar();
```

- **Escritorio:** un solo plano que empieza cerca (1.3) y se abre lentamente hasta 1: un *dolly out*.
- **Teléfono:** el plano completo es ilegible a 393 px, así que la cámara viaja a cada pieza, se detiene
  (fotogramas repetidos = pausa) y al final abre el plano entero como recompensa.
- Para elegir el centro de cada pieza: `left + width / 2`, `top + height / 2` en coordenadas del lienzo.

### Coreografía: una pieza por tramo

| Tramo de `p` | Pieza | Entrada |
|---|---|---|
| 0 – .14 | Panel principal | sube 70 px, baja de escala 1.12 → 1, se enfoca |
| .06 – .24 | KPIs y gráfico | números cuentan, barras crecen escalonadas 12 ms de `p` |
| .24 – .38 | Editor de código | llega desde la izquierda girado −8°; líneas se escriben con `clip-path` |
| .44 – .58 | Teléfono | llega desde la derecha girado +8°; burbujas aparecen una a una |
| .68 – .93 | Chips, cables, muelle | chips caen escalonados, cables punteados aparecen, el muelle sube |

```js
var a = tr(p, 0, 0.14);
panel.style.opacity = a;
panel.style.transform = 'translateY(' + (1 - a) * 70 + 'px) scale(' + (1.12 - 0.12 * a) + ')';
panel.style.filter = 'blur(' + (1 - a) * 10 + 'px)';
nums.forEach(function (n) { n.textContent = Math.round(+n.dataset.n * tr(p, 0.06, 0.24)); });
barras.forEach(function (b, i) { b.style.transform = 'scaleY(' + tr(p, 0.07 + i * 0.012, 0.2 + i * 0.012) + ')'; });
lineas.forEach(function (l, i) { l.style.clipPath = 'inset(0 ' + (1 - tr(p, 0.3 + i * 0.012, 0.345 + i * 0.012)) * 100 + '% 0 0)'; });

var cortes = [0, 0.24, 0.44, 0.66, 1.01];                // titulares que se relevan, cruce de ±0.03
tits.forEach(function (t, i) {
  var e = tr(p, cortes[i] - 0.03, cortes[i] + 0.03) * (1 - tr(p, cortes[i + 1] - 0.03, cortes[i + 1] + 0.03));
  if (i === 0) e = 1 - tr(p, cortes[1] - 0.03, cortes[1] + 0.03);
  t.style.opacity = e; t.style.transform = 'translateY(' + (1 - e) * 16 + 'px)'; t.style.filter = 'blur(' + (1 - e) * 8 + 'px)';
});
```

Detalles que la hacen creíble:

- Ventanas con los tres puntos de macOS (`#ff5f57`, `#febc2e`, `#28c840`) y barra de dirección en `--papel`.
- El editor de código oscuro (`#0f1629`) con números de línea por `counter()` y cursor que parpadea.
- Cables SVG con `stroke-dasharray: 2 7` y un punto de luz que los recorre con `<animateMotion>`.
- La flotación (`.flota`) va en el hijo `.win`, no en `.pz`, para no pelear con el `transform` del scroll.

### Movimiento reducido

```css
@media (prefers-reduced-motion: reduce) {
  .vit { height: auto; } .vit__pin { position: relative; } .vit__t:not(:first-of-type) { display: none; }
}
```

Y en JS, con `quieto`, se pinta el estado final (`p = 1`) y se le da al pin la altura del lienzo escalado:
`pin.style.height = (cap + 760 * S + 40) + 'px'`.

## Cuándo NO fijar una sección

- Más de dos secciones fijadas por página. A partir de la tercera el usuario siente que no avanza.
- Contenido que el usuario necesita leer con calma (precios, condiciones, formularios).
- Si no hay al menos tres estados distintos que contar. Para uno o dos, un `.rv` basta.
