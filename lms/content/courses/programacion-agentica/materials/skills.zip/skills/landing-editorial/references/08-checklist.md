# 08 · Checklist antes de publicar

Marca cada punto. Si uno falla, no está terminada.

## Identidad

- [ ] `:root` copiado de 01; solo cambiaron `--azul`, `--azul-2` y `--azul-claro`.
- [ ] Ningún `rgba(37, 99, 235, …)` suelto queda en la página (`grep -n "37, 99, 235"`): el color sale de `var(--azul)`.
- [ ] Titulares en Inter 600–700 con tracking negativo. Ninguna serif fina.
- [ ] Un solo color de marca en la interfaz. Colores extra solo dentro de maquetas de producto.
- [ ] Una sola tarjeta oscura en el bento.

## Movimiento

- [ ] Todas las transiciones y animaciones usan `var(--suave)` (salvo bucles de flotación y la barra de carga).
- [ ] La intro dura menos de 3 s y se salta con clic o tecla.
- [ ] Las entradas combinan desplazamiento + opacidad + desenfoque.
- [ ] Cada sección fijada tiene indicador de avance.
- [ ] Ningún elemento anima `width`, `height`, `top` ni `left`.
- [ ] Un solo listener de scroll y un rAF compartido.
- [ ] El fondo animado, si existía en la versión anterior, sigue ahí.
- [ ] La figura del fondo encaja con el rubro (ver 09) y no compite con los titulares.

## Responsive

- [ ] Revisado a 393 px, 768 px, 1024 px y 1440 px.
- [ ] Sin scroll horizontal en ningún ancho (prueba: `document.documentElement.scrollWidth === innerWidth`).
- [ ] Portada y pines con `100svh`.
- [ ] La vitrina, si la hay, se lee en el teléfono (la cámara se acerca a cada pieza).
- [ ] Campos de formulario a 16 px.

## Accesibilidad

- [ ] Con «Reducir movimiento» activado: sin intro, todo visible, ninguna sección vacía de 400vh.
- [ ] Sin JavaScript: el contenido se lee (los titulares no quedan en gris claro).
- [ ] Un `<h1>`, `<h2>` por sección, decoración con `aria-hidden`.
- [ ] Se puede recorrer con Tab y el foco se ve.
- [ ] Imágenes con `alt`, `width`, `height`.

## Contenido

- [ ] Ninguna cifra, nombre, número de teléfono o testimonio inventado.
- [ ] Titular de portada de 3–5 palabras.
- [ ] Cada párrafo ≤ 25 palabras y en lenguaje de negocio.
- [ ] El formulario abre WhatsApp (o envía al servicio real) con el número verificado por el cliente.
- [ ] `<title>` y `<meta name="description">` reales; `theme-color` en blanco; favicon con el isotipo.

## Técnica

- [ ] La consola del navegador sin errores.
- [ ] Lighthouse móvil: rendimiento ≥ 90, accesibilidad 100.
- [ ] Todos los enlaces `#ancla` llevan a una sección que existe.
- [ ] Enlaces externos con `target="_blank" rel="noopener"`.
- [ ] Ninguna clase CSS se arma con plantilla de texto en JS (`'tj--' + x`): escribirlas completas.
