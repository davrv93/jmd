# 06 · Responsive, accesibilidad y rendimiento

## Estrategia

**Fluido primero, cortes después.** Tipografía, márgenes, huecos y rellenos se escalan con `clamp()`,
así que casi todo funciona sin media queries. Los cortes solo cambian la **estructura** (columnas,
dirección de un hilo, ocultar la nav).

## Cortes usados

| Ancho | Qué cambia |
|---|---|
| `≤ 980px` | Bento: todas las tarjetas a 6 columnas (una por fila) |
| `≤ 880px` | Pasos en columna con el hilo vertical a la izquierda; fundador en una columna; trío de promesas en una columna; se oculta el folio vertical del retrato |
| `< 820px` (JS) | Vitrina: la cámara viaja a cada pieza en vez de mostrar el plano entero; aparece el velo bajo los titulares |
| `≤ 760px` | Se ocultan los enlaces de la nav (quedan logo + botón) |
| `< 700px` (JS) | Fondo animado: `cantidad[0]` figuras en vez de `cantidad[1]`; formación algo más grande en proporción |
| `≤ 640px` | Cifras apiladas con separador horizontal |
| `≤ 560px` | Formulario: nombre y empresa en dos filas |

Usa siempre `minmax(0, 1fr)` en lugar de `1fr` en las retículas: evita que una palabra larga o un
`<pre>` ensanche la columna y cree scroll horizontal.

## Móvil: lo que hay que cuidar

- **`100svh` después de `100vh`** en portada y pines: el `vh` clásico incluye la barra del navegador y la
  sección fijada queda cortada.
- **`overflow-x: clip` en `body`** (no `hidden`): evita el scroll lateral sin romper `position: sticky`.
- **Campos de formulario a `font-size: 1rem`** (16 px): por debajo, iOS hace zoom al enfocar.
- **Nada de hover como única vía:** los efectos de `:hover` son adorno; todo se entiende sin ellos.
- **Titulares de portada a `10.5vw`** con mínimo de 3 rem: en 393 px una palabra de 10 letras cabe en una línea.
  Si tu palabra más larga no cabe, acorta el titular antes que bajar el tamaño.
- **Botones con `white-space: nowrap`** y su contenedor con `flex-wrap: wrap`: se apilan, no se parten.
- **Revisa en un teléfono real o en Chrome a 393 × 852**, no solo en una maqueta. Las secciones fijadas y
  el canvas se comportan distinto con la barra del navegador apareciendo y desapareciendo.

## Movimiento reducido (obligatorio)

Tres capas:

1. **En el `<head>`**: la intro no se activa (`html.arranque` no se añade).
2. **En CSS**: se apagan animaciones y transiciones y se fuerza el estado final de todo lo que empieza oculto.
3. **En JS**: con `quieto = true` no se parten titulares, no rota la palabra, la vitrina pinta su estado
   final, los contadores escriben el número directo y el canvas pinta un solo cuadro.

```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after { animation: none !important; transition: none !important; }
  .titular .pal, .entra, .rv, .glb, .maq > * { opacity: 1 !important; transform: none !important; filter: none !important; }
  .luz .w { color: var(--tinta); }
  .orden { height: auto; padding-block: 5rem; }
  .orden__pin { position: static; height: auto; gap: 2rem; }
  .orden__f { grid-area: auto; opacity: 1; transform: none; filter: none; }
  .retrato__m { clip-path: none; } .retrato figcaption { opacity: 1; transform: none; }
  .hilo i { transform: none; } .promesa svg .tz { stroke-dashoffset: 0; }
  .vit { height: auto; } .vit__pin { position: relative; } .vit__t:not(:first-of-type) { display: none; }
}
```

**Sin JavaScript** la portada y todo `.rv` se quedarían invisibles (esperan `.listo` e `.in`). La
plantilla lo cierra con:

```html
<noscript><style>
  .titular .pal, .entra, .rv { opacity: 1; transform: none; filter: none; }
  .retrato__m { clip-path: none; } .retrato figcaption { opacity: 1; transform: none; }
  .orden { height: auto; } .orden__pin { position: static; height: auto; gap: 2rem; padding-block: 5rem; }
  .orden__f { grid-area: auto; opacity: 1; transform: none; filter: none; }
</style></noscript>
```

**Regla:** cada vez que añadas un elemento que empieza con `opacity: 0`, `clip-path` cerrado o
`stroke-dashoffset`, añádelo a este bloque. Pruébalo activando «Reducir movimiento» en el sistema
(macOS: Accesibilidad → Pantalla) o en DevTools → Rendering → *Emulate prefers-reduced-motion*.

## Accesibilidad

- Un `<h1>` (portada), `<h2>` por sección, `<h3>` en tarjetas y pasos.
- Titulares partidos en trozos animados: `aria-label` con la frase en el padre, `aria-hidden` en los trozos.
- Toda decoración (`.boot`, `canvas`, escenas, hilos, indicadores, lienzo de vitrina) con `aria-hidden="true"`.
- Secciones fijadas con `aria-label` que diga de qué tratan.
- La palabra rotatoria con `aria-live="off"`: que no se anuncie cada 2,6 s.
- `:focus-visible` con anillo de 2 px del color de marca y `outline-offset: 4px`.
- Botón flotante e iconos sin texto con `aria-label`.
- Imágenes con `width`, `height`, `alt` descriptivo y `loading="lazy"` (salvo la de portada si la hay).
- Contraste: párrafos `#6b6b70` sobre blanco ≈ 5.3:1 (pasa AA). `--gris-2` (`#a1a1a6`) solo para notas
  no esenciales: no llega a AA en texto pequeño.

## Rendimiento

- **Solo propiedades compuestas:** `transform`, `opacity`, `filter`, `clip-path`. El `blur` en
  `filter` es caro en superficies grandes: úsalo en texto y piezas, no en secciones enteras.
- **`will-change` solo en lo que se mueve cada cuadro** (portada, frases fijadas, lienzo, piezas de
  vitrina). Ponerlo en todo gasta memoria de GPU.
- **Un listener de scroll, `passive`, un rAF compartido** (ver 03). Nada de `scroll` que escriba estilos
  directamente.
- **Canvas con `devicePixelRatio` topado a 2** y menos figuras en móvil.
- **IntersectionObserver con `unobserve`** tras la entrada: cada elemento se observa una sola vez.
- **Fuente:** solo los pesos que se usan (400, 500, 600, 700) con `display=swap` y `preconnect`.
- **Sin dependencias:** un HTML de ~80 KB sin comprimir es toda la página. No añadas una librería de 40 KB
  para una animación que caben en 10 líneas.
- Presupuesto orientativo: Lighthouse móvil ≥ 90 en rendimiento y 100 en accesibilidad.
