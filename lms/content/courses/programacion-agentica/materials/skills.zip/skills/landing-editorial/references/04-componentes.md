# 04 · Componentes

Cada componente con su HTML mínimo y su CSS. Las animaciones de entrada (`.rv`, `.in`) están en
[02-animaciones.md](02-animaciones.md).

## Navegación de vidrio

```html
<header class="nav" id="nav">
  <a class="logo" href="#inicio" aria-label="Marca, inicio"> <svg …/> <span class="logo__t"><b>MARCA</b><small>SOLUTIONS</small></span></a>
  <nav class="nav__links" aria-label="Secciones"><a href="#servicios">Servicios</a><a href="#metodo">Método</a>…</nav>
  <a class="btn btn--lleno btn--chico" href="#contacto">Conversemos</a>
</header>
```

```css
.nav { position: fixed; inset: 0 0 auto 0; z-index: 50; display: flex; align-items: center; justify-content: space-between; gap: 1rem;
       padding: .85rem var(--margen); background: rgba(255, 255, 255, .72);
       backdrop-filter: saturate(180%) blur(18px); -webkit-backdrop-filter: saturate(180%) blur(18px);
       border-bottom: 1px solid transparent; transition: border-color .4s; }
.nav.pegada { border-color: var(--linea); }
.nav__links { display: flex; gap: clamp(1rem, 2.4vw, 2.25rem); font-size: .86rem; color: var(--gris); }
.nav__links a { position: relative; transition: color .3s; }
.nav__links a:hover { color: var(--tinta); }
@media (max-width: 760px) { .nav__links { display: none; } }   /* en móvil: logo + un botón, sin hamburguesa */
```

```js
var nav = document.getElementById('nav');
function alBajar() { nav.classList.toggle('pegada', scrollY > 12); }
addEventListener('scroll', alBajar, { passive: true }); alBajar();
```

- Cuatro enlaces como máximo. En móvil desaparecen: la página es una sola columna que se recorre bajando.
- El logo: isotipo de trazo (marco redondeado + letra) y logotipo en dos niveles —nombre en 700 con
  `.06em`, subtítulo en 600 a `.5rem` con `.46em` de tracking y en gris—.

## Botones

```css
.btn { display: inline-flex; align-items: center; gap: .6rem; padding: .78rem 1.35rem; border-radius: 999px;
       font-size: .9rem; font-weight: 500; border: 1px solid var(--tinta); white-space: nowrap;
       transition: transform .5s var(--suave), background .3s, color .3s, box-shadow .5s; }
.btn--lleno { background: var(--tinta); color: #fff; }
.btn--lleno:hover { background: var(--azul); border-color: var(--azul); transform: translateY(-2px); box-shadow: 0 14px 30px -12px color-mix(in srgb, var(--azul) 60%, transparent); }
.btn--linea:hover { background: var(--tinta); color: #fff; transform: translateY(-2px); }
.btn svg { width: 1rem; height: 1rem; transition: transform .5s var(--suave); }
.btn:hover svg { transform: translateX(4px); }
.btn--chico { padding: .55rem 1rem; font-size: .82rem; }
```

Flecha del botón principal: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M4 12h16M14 6l6 6-6 6"/></svg>`.

- **En reposo el botón principal es tinta, no color de marca.** El color aparece solo al pasar el ratón: es
  el premio de la interacción, y mantiene la página en blanco y negro.
- Pareja de acciones en portada: `btn--lleno` (la acción) + `btn--linea` (explorar).

## Portada

```css
.portada   { position: relative; min-height: 100vh; min-height: 100svh;
             padding: clamp(6.5rem, 14vh, 9rem) var(--margen) clamp(3rem, 8vh, 5rem);
             display: grid; place-items: center; text-align: center; }
.portada__c { display: grid; justify-items: center; will-change: transform, opacity; }
.portada__meta { display: flex; gap: 1.25rem; flex-wrap: wrap; justify-content: center; margin-bottom: clamp(1.25rem, 3vh, 2rem); }
.titular   { font-size: clamp(3rem, 10.5vw, 10rem); line-height: .94; }
.bajada    { margin-top: clamp(1.25rem, 3vh, 2rem); max-width: 36rem; font-size: clamp(1.02rem, 1.35vw, 1.25rem); color: var(--gris); font-weight: 300; }
.bajada strong { color: var(--tinta); font-weight: 500; }
.portada__acc { margin-top: clamp(1.5rem, 4vh, 2.5rem); display: flex; gap: .75rem; flex-wrap: wrap; justify-content: center; }
```

Orden fijo: ojo → titular (2 líneas) → bajada (1–2 líneas, con una idea en `<strong>`) → palabra rotatoria → dos botones → indicador de scroll.

## Encabezado de sección

```html
<div class="cab">
  <p class="ojo rv"><b>01</b> — Servicios</p>
  <h2 class="h2 serif luz">Cinco formas de ordenar tu empresa. <em>Una sola conversación.</em></h2>
</div>
```

El ojo va numerado en orden de página (`01`…`05`) con raya larga `—`. Da ritmo de revista.

## Bento

```css
.bento { display: grid; grid-template-columns: repeat(6, minmax(0, 1fr)); gap: clamp(.75rem, 1.4vw, 1.25rem); }
.tj { position: relative; grid-column: span 2; border-radius: var(--radio);
      background: rgba(246, 246, 247, .86); backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px);
      padding: clamp(1.25rem, 2.2vw, 2rem); display: flex; flex-direction: column; gap: .75rem;
      min-height: clamp(22rem, 34vw, 30rem); overflow: hidden; isolation: isolate;
      transition: transform .7s var(--suave), box-shadow .7s var(--suave), background .5s; }
.tj:hover { transform: translateY(-6px); box-shadow: 0 40px 70px -40px rgba(11, 18, 32, .35); background: #f1f2f5; }
.tj--ancha { grid-column: span 4; } .tj--mitad { grid-column: span 3; }
.tj--noche { background: var(--noche); color: #fff; } .tj--noche:hover { background: #0f1830; }
.tj--noche .tj__txt { color: rgba(255, 255, 255, .68); } .tj--noche .tj__n { color: rgba(255, 255, 255, .5); }
@media (max-width: 980px) { .tj, .tj--ancha, .tj--mitad { grid-column: span 6; } }
.tj__n   { font-family: var(--mono); font-size: .72rem; color: var(--gris); letter-spacing: .08em; }
.tj__t   { font-weight: 600; font-size: clamp(1.7rem, 3vw, 2.7rem); line-height: 1.02; letter-spacing: -.02em; }
.tj__txt { color: var(--gris); max-width: 30rem; font-size: .98rem; }
.tj__esc { flex: 1; position: relative; min-height: 10rem; margin-top: .5rem; }   /* aquí va la escena */
```

- Retícula de **6 columnas**: combinaciones 4+2, 2+2+2, 3+3. Fila 1: ancha + noche. Fila 2: tres de 2.
- **Una sola tarjeta oscura** (`.tj--noche`) por bento: es el contrapunto. Dos ya es un tablero de ajedrez.
- Orden interno: número en mono → título → una frase → escena que ocupa el resto (`flex: 1`).

### Escenas del bento

Cada escena es decorativa (`aria-hidden` implícito en `<i>` vacíos, o `aria-hidden="true"` en el SVG)
y explica el servicio sin palabras.

**Módulos que encajan** (software a medida): piezas que llegan giradas desde fuera y encajan en una retícula.

```css
.mod { position: absolute; inset: 0; display: grid; grid-template-columns: repeat(4, 1fr); grid-auto-rows: 1fr; gap: 10px; max-width: 30rem; margin-inline: auto; }
.mod i { border-radius: 12px; background: #fff; border: 1px solid var(--linea); box-shadow: 0 10px 22px -16px rgba(11, 18, 32, .4);
         animation: encaja 7s var(--suave) infinite; animation-delay: calc(var(--m) * 110ms);
         display: grid; place-items: center; font-style: normal; font-size: .62rem; letter-spacing: .08em; text-transform: uppercase; color: var(--gris); }
.mod i:nth-child(3) { background: var(--azul); border-color: var(--azul); color: #fff; }   /* una pieza de marca */
.mod i:nth-child(6) { background: var(--tinta); border-color: var(--tinta); color: #fff; } /* una pieza de tinta */
.mod .a2 { grid-column: span 2 }
@keyframes encaja { 0%, 6% { opacity: 0; transform: translate(var(--x), var(--y)) rotate(var(--r)) scale(.7) } 26%, 84% { opacity: 1; transform: none } 100% { opacity: 0; transform: scale(.9) } }
```
```html
<i style="--m:0;--x:-60px;--y:-40px;--r:-12deg" class="a2">Ventas</i><i style="--m:1;--x:40px;--y:-60px;--r:9deg">Stock</i> …
```

**Chat que escribe** (chatbots): teléfono cortado por abajo, burbujas que aparecen cada 1,25 s y tres puntos «escribiendo».

```css
.tel { position: absolute; inset: 0 auto 0 50%; translate: -50% 0; width: min(100%, 17rem); border-radius: 26px 26px 0 0;
       background: #fff; padding: 14px 12px 0; display: flex; flex-direction: column; gap: 8px; box-shadow: 0 30px 60px -30px rgba(0,0,0,.7); overflow: hidden; }
.glb { max-width: 84%; padding: 7px 10px; border-radius: 12px; font-size: .72rem; line-height: 1.35; color: var(--tinta);
       opacity: 0; animation: glb 9s var(--suave) infinite; animation-delay: calc(var(--g) * 1.25s); }
.glb--yo  { align-self: flex-end;   background: #dcf8c6;      border-bottom-right-radius: 3px; }  /* verde WhatsApp */
.glb--bot { align-self: flex-start; background: var(--papel); border-bottom-left-radius: 3px; }
.glb--bot.pts { display: flex; gap: 4px; padding: 10px 12px; }
.glb--bot.pts i { width: 5px; height: 5px; border-radius: 50%; background: var(--gris-2); animation: pto 1s infinite; }
.glb--bot.pts i:nth-child(2) { animation-delay: .15s } .glb--bot.pts i:nth-child(3) { animation-delay: .3s }
@keyframes glb { 0% { opacity: 0; transform: translateY(10px) scale(.94) } 6%, 88% { opacity: 1; transform: none } 96%, 100% { opacity: 0 } }
@keyframes pto { 30% { transform: translateY(-3px) } }
```

**Maqueta que se arma** (landings): bloques grises/tinta/azul que crecen de izquierda a derecha y una etiqueta de éxito al final.

```css
.maq { position: absolute; inset: 0; margin-inline: auto; max-width: 22rem; border-radius: 14px 14px 0 0; background: #fff;
       border: 1px solid var(--linea); border-bottom: 0; padding: 12px; display: grid; gap: 9px; align-content: start; }
.maq > * { transform-origin: left; animation: arma 7s var(--suave) infinite; animation-delay: calc(var(--q) * .28s); }
@keyframes arma { 0%, 4% { opacity: 0; transform: scaleX(.2) } 18%, 88% { opacity: 1; transform: none } 100% { opacity: 0 } }
```
Bloques: nav 8px al 40 %, titular 16px al 82 % y al 56 % en tinta, párrafo 7px al 70 %, botón 24px al 42 % en marca, y `+1 contacto nuevo` en píldora azul clara.

**Dato que recorre una red** (transformación digital): SVG con nodos y un punto que viaja por el camino.

```html
<svg class="red" viewBox="0 0 300 170" aria-hidden="true">
  <path id="ruta" d="M40 120 L110 50 L190 110 L260 46" fill="none"/>
  <line …/>  <circle class="n" …/> … <circle class="n n--az" cx="260" cy="46" r="13"/>
  <text x="40" y="150">Papel</text> … <text x="260" y="24">Decisión</text>
  <circle class="dato" r="5"><animateMotion dur="4s" repeatCount="indefinite" keyPoints="0;1" keyTimes="0;1"
          calcMode="spline" keySplines=".5 0 .2 1"><mpath href="#ruta"/></animateMotion></circle>
</svg>
```
Líneas `stroke-dasharray: 5 5` en `--linea`; nodos blancos con borde tinta; el último, en color de marca.

**Barras que suben** (capacitación): cinco columnas en degradado de marca, con un círculo encima (la persona), que crecen escalonadas.

```css
.eq u { display: block; width: 100%; border-radius: 10px 10px 4px 4px; background: linear-gradient(180deg, var(--azul), var(--azul-2));
        height: calc(var(--n) * 1.1px); transform-origin: bottom; animation: nivel 6s var(--suave) infinite; animation-delay: calc(var(--e) * .2s); }
@keyframes nivel { 0%, 8% { transform: scaleY(.18) } 40%, 86% { transform: scaleY(1) } 100% { transform: scaleY(.18) } }
```

## Cifras

```css
.cifras { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); border-block: 1px solid var(--linea); padding-block: 0; }
.cifra  { padding: clamp(2rem, 5vw, 4rem) clamp(.5rem, 2vw, 2rem); text-align: center; border-left: 1px solid var(--linea); }
.cifra:first-child { border-left: 0; }
.cifra b { display: block; font-weight: 600; font-size: clamp(2.8rem, 9vw, 8rem); line-height: 1; letter-spacing: -.03em;
           font-variant-numeric: tabular-nums; background: var(--degradado); -webkit-background-clip: text; background-clip: text; color: transparent; }
.cifra b sup { font-size: .4em; vertical-align: top; margin-left: .05em; }
.cifra > span { font-size: clamp(.68rem, 1vw, .8rem); letter-spacing: .16em; text-transform: uppercase; color: var(--gris); }
@media (max-width: 640px) { .cifras { grid-template-columns: 1fr; } .cifra { border-left: 0; border-top: 1px solid var(--linea); } .cifra:first-child { border-top: 0; } }
```

Tres cifras, nunca cuatro. Solo cifras reales que dio el cliente.

## Método en pasos

```html
<div class="pasos rv" id="pasos">
  <div class="hilo" aria-hidden="true"><i></i></div>
  <div class="paso"><span class="paso__p" style="--p:0"></span><small>01 · 45 minutos, sin costo</small><h3>Escuchamos</h3><p>…</p></div>
  …
</div>
```

```css
.pasos { position: relative; display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: clamp(1rem, 2.5vw, 2.5rem); }
.hilo  { position: absolute; left: 0; right: 0; top: 13px; height: 2px; background: var(--linea); overflow: hidden; }
.paso  { position: relative; display: grid; gap: .6rem; align-content: start; }
.paso__p { width: 28px; height: 28px; border-radius: 50%; background: #fff; border: 2px solid var(--linea); display: grid; place-items: center; z-index: 1;
           transition: border-color .6s, background .6s; transition-delay: calc(var(--p) * .45s + .3s); }
.paso__p::after { content: ""; width: 8px; height: 8px; border-radius: 50%; background: var(--linea); transition: background .6s, transform .6s var(--suave); transition-delay: inherit; }
.pasos.in .paso__p { border-color: var(--azul); } .pasos.in .paso__p::after { background: var(--azul); transform: scale(1.2); }
.paso small { font-family: var(--mono); font-size: .7rem; color: var(--azul); letter-spacing: .08em; }
@media (max-width: 880px) {   /* el hilo pasa a vertical, a la izquierda */
  .pasos { grid-template-columns: minmax(0, 1fr); }
  .hilo { left: 13px; right: auto; top: 0; bottom: 0; width: 2px; height: auto; }
  .hilo i { height: 100%; transform: scaleY(0); transform-origin: top; } .pasos.in .hilo i { transform: scaleY(1); }
  .paso { padding-left: 3rem; } .paso__p { position: absolute; left: 0; }
}
```

Verbos en primera persona plural, una palabra: Escuchamos · Proponemos · Construimos · Acompañamos.

## Persona (fundador)

```css
.fundador { display: grid; grid-template-columns: minmax(0, .9fr) minmax(0, 1.1fr); gap: clamp(2rem, 6vw, 6rem); align-items: center; }
.retrato figcaption { position: absolute; left: clamp(.75rem, 2vw, 1.5rem); bottom: clamp(.75rem, 2vw, 1.5rem); padding: .7rem 1rem; border-radius: 16px;
                      background: rgba(255, 255, 255, .82); backdrop-filter: blur(14px); font-size: .8rem; line-height: 1.3; }
.retrato::after { content: "N.º 01"; position: absolute; right: -1.5rem; top: 1.5rem; writing-mode: vertical-rl;
                  font-family: var(--mono); font-size: .7rem; letter-spacing: .2em; color: var(--gris-2); }   /* folio de revista */
.lista { list-style: none; margin: 0; padding: 0; border-top: 1px solid var(--linea); counter-reset: l; }
.lista li { display: flex; gap: 1rem; align-items: baseline; padding: .9rem 0; border-bottom: 1px solid var(--linea); font-size: .98rem; }
.lista li::before { content: counter(l, decimal-leading-zero); counter-increment: l; font-family: var(--mono); font-size: .7rem; color: var(--azul); }
@media (max-width: 880px) { .fundador { grid-template-columns: minmax(0, 1fr); } .retrato::after { display: none; } }
```

La cita va entre comillas latinas «…» con la segunda mitad en `<em>`. Foto 4:5, `object-position: 50% 30%`.

## Promesas (confianza)

Tres tarjetas blancas sobre banda `--papel` (`rgba(246, 246, 247, .8)`), cada una con un icono de línea de 40 px
(`stroke: var(--azul); stroke-width: 1.5; fill: none`) que se dibuja al entrar. Título de dos o tres palabras y una frase.

## Cierre y formulario

```css
.cierre { position: relative; text-align: center; padding-block: clamp(9rem, 22vw, 17rem); }
.cierre h2 { font-size: clamp(3.2rem, 13vw, 12rem); line-height: .9; }
.form { max-width: 34rem; margin: 0 auto; display: grid; gap: .9rem; text-align: left; }
.form .fila { display: grid; gap: .9rem; grid-template-columns: 1fr 1fr; }
@media (max-width: 560px) { .form .fila { grid-template-columns: 1fr; } }
.form label { display: grid; gap: .35rem; font-size: .78rem; letter-spacing: .04em; color: var(--gris); }
.form input, .form textarea, .form select { font: inherit; font-size: 1rem; /* 16px: iOS no hace zoom */ color: var(--tinta); background: #fff;
  border: 1px solid var(--linea); border-radius: 14px; padding: .8rem 1rem; width: 100%; transition: border-color .3s, box-shadow .3s; }
.form input:focus, .form textarea:focus, .form select:focus { outline: none; border-color: var(--azul); box-shadow: 0 0 0 4px color-mix(in srgb, var(--azul) 12%, transparent); }
.form .error { color: #b91c1c; font-size: .82rem; text-align: center; margin: 0; min-height: 1.1em; }  /* reserva su alto: nada salta */
.form .nota  { text-align: center; font-size: .8rem; color: var(--gris-2); margin: 0; }
```

Formulario sin servidor que abre WhatsApp con el mensaje ya redactado (no hay nada que se caiga):

```js
f.addEventListener('submit', function (ev) {
  ev.preventDefault();
  var d = new FormData(f), nombre = (d.get('nombre') || '').trim();
  if (!nombre) { err.textContent = 'Escribe tu nombre para saber con quién hablamos.'; f.nombre.focus(); return; }
  err.textContent = '';
  var lineas = ['Hola, soy ' + nombre + ((d.get('empresa') || '').trim() ? ' de ' + d.get('empresa').trim() : '') + '.',
                'Necesito: ' + d.get('servicio') + '.'];
  if ((d.get('detalle') || '').trim()) lineas.push(d.get('detalle').trim());
  window.open('https://wa.me/<NUMERO>?text=' + encodeURIComponent(lineas.join('\n\n')), '_blank', 'noopener');
});
```

- Solo el nombre es obligatorio. Empresa «Opcional» en el *placeholder*. Un `<select>` con 4–5 necesidades
  en lenguaje del cliente y una opción «Otro / aún no lo tengo claro».
- Mensaje de error en segunda persona y explicando el porqué, en un `role="alert"`.
- Nota bajo el botón que dice qué va a pasar: «Se abre WhatsApp con tu mensaje listo para enviar».
- `<NUMERO>` en formato internacional sin `+` ni espacios (`51…`). Pídelo siempre al cliente: nunca lo inventes.

## Botón flotante de WhatsApp

```css
.wsp { position: fixed; right: clamp(14px, 3vw, 28px); bottom: clamp(14px, 3vw, 28px); z-index: 60; width: 56px; height: 56px; border-radius: 50%;
       background: #25d366; color: #fff; display: grid; place-items: center; box-shadow: 0 14px 30px -10px rgba(37, 211, 102, .7); transition: transform .4s var(--suave); }
.wsp:hover { transform: translateY(-3px) scale(1.04); }
```

Con `aria-label="Escríbenos por WhatsApp"`, `target="_blank" rel="noopener"`. Es el único verde de interfaz permitido.

## Pie

```css
footer { padding: 1.5rem var(--margen) 2rem; border-top: 1px solid var(--linea); display: flex; justify-content: space-between;
         gap: 1rem; flex-wrap: wrap; font-size: .78rem; color: var(--gris); }
```

Dos cosas: `© año · Marca · lo que hace` y `Volver arriba ↑`. Nada más.
