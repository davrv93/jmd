# 05 · Fondo animado (A17): figuras × movimientos × formaciones

Un único `<canvas>` fijo detrás de toda la página dibuja figuras que se mueven solas. Al llegar a
ciertas secciones, las figuras **dejan de moverse libres y se ordenan** en una formación alrededor
del titular. La idea visual: del desorden al orden, de las dudas a la solución.

El motor completo está en [plantilla/index.html](../plantilla/index.html), bloque «Fondo vivo
configurable». Se maneja con un solo objeto:

```js
var FONDO = {
  figura: 'hoja',          // ver catálogo de figuras
  movimiento: 'caer',      // ver catálogo de movimientos
  formacion: 'espiral',    // ver catálogo de formaciones; '' = nunca se ordenan
  ordenar: ['#orden', '#contacto'],   // secciones donde se ordenan
  cantidad: [26, 46],      // [móvil, escritorio]
  hueco: 0.38,             // fracción de figuras solo en contorno (0 = todas llenas)
  tamano: 1, opacidad: 1,  // multiplicadores
  paralaje: true,          // las cercanas reaccionan más al scroll
  cursor: ''               // '' | 'repele' | 'atrae'  (solo con ratón, nunca en táctil)
  // color: [r, g, b], oscuro: [r, g, b], claro: [r, g, b]  → por defecto salen de --azul, --azul-2 y --azul-claro
};
```

`figura: ''` apaga el fondo. Con movimiento reducido se pinta un solo cuadro quieto.

## Figuras

Todas usan el color de marca con su degradado. «Giro 3D» = se aplanan y dan la vuelta mientras se
mueven, como una hoja o un papel. «Fija» = nunca rota (no tendría sentido una cruz torcida).

| Figura | Cómo es | Giro 3D | Va bien con |
|---|---|---|---|
| `hoja` | Hoja con nervadura y un nodo | sí | tecnología con calidez, consultoría, naturaleza, bienestar |
| `burbuja` | Esfera translúcida con brillo | fija | bebidas, limpieza, spa, lavandería, piscinas, niños |
| `modulo` | Cuadrado redondeado con punto interior | sí | software, apps, construcción, logística, arquitectura |
| `nodo` | Punto con dos enlaces | fija | redes, datos, IA, telecomunicaciones, comunidad |
| `chispa` | Destello de cuatro puntas | sí | belleza, joyería, IA, lanzamientos, productos premium |
| `gota` | Gota con reflejo | no | agua, bebidas, salud, laboratorio, cosmética |
| `grano` | Grano de café o semilla | sí | cafetería, panadería, agro, alimentos, chocolate |
| `anillo` | Aro de trazo grueso | sí | joyería, bodas, eventos, comunidad, gimnasios |
| `trazo` | Línea con punta redonda | no | logística, envíos, transporte, velocidad, deporte |
| `confeti` | Tira de papel en dos tonos | sí | eventos, fiestas, niños, educación inicial, promociones |
| `cruz` | Cruz redondeada | fija | clínica, farmacia, veterinaria, salud, seguros |

## Movimientos

| Movimiento | Qué hace | Sensación | Figuras naturales |
|---|---|---|---|
| `caer` | Bajan despacio con vaivén lateral y giran | calma, otoño, ligereza | hoja, confeti, grano, chispa |
| `subir` | Ascienden con un balanceo suave | frescura, efervescencia, mejora | burbuja, gota, cruz, chispa |
| `deriva` | Vagan sin rumbo, cambiando de dirección poco a poco | flotación, espacio, laboratorio | nodo, modulo, burbuja |
| `orbita` | Giran en elipse alrededor del centro de la pantalla | sistema, ecosistema, conexión | nodo, anillo, trazo, modulo |
| `onda` | Avanzan a la derecha siguiendo una ola | flujo, mar, música, envíos | trazo, gota, hoja |
| `quieto` | No se desplazan, solo rotan muy lento | sobriedad; fondo casi estático | cualquiera; ideal en intensidad sobria |

Todos los movimientos libres envuelven la pantalla con módulo: lo que sale por un lado entra por el
otro, y un scroll rápido nunca deja el fondo vacío.

## Formaciones

Dónde se colocan cuando el scroll llega a una sección de `ordenar`. Llegan **en ola**: cada figura
un poco después que la anterior.

| Formación | Forma | Deja el centro libre | Cuándo usarla |
|---|---|---|---|
| `espiral` | Espiral de ángulo áureo en anillo, girando lento | sí | por defecto; parece una turbina, no una flor |
| `anillo` | Círculo perfecto que gira | sí | sellos, comunidad, ciclos, «todo conectado» |
| `rejilla` | Cuadrícula ordenada, todas de frente | **no** | orden, método, software; solo con titulares cortos u `opacidad` ≤ .7 |
| `onda` | Una ola horizontal que ondula | casi | flujo, procesos, música, mar |
| `''` | No se ordenan nunca | — | intensidad media sin secciones fijadas |

En una sección fijada (más alta que 1,5 pantallas) la formación sigue el progreso del scroll y se
deshace al final. En una sección normal se forma cuando su centro pasa por el centro de la pantalla.

## Combinaciones probadas

| Rubro | Figura | Movimiento | Formación |
|---|---|---|---|
| Consultoría o software | `hoja` o `modulo` | `caer` / `deriva` | `espiral` / `rejilla` |
| Cafetería, panadería | `grano` | `caer` | `espiral` |
| Bebidas, spa, limpieza | `burbuja` | `subir` | `anillo` |
| Clínica, farmacia | `cruz` | `subir` | `anillo` |
| Belleza, joyería | `chispa` o `anillo` | `deriva` | `espiral` |
| Datos, IA, telecom | `nodo` | `orbita` | `anillo` |
| Logística, envíos | `trazo` | `onda` | `onda` |
| Eventos, niños | `confeti` | `caer` | `espiral` |

Más detalle por rubro en [09-recetas-por-negocio.md](09-recetas-por-negocio.md).

## Reglas de uso

- **Una figura por página.** Mezclar figuras parece un salvapantallas.
- **26 figuras en móvil y 46 en escritorio** como máximo. Más figuras compiten con el titular.
- **30–40 % huecas** (`hueco`): aligera el conjunto. `confeti` y `anillo` lo ignoran.
- **Las tarjetas encima del fondo llevan vidrio:** `background: rgba(246, 246, 247, .86); backdrop-filter: blur(10px)`.
- **Máximo dos secciones en `ordenar`:** el problema (S3) y el cierre (S10).
- **`cursor` solo en intensidad espectáculo.** Y nunca `atrae` con figuras grandes: tapan el texto
  que el usuario intenta leer.
- Si al cliente le gusta el fondo, **se conserva** en cada iteración de la página.

## Montaje

```html
<canvas id="fondo" aria-hidden="true"></canvas>
```

```css
#fondo { position: fixed; inset: 0; width: 100%; height: 100%; z-index: -1; pointer-events: none; }
html { background: var(--blanco); } body { background: transparent; }
```

Detalles del motor que no hay que romper:

- `devicePixelRatio` con tope de 2: nítido en retina sin gastar de más.
- `dt` con tope de 50 ms: al volver de otra pestaña las figuras no pegan un salto.
- Al redimensionar solo se resiembra si el ancho cambió más de 80 px. En móvil la barra del
  navegador cambia el alto todo el rato, y resembrar haría parpadear el fondo.
- El cursor se suaviza con un desplazamiento aparte (`p.ex`, `p.ey`) que no altera el movimiento.
- El color se lee de `--azul`, `--azul-2` y `--azul-claro` con `getComputedStyle`: cambiar la marca en `:root` basta.

## Crear una figura nueva

Añade una entrada a `FIG`. Se dibuja en el origen, apuntando hacia arriba, con medio largo `L`, y
recibe la opacidad `a`. `relleno(p, L, a)` pinta el degradado de marca o solo el contorno si la
figura es hueca.

```js
// Hoja de ginkgo: abanico con muesca
ginkgo: { giro3d: true, dibujar: function (p, L, a) {
  cx.beginPath(); cx.moveTo(0, L);
  cx.quadraticCurveTo(-L * 0.9, -L * 0.2, -L * 0.6, -L * 0.75);
  cx.quadraticCurveTo(-L * 0.2, -L, 0, -L * 0.55);       // muesca
  cx.quadraticCurveTo(L * 0.2, -L, L * 0.6, -L * 0.75);
  cx.quadraticCurveTo(L * 0.9, -L * 0.2, 0, L);
  relleno(p, L, a);
} },
```

Claves: `giro3d: true` si es plana y puede dar la vuelta; `fija: true` si debe ir siempre derecha.
Mide visualmente con `figura: 'ginkgo', movimiento: 'quieto', formacion: 'rejilla'`.

## Crear un movimiento nuevo

Añade una entrada a `MOV`. Recibe la figura `p`, el paso `dt` en segundos, el tiempo `s` y el
desplazamiento por paralaje `par`. Escribe `p.x`, `p.y` y, si quiere, `p.rot`. Usa `env(v, tamaño)`
para envolver la pantalla.

```js
// Espiral hacia el centro, como un remolino
remolino: function (p, dt, s) {
  p.ang += (0.15 + p.z * 0.2) * dt; p.radio -= 6 * dt;
  if (p.radio < 20) p.radio = Math.hypot(W, H) * 0.55;    // reaparece por fuera
  p.x = W / 2 + Math.cos(p.ang) * p.radio; p.y = H / 2 + Math.sin(p.ang) * p.radio * 0.72;
  p.rot = p.ang + 1.5708;
},
```

Datos disponibles en cada figura: `x, y, y0, z` (profundidad 0–1), `v` (velocidad), `fase`, `mece`
(amplitud), `rot, vr, giro, vg`, `ang, radio, sentido`, `hueco`, `tono`.

## Crear una formación nueva

Añade una entrada a `FORM`. Recibe el índice `i`, el tiempo `s`, el centro `x0, y0` y el radio `R`.
Devuelve `[x, y, rotación]`. `K` es el número de figuras.

```js
// Corazón
corazon: function (i, s, x0, y0, R) {
  var t = i / K * TAU, k = R / 17;
  return [x0 + 16 * Math.pow(Math.sin(t), 3) * k,
          y0 - (13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t)) * k, t];
},
```
