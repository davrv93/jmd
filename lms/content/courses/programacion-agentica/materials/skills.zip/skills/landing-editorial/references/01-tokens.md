# 01 · Tokens: color, tipografía, espacio

Copia este bloque tal cual. Para otra marca cambia **solo** `--azul`, `--azul-2` y `--azul-claro`
(ver «Cambiar de marca» abajo y la tabla de colores por rubro en [09](09-recetas-por-negocio.md)). Los nombres están en castellano a propósito: así se llaman en la
referencia y así se buscan.

```css
:root {
  --blanco: #ffffff;
  --papel:  #f6f6f7;   /* fondo de tarjetas y bandas */
  --tinta:  #0a0a0b;   /* titulares, botón lleno, isotipo */
  --gris:   #6b6b70;   /* párrafos, enlaces de la nav, ojos */
  --gris-2: #a1a1a6;   /* notas, detalles verticales */
  --linea:  #e7e7ea;   /* bordes y separadores de 1px */
  --azul:   #2563eb;   /* EL color de marca: foco, selección, acentos */
  --azul-2: #1e3a8a;   /* su versión profunda */
  --azul-claro: #60a5fa; /* su versión luminosa: final del degradado */
  --noche:  #0b1220;   /* la única tarjeta oscura del bento */
  --sans: "Inter", -apple-system, BlinkMacSystemFont, "SF Pro Display", "Segoe UI", sans-serif;
  --mono: ui-monospace, "SF Mono", Menlo, monospace;
  --degradado: linear-gradient(100deg, var(--azul-2) 0%, var(--azul) 45%, var(--azul-claro) 100%);
  --margen: clamp(1rem, 5vw, 5.5rem);   /* margen lateral de TODA la página */
  --suave: cubic-bezier(.16, 1, .3, 1); /* la única curva */
  --radio: 28px;                        /* tarjetas grandes, retrato */
}
```

Carga de Inter (solo los pesos usados):

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap">
```

## Base

```css
*, *::before, *::after { box-sizing: border-box; }
html { -webkit-text-size-adjust: 100%; scroll-behavior: smooth; background: var(--blanco); }
body { margin: 0; background: transparent; /* deja ver el canvas fijo del fondo */
       color: var(--tinta); font-family: var(--sans); font-weight: 400; line-height: 1.55;
       overflow-x: clip; -webkit-font-smoothing: antialiased; }
img, svg { display: block; max-width: 100%; }
a { color: inherit; text-decoration: none; }
h1, h2, h3, p { margin: 0; }
::selection { background: var(--azul); color: #fff; }
:focus-visible { outline: 2px solid var(--azul); outline-offset: 4px; border-radius: 6px; }
```

- `overflow-x: clip` y no `hidden`: `hidden` rompe `position: sticky` en los hijos.
- El fondo blanco va en `html` y el `body` es transparente para que un `<canvas>` con
  `z-index: -1` se vea por detrás del contenido.

## Escala tipográfica

Todo con `clamp(mín, preferido-en-vw, máx)`. Esta es la escala completa de la referencia:

| Uso | Clase | Tamaño | Alto de línea | Peso / tracking |
|---|---|---|---|---|
| Titular de portada | `.titular` | `clamp(3rem, 10.5vw, 10rem)` | .94 | 600 / -.045em |
| Titular del cierre | `.cierre h2` | `clamp(3.2rem, 13vw, 12rem)` | .9 | 600 / -.045em |
| Frase fijada | `.orden__f` | `clamp(2.2rem, 7vw, 6.4rem)`, `max-width: 12ch` | .98 | 600 / -.045em |
| Cifra | `.cifra b` | `clamp(2.8rem, 9vw, 8rem)` | 1 | 600 / -.03em, `tabular-nums` |
| Titular de sección | `.h2` | `clamp(2.3rem, 6vw, 5.4rem)` | .98 | 600 / -.045em |
| Cita | `.cita` | `clamp(2rem, 4.6vw, 4.2rem)` | 1.02 | 600 / -.045em |
| Titular de vitrina | `.vit__t` | `clamp(1.7rem, 4.6vw, 3.9rem)`, `max-width: 17ch` | 1 | 600 / -.045em |
| Título de tarjeta | `.tj__t` | `clamp(1.7rem, 3vw, 2.7rem)` | 1.02 | 600 / -.02em |
| Título de paso / promesa | `h3` | `clamp(1.5rem, 2.4vw, 2.1rem)` | 1.05 | 600 / -.035em |
| Bajada de portada | `.bajada` | `clamp(1.02rem, 1.35vw, 1.25rem)`, `max-width: 36rem` | 1.55 | 300, gris |
| Párrafo | `p` | `.96rem`–`1.05rem` | 1.55 | 400, gris |
| Ojo (antetítulo) | `.ojo` | `.72rem`, MAYÚSCULAS | — | 400 / .2em, gris |
| Numeración técnica | `.tj__n`, `.paso small` | `.7rem`–`.72rem`, `--mono` | — | .08em |

Reglas de la escala:

- **Grande y pesado se aprieta; pequeño y en mayúsculas se abre.** Titulares a `-.045em`;
  ojos y subtítulos a `+.2em`. Nunca al revés.
- **El `ch` manda en titulares partidos:** `max-width: 12ch` fuerza 2–3 líneas equilibradas sin `<br>`.
- **Números con `font-variant-numeric: tabular-nums`** para que los contadores no bailen.
- Un solo `<h1>` (la portada). Los demás titulares son `<h2>` aunque visualmente midan más.

## Clases tipográficas utilitarias

```css
.ojo   { font-size: .72rem; letter-spacing: .2em; text-transform: uppercase; color: var(--gris); }
.ojo b { color: var(--azul); font-weight: 500; }       /* «<b>01</b> — Servicios» */
.serif { font-family: var(--sans); font-weight: 600; letter-spacing: -.045em; } /* nombre heredado: ya NO es serif */
.serif em, .az { font-style: normal; background: var(--degradado);
                 -webkit-background-clip: text; background-clip: text; color: transparent; }
```

`<em>` dentro de un titular **no es cursiva**: es la parte que se pinta con el degradado de marca.
Úsalo para la segunda mitad de la frase, la que trae la solución:
`Cinco formas de ordenar tu empresa. <em>Una sola conversación.</em>`

## Espacio

- Sección: `padding: clamp(4.5rem, 11vw, 9rem) var(--margen);`
- Cierre: `padding-block: clamp(9rem, 22vw, 17rem);` (el doble: el final respira).
- Encabezado de sección (`.cab`): `display: grid; gap: 1rem; margin-bottom: clamp(2rem, 5vw, 4rem); max-width: 58rem;`
- Huecos de retícula: `clamp(.75rem, 1.4vw, 1.25rem)` en bento, `clamp(1rem, 2.5vw, 2.5rem)` en pasos.
- Portada: `min-height: 100vh; min-height: 100svh;` (las dos: `svh` para la barra del navegador móvil).

## Radios

| Elemento | Radio |
|---|---|
| Tarjeta grande, retrato | `var(--radio)` = 28px |
| Ventana de maqueta | 16px; teléfono 34px |
| Campo de formulario, figcaption | 14–16px |
| Botón, píldora, chip de estado | 999px |
| Mini piezas dentro de escenas | 10–12px |

## Sombras

Largas, muy desplazadas hacia abajo y con *spread* negativo: flotan sin ensuciar el blanco.

```css
/* reposo de una ventana de maqueta */
box-shadow: 0 46px 90px -46px rgba(11, 18, 32, .45), 0 16px 34px -20px rgba(11, 18, 32, .2);
/* hover de tarjeta */
box-shadow: 0 40px 70px -40px rgba(11, 18, 32, .35);
/* hover de botón lleno: sombra del color de marca (sigue a --azul) */
box-shadow: 0 14px 30px -12px color-mix(in srgb, var(--azul) 60%, transparent);
/* pieza pequeña dentro de una escena */
box-shadow: 0 10px 22px -16px rgba(11, 18, 32, .4);
```

Una ventana oscura o de color usa su propio tono en la sombra
(`rgba(124, 58, 237, .6)` para la de código violeta, `rgba(16, 185, 129, .55)` para el teléfono verde).

## Vidrio

```css
background: rgba(255, 255, 255, .72);
backdrop-filter: saturate(180%) blur(18px);
-webkit-backdrop-filter: saturate(180%) blur(18px);
```

Navegación: 18px. Tarjetas sobre el fondo vivo: `rgba(246, 246, 247, .86)` + `blur(10px)`.
Pie de foto: `rgba(255, 255, 255, .82)` + `blur(14px)`.

## Colores de producto (solo dentro de maquetas)

```css
--c-azul: #2563eb; --c-viol: #7c3aed; --c-verde: #10b981;
--c-ambar: #f59e0b; --c-rosa: #ec4899; --c-cian: #06b6d4;
```

Para fondos suaves de iconos y etiquetas, mezcla el color con blanco en lugar de inventar tonos:
`background: color-mix(in srgb, var(--k) 14%, #fff); color: var(--k);`
Para el texto de una etiqueta: `color-mix(in srgb, var(--k) 70%, #0a0a0b)`.

## Cambiar de marca

1. Pon el color principal en `--azul` (el nombre se queda; es «el color»).
2. `--azul-2`: el mismo tono, unos 35–40 puntos más oscuro en luminosidad.
3. `--azul-claro`: el mismo tono, unos 20 puntos más luminoso. `--degradado` se arma solo con los tres.
4. No escribas el color de marca en `rgba()` sueltos: usa `color-mix(in srgb, var(--azul) 60%, transparent)`.
   El fondo animado lee `--azul` y `--azul-2` solo. Comprueba con `grep -n "37, 99, 235"` que no quedan restos.
5. Comprueba contraste: el principal sobre blanco debe dar al menos 4.5:1 si se usa en texto pequeño
   (`.ojo b`, `.paso small`).
