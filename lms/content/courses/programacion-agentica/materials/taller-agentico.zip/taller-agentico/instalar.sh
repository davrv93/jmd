#!/usr/bin/env bash
# Instala los skills del taller para cada familia de modelo.
#
#   bash instalar.sh [carpeta-destino] [--solo-prompts]
#
# - Copia skills/<nombre>/SKILL.md a ~/.claude/skills/<nombre>/SKILL.md
#   (todas las carpetas que existan, menos _perfiles).
# - Genera <destino>/AGENTS.md con la "Version corta para modelos pequenos"
#   de cada skill, para Codex / GPT.
# - Genera <destino>/prompts/<skill>.txt con esa misma version corta, para
#   usar como system prompt en Ollama / DeepSeek / GLM / Nemotron.
#
# Idempotente: se puede ejecutar las veces que haga falta.

set -euo pipefail

AQUI="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILLS_DIR="$AQUI/skills"
CLAUDE_SKILLS="${CLAUDE_SKILLS_DIR:-$HOME/.claude/skills}"

DESTINO="."
SOLO_PROMPTS=0
for arg in "$@"; do
  case "$arg" in
    --solo-prompts) SOLO_PROMPTS=1 ;;
    -h|--help)
      sed -n '2,13p' "$0" | sed 's/^# \{0,1\}//'
      exit 0
      ;;
    *) DESTINO="$arg" ;;
  esac
done

mkdir -p "$DESTINO"
DESTINO="$(cd "$DESTINO" && pwd)"
PROMPTS_DIR="$DESTINO/prompts"
AGENTS="$DESTINO/AGENTS.md"

if [ ! -d "$SKILLS_DIR" ]; then
  echo "No existe $SKILLS_DIR; nada que instalar." >&2
  exit 1
fi

# Recoge los skills disponibles (carpetas con SKILL.md, sin _perfiles).
skills=()
for dir in "$SKILLS_DIR"/*/; do
  [ -d "$dir" ] || continue
  nombre="$(basename "$dir")"
  [ "$nombre" = "_perfiles" ] && continue
  [ -f "$dir/SKILL.md" ] || continue
  skills+=("$nombre")
done

if [ "${#skills[@]}" -eq 0 ]; then
  echo "No hay ningun skills/<nombre>/SKILL.md todavia. Nada que instalar." >&2
  exit 0
fi

# Extrae desde el encabezado que contiene "Version corta" (con o sin tilde)
# hasta el final del archivo. Si no existe, devuelve el cuerpo sin frontmatter.
# Se usa grep + tail y no awk: el awk de macOS ignora IGNORECASE. El patron
# lleva ".*" y no "." porque, en locale C, "ó" ocupa dos bytes y un punto solo
# casa uno (el grep BSD del sistema fallaba en silencio con "Versión").
version_corta() {
  local archivo="$1" linea
  # "|| true": sin coincidencia grep sale con 1 y pipefail abortaria el script.
  linea="$( { grep -niE '^#+ .*versi.*n corta' "$archivo" || true; } | head -1 | cut -d: -f1)"
  if [ -n "$linea" ]; then
    tail -n "+$linea" "$archivo"
  else
    awk 'NR==1 && /^---$/{fm=1; next} fm && /^---$/{fm=0; next} !fm{print}' "$archivo"
  fi
}

# Titulo legible: campo name del frontmatter o el nombre de la carpeta.
titulo_skill() {
  local archivo="$1" carpeta="$2" n
  n="$(awk 'NR==1 && /^---$/{fm=1; next} fm && /^---$/{exit} fm && /^name:/{sub(/^name:[ \t]*/, ""); print; exit}' "$archivo")"
  printf '%s' "${n:-$carpeta}"
}

descripcion_skill() {
  awk 'NR==1 && /^---$/{fm=1; next} fm && /^---$/{exit} fm && /^description:/{sub(/^description:[ \t]*/, ""); print; exit}' "$1"
}

copiados=0
if [ "$SOLO_PROMPTS" -eq 0 ]; then
  for s in "${skills[@]}"; do
    mkdir -p "$CLAUDE_SKILLS/$s"
    if ! cmp -s "$SKILLS_DIR/$s/SKILL.md" "$CLAUDE_SKILLS/$s/SKILL.md" 2>/dev/null; then
      cp "$SKILLS_DIR/$s/SKILL.md" "$CLAUDE_SKILLS/$s/SKILL.md"
      copiados=$((copiados + 1))
    fi
  done
fi

mkdir -p "$PROMPTS_DIR"

tmp_agents="$(mktemp "$DESTINO/.AGENTS.md.XXXXXX")"
trap 'rm -f "$tmp_agents"' EXIT

{
  echo "# AGENTS.md - taller de programacion agentica"
  echo
  echo "Reglas de trabajo para agentes (Codex, GPT y similares). Generado por"
  echo "instalar.sh a partir de skills/*/SKILL.md; no editar a mano, volver a"
  echo "ejecutar \`bash instalar.sh\`."
  echo
  echo "Skills incluidos:"
  for s in "${skills[@]}"; do
    echo "- $(titulo_skill "$SKILLS_DIR/$s/SKILL.md" "$s"): $(descripcion_skill "$SKILLS_DIR/$s/SKILL.md")"
  done
  echo
  for s in "${skills[@]}"; do
    archivo="$SKILLS_DIR/$s/SKILL.md"
    echo "---"
    echo
    echo "# Skill: $(titulo_skill "$archivo" "$s")"
    echo
    # Rebaja un nivel el encabezado "Version corta" para que cuelgue del skill.
    version_corta "$archivo" | sed -E '1s/^#+ /## /'
    echo
  done
} > "$tmp_agents"
mv -f "$tmp_agents" "$AGENTS"
trap - EXIT

generados=0
for s in "${skills[@]}"; do
  archivo="$SKILLS_DIR/$s/SKILL.md"
  salida="$PROMPTS_DIR/$s.txt"
  {
    echo "Eres un agente de programacion. Sigue estas reglas del skill \"$(titulo_skill "$archivo" "$s")\":"
    echo
    # Sin el encabezado markdown: un system prompt no necesita "#".
    version_corta "$archivo" | sed -E '1{/^#+ /d;}'
  } > "$salida.tmp"
  mv -f "$salida.tmp" "$salida"
  generados=$((generados + 1))
done

echo "Skills encontrados : ${#skills[@]} (${skills[*]})"
if [ "$SOLO_PROMPTS" -eq 0 ]; then
  echo "Claude Code        : $CLAUDE_SKILLS ($copiados copiados, $(( ${#skills[@]} - copiados )) sin cambios)"
else
  echo "Claude Code        : omitido (--solo-prompts)"
fi
echo "AGENTS.md          : $AGENTS ($(wc -l < "$AGENTS" | tr -d ' ') lineas)"
echo "Prompts            : $PROMPTS_DIR ($generados archivos)"
