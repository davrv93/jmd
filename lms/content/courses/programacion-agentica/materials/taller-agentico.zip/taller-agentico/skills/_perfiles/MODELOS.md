# Matriz de adaptación de los skills por modelo

Fecha de verificación: 2026-10-10. Los enlaces, precios y tamaños de contexto cambian cada pocos meses; antes de dar una clase, revisa las filas marcadas y actualiza esta fecha.

Los seis skills del taller (`planificacion-proyecto`, `plan-de-trabajo`, `pruebas-de-uso`, `pruebas-de-rendimiento`, `comandos-optimizados`, `piedra`) están escritos para leerse completos en modelos grandes y para usarse solo con la sección "Versión corta para modelos pequeños" en los demás. Esta matriz dice, modelo por modelo, dónde se instala el skill, cuánto texto darle y qué estilo de instrucción obedece mejor.

## Cómo leer la matriz

- **Dónde vive el skill**: la ruta o el lugar donde el modelo lee instrucciones persistentes. Si el modelo no tiene un lugar propio, el skill se pega como system prompt o como primer mensaje.
- **Longitud**: "completo" significa todo el `SKILL.md`; "corta" significa solo la sección final de 25 líneas. "Completo o corta" significa que el modelo aguanta el completo pero la corta suele bastar.
- **Contexto**: ventana nominal publicada. La ventana útil para seguir instrucciones es siempre menor; con modelos pequeños, asume la mitad.
- **Herramientas**: "sí" cuando el modelo llama funciones de forma nativa; "JSON a mano" cuando hay que pedirle que escriba un JSON con el comando y otro programa lo ejecuta; "no" cuando no es fiable ni con JSON.
- **Costo**: lo que paga el alumno. "Gratis" incluye pesos abiertos que corren en su laptop o un tier gratuito con límites.

## Glosario mínimo

- **System prompt**: texto que el modelo recibe antes del primer mensaje del usuario y que trata como instrucciones permanentes de la sesión.
- **Frontmatter**: bloque YAML entre `---` al inicio de un `SKILL.md`; Claude Code lo usa para decidir cuándo cargar el skill.
- **Function calling / herramientas**: capacidad del modelo de devolver una llamada estructurada (nombre de función y argumentos) que otro programa ejecuta.
- **JSON a mano**: pedir al modelo que escriba un JSON con el comando a ejecutar cuando no tiene herramientas nativas; una persona o un script lo valida y lo corre.
- **Pesos abiertos**: el archivo del modelo se descarga y corre en local (Ollama, llama.cpp); no implica licencia libre, hay que leerla.
- **Cuantización (`q4`, `q8`)**: reducir la precisión de los pesos para que el modelo quepa en menos RAM a cambio de algo de calidad.
- **Tokens/s**: velocidad de generación; con menos de 8 el usuario percibe espera, con más de 15 lee a ritmo de conversación.

## Matriz

| Modelo | Dónde vive el skill | Longitud recomendada | Contexto nominal | Estilo que mejor obedece | Herramientas | Costo | Enlace oficial |
|--------|---------------------|----------------------|------------------|--------------------------|--------------|-------|----------------|
| Claude (Claude Code) | `~/.claude/skills/<nombre>/SKILL.md` (personal) o `.claude/skills/<nombre>/SKILL.md` (proyecto); el frontmatter `name` y `description` son los que usa para decidir cuándo cargarlo | Completo | 200 000 tokens (1 M en algunas variantes) | Prosa con secciones, reglas duras explícitas, listas de comprobación. Respeta bien "nunca" y "siempre". Tolera matices. | Sí, nativo (Bash, lectura y escritura de archivos, MCP) | Pago (suscripción o API); tier gratuito de chat sin Claude Code | https://docs.claude.com/en/docs/claude-code |
| OpenAI Codex (CLI y nube) | `AGENTS.md` en la raíz del repositorio; también `~/.codex/AGENTS.md` para reglas personales. Pega el skill completo o un enlace relativo al archivo. | Completo o corta (si `AGENTS.md` ya es largo, corta) | 200 000 tokens o más según modelo subyacente | Instrucciones por secciones con títulos; obedece bien reglas de "no hagas X sin confirmación". Agradece ejemplos de comandos. | Sí, nativo (shell en sandbox, edición de archivos) | Pago (incluido en planes ChatGPT Plus/Pro/Team; API aparte) | https://developers.openai.com/codex |
| GPT (ChatGPT, GPT-5 y familia) | Instrucciones del proyecto (Projects) o un GPT personalizado con el skill en "Instrucciones"; en API, system prompt | Completo o corta | 128 000 a 400 000 tokens según modelo | Rol al inicio ("Eres…"), reglas numeradas, formato de salida descrito. Tiende a añadir cortesía: `piedra` necesita la regla "sin saludos" repetida al final. | Sí (function calling en API; en ChatGPT solo con herramientas propias o GPTs con acciones) | Gratis con límites; Plus/Pro pago; API pago | https://platform.openai.com/docs |
| DeepSeek (V3 chat, R1 razonador) | System prompt (API compatible con OpenAI) o primer mensaje en el chat web | Corta; completo solo en V3 con tarea de planificación | 128 000 tokens (64 000 de salida en R1 según versión) | Listas numeradas explícitas, un verbo por ítem. R1 ignora instrucciones de estilo si razonan en contra: ponlas como "formato de salida obligatorio" al final. Evita párrafos largos de contexto. | Sí en V3 (function calling); R1 inestable con herramientas, prefiere JSON a mano | Gratis en web; API muy barata (pago) | https://api-docs.deepseek.com |
| GLM (Zhipu / Z.ai, serie 4.x: GLM-4.5, GLM-4.6) | System prompt; en Z.ai Coding Plan y en herramientas tipo Claude Code conectadas por API, el `SKILL.md` funciona si se expone en la ruta de skills del cliente | Corta; completo en GLM-4.6 para planificación | 128 000 a 200 000 tokens según variante | Listas numeradas explícitas, cada regla en su línea. Buen seguimiento de formato tabular. Repite el formato de salida esperado al final del prompt. | Sí (function calling nativo, estilo OpenAI) | Pesos abiertos (gratis para correr); API y Coding Plan pago | https://docs.z.ai |
| NVIDIA Nemotron (Nemotron 3 Nano/Super/Ultra, Nemotron-H) | System prompt con rol explícito y formato de salida; disponible en NIM, Hugging Face y Ollama (`ollama run nemotron-mini`, `nemotron-nano`) | Corta; completo solo en Super/Ultra | 128 000 tokens en la mayoría; 1 M en variantes Nano 3 largas | System prompt con "Rol:" y "Formato de salida:" en dos bloques separados. Obedece mejor cuando el formato esperado va con ejemplo. Flojo con reglas negativas sueltas: agrúpalas bajo "Prohibido:". | Sí en Super/Ultra (function calling); Nano: JSON a mano | Pesos abiertos (gratis); NIM en nube pago | https://developer.nvidia.com/nemotron |
| Ling (inclusionAI, Ant Group: Ling-mini-2.0, Ling-flash-2.0, Ling-1T; 2.6 y 3.0 Flash más recientes) | System prompt (API compatible con OpenAI en proveedores como Kilo u OpenRouter; pesos en Hugging Face `inclusionAI/`) | Corta; completo en Ling-1T o Ling-flash para planificación | 128 000 a 256 000 tokens; variantes 2.5/2.6 declaran 1 M | Mezcla de expertos orientada a agentes: obedece listas numeradas y formato JSON de salida. Pide ejemplos de comandos. Verifica licencia y pesos de 3.0 Flash antes de prometerlos en clase: las fuentes del 2026-10-10 se contradicen (abierto en HF frente a solo API). | Sí (llamada a herramientas declarada en los modelos 2.6) | Pesos abiertos de 2.0 y 2.6 (gratis); 3.0 Flash gratis temporal en Kilo, API pago después | https://huggingface.co/inclusionAI |
| Muse (Meta Superintelligence Labs: Muse Glimmer abierto, Muse Spark cerrado) | System prompt. Muse Glimmer corre en Ollama (`ollama run` con la etiqueta que publique la biblioteca) o llama.cpp; Muse Spark solo en productos de Meta y API privada | Corta en Glimmer (30 B denso, local); completo no probado | Glimmer: ventana publicada en la tarjeta de Hugging Face, revisar; Spark: no público | Glimmer es modelo de agente local con entrada de texto e imagen; obedece reglas numeradas y formato de salida fijo. Spark no aplica a este taller por ser cerrado. Verificado el 2026-10-10: Glimmer liberado 2026-08-10 con licencia Apache 2.0; cifras de rendimiento son del fabricante. | Glimmer: sí (orientado a agentes); Spark: no accesible | Glimmer gratis (pesos abiertos, requiere GPU de 24 GB o cuantización); Spark no disponible | https://ai.meta.com |
| SpaceBunny (`stealth/space-bunny-alpha` en OpenRouter) | System prompt vía OpenRouter (API compatible con OpenAI) | Corta | 1 M tokens declarado por la ficha de OpenRouter | **No verificado el 2026-10-10: ajustar.** Existe como modelo anónimo ("stealth") en OpenRouter desde 2026-09-23, con texto, imagen y video de entrada y precio 0 en preview; el fabricante no se ha identificado (especulación: MiniMax) y la ficha llevaba fecha de expiración 2026-10-05. No hay documentación oficial, ni pesos, ni garantía de que siga en línea. Úsalo solo como curiosidad de clase, nunca como base de un proyecto. | Desconocido; tratar como JSON a mano | Gratis en preview (puede desaparecer) | https://openrouter.ai/stealth/space-bunny-alpha |
| Ollama pequeño (qwen3:1.7b, gemma3:4b, llama3.2:1b) | System prompt en `Modelfile` (`SYSTEM """…"""`) o con `ollama run modelo "$(cat corta.md)"`; también por API en `/api/chat` con rol `system` | Corta, siempre. Nunca el completo. | 32 000 a 128 000 nominal; útil real 4 000 a 8 000 para seguir reglas | Una sola instrucción por turno. Ejemplos antes que reglas (muestra "entrada → salida" en dos pares). Repite el formato de salida al final de cada mensaje de usuario. Evita negaciones compuestas: "No hagas X salvo Y" se parte en dos frases. | No fiable. JSON a mano con esquema de un solo nivel y validación externa. | Gratis (CPU o GPU local; 2 a 4 GB de RAM por modelo) | https://ollama.com/library |

## Notas por familia

### Claude Code
El `SKILL.md` se carga completo cuando el `description` del frontmatter coincide con lo que pide el usuario, así que la línea de `description` debe llevar las palabras gatillo tal como las diría un alumno. Para `piedra`, Claude Code tiene además skills de terceros con modos compactos; `piedra` es independiente y no requiere ninguno. Si hay un `CLAUDE.md` en el proyecto, las reglas de ese archivo mandan sobre el skill.

### Codex
`AGENTS.md` es un solo archivo, así que conviene pegar en él las "versiones cortas" de los skills que se usarán siempre (`comandos-optimizados`, `plan-de-trabajo`) y enlazar con ruta relativa los completos (`Ver taller-agentico/skills/pruebas-de-rendimiento/SKILL.md`). Codex lee el archivo al inicio de la sesión; si se edita a mitad, hay que reiniciar.

### GPT / ChatGPT
En un proyecto de ChatGPT las instrucciones tienen límite de caracteres (varía por plan; alrededor de 8 000). Cabe un skill completo o tres cortas. En un GPT personalizado se pueden subir los `SKILL.md` como archivos de conocimiento y dejar en "Instrucciones" solo la regla "antes de planificar, lee planificacion-proyecto.md". Para `piedra`, añade al final de las instrucciones la línea "Sin saludos ni cierres" porque la cortesía por defecto reaparece.

### DeepSeek
V3 sigue las versiones cortas sin problema y puede con el completo en tareas de planificación. R1 razona antes de responder y a veces "decide" que el formato pedido no es necesario; para evitarlo, la última línea del system prompt debe ser "Formato de salida obligatorio: [descripción]". Para `comandos-optimizados`, pide los comandos dentro de un bloque de código y que no explique salvo que se le pregunte.

### GLM
La serie 4.x se integra bien en clientes de código por API compatible. Obedece tablas y listas numeradas con disciplina. Para `plan-de-trabajo`, dale la plantilla con la tabla vacía y pídele que la rellene fila por fila; produce mejor resultado que pedirle "haz un plan".

### Nemotron
Separa siempre el system prompt en dos bloques: "Rol:" (una o dos frases) y "Formato de salida:" (con un ejemplo). Las reglas negativas sueltas se pierden; agrúpalas bajo un encabezado "Prohibido:". Las variantes Nano corren en Ollama y en una laptop con 8 GB; las Super y Ultra necesitan GPU grande o NIM en nube.

### Ling
Verificado el 2026-10-10: la familia Ling 2.0 (mini 16 B, flash 100 B, 1T) es de inclusionAI, laboratorio de Ant Group, con pesos en Hugging Face y arquitectura de mezcla de expertos. Las versiones 2.6 y 3.0 Flash son de 2026 y las fuentes disponibles se contradicen sobre si 3.0 Flash tiene pesos abiertos o solo API. Para el taller, usa Ling-flash-2.0 o Ling-mini-2.0 si quieres pesos; o accede por OpenRouter/Kilo para probar sin instalar. Trata sus cifras de rendimiento como declaraciones del fabricante.

### Muse
Verificado el 2026-10-10: "Muse" en 2026 es la serie de Meta Superintelligence Labs. Muse Spark (abril de 2026) es cerrado y no sirve para el taller. Muse Glimmer (10 de agosto de 2026) es abierto, 30 B denso, Apache 2.0, pensado para agentes locales, con soporte en Ollama desde la versión 0.32.7. Necesita una GPU de 24 GB o cuantización agresiva; en una laptop de alumno sin GPU no es realista. Si en tu contexto "Muse" se refiere a otro producto (hubo un Muse de Microsoft Research para videojuegos en 2025, sin relación con LLM de texto), ajusta esta fila.

### SpaceBunny
No verificado el 2026-10-10: ajustar. Solo se encontró `stealth/space-bunny-alpha`, un modelo anónimo servido por OpenRouter en preview gratuita, sin fabricante confirmado, sin documentación y con fecha de expiración ya pasada en la ficha. No hay evidencia de un modelo en Hugging Face con ese nombre. Si el alumno lo trae a clase, úsalo para demostrar cómo se evalúa un modelo desconocido (medir tokens/s, probar la versión corta de `piedra`, ver si respeta negaciones) y nada más.

### Ollama pequeño
Un modelo de 1 a 4 B no "lee un skill": sigue el último formato que vio. Por eso la versión corta se da como system prompt, el formato de salida se repite en cada turno y los ejemplos van antes que las reglas. Mide con `ollama run modelo --verbose` (ver `pruebas-de-rendimiento`): bajo 8 tokens/s en la laptop del alumno, cambia a un modelo más chico o cuantización `q4`. Qwen3 1.7 B sigue instrucciones mejor que Llama 3.2 1 B; Gemma 3 4 B escribe mejor español pero necesita 4 GB de RAM.

## Instalación rápida por modelo

Comandos para dejar los seis skills disponibles en cada entorno. Sustituye `RUTA` por la carpeta `taller-agentico/skills` del repositorio del alumno.

### Claude Code (personal, todos los proyectos)

```bash
for s in planificacion-proyecto plan-de-trabajo pruebas-de-uso pruebas-de-rendimiento comandos-optimizados piedra; do
  mkdir -p ~/.claude/skills/$s && cp RUTA/$s/SKILL.md ~/.claude/skills/$s/SKILL.md
done && ls ~/.claude/skills | wc -l
```

Para instalarlos solo en un proyecto, cambia `~/.claude/skills` por `.claude/skills` dentro del repositorio. Claude Code los lista con `/skills` o los invoca al detectar las palabras gatillo del `description`.

### Codex

```bash
{
  echo; echo "## Skills del taller (versiones cortas)";
  for s in comandos-optimizados plan-de-trabajo piedra; do
    echo; echo "### $s"; sed -n '/^## Versión corta para modelos pequeños/,$p' RUTA/$s/SKILL.md | tail -n +2;
  done;
  echo; echo "Versiones completas en RUTA/<skill>/SKILL.md";
} >> AGENTS.md && wc -l AGENTS.md
```

Reinicia la sesión de Codex después de editar `AGENTS.md`.

### GPT / ChatGPT

Sin terminal: abre el proyecto o el GPT personalizado, pega en "Instrucciones" la versión corta de `comandos-optimizados` y de `piedra`, y sube los seis `SKILL.md` como archivos de conocimiento. Añade la frase: "Antes de planificar, lee planificacion-proyecto y plan-de-trabajo de los archivos adjuntos".

### DeepSeek, GLM, Ling, OpenRouter (API compatible con OpenAI)

```bash
SYSTEM=$(sed -n '/^## Versión corta para modelos pequeños/,$p' RUTA/piedra/SKILL.md)
curl -s "$API_URL/chat/completions" -H "Authorization: Bearer $API_KEY" -H "Content-Type: application/json" \
  -d "$(jq -n --arg s "$SYSTEM" --arg m "$MODELO" '{model:$m, messages:[{role:"system",content:$s},{role:"user",content:"/piedra"}]}')" \
  | jq -r '.choices[0].message.content'
```

`$API_URL` es `https://api.deepseek.com`, `https://api.z.ai/api/paas/v4`, `https://openrouter.ai/api/v1` u otro según el proveedor; comprueba la ruta exacta en su documentación. Nunca pegues el valor de `$API_KEY` en el chat.

### Nemotron y Ollama pequeño

Ver la sección final "Cómo convertir un SKILL.md en system prompt". Para Nemotron, antepón las dos líneas `Rol:` y `Formato de salida:` al texto de la versión corta.

## Adaptación skill por skill

Qué cambia en cada skill según el tamaño del modelo. "Grande" es Claude, Codex, GPT, DeepSeek V3, GLM-4.6, Ling-1T, Nemotron Super/Ultra. "Pequeño" es todo lo que corre en una laptop sin GPU.

| Skill | Modelo grande | Modelo pequeño | Riesgo típico en pequeños y remedio |
|-------|---------------|----------------|-------------------------------------|
| `planificacion-proyecto` | Completo. Puede hacer las siete preguntas en un turno y rellenar la plantilla entera. | Versión corta. Una pregunta de descubrimiento por turno; la plantilla se rellena sección por sección. | Inventa respuestas del cliente. Remedio: pedir "Escribe SUPUESTO: delante de lo que no te dije". |
| `plan-de-trabajo` | Completo. Genera la tabla con dependencias y criterios en un turno. | Versión corta. Pedir una fase por turno; dar la tabla vacía y pedir que la rellene. | Criterios vagos ("funciona"). Remedio: ejemplo de criterio bueno y malo en el prompt. |
| `pruebas-de-uso` | Completo. Redacta guion, SUS e informe. | Versión corta. Solo guion y hoja de hallazgos; el SUS se calcula con calculadora, no con el modelo. | Error al calcular el SUS. Remedio: no delegar aritmética a modelos de 1 a 4 B. |
| `pruebas-de-rendimiento` | Completo. Propone umbrales, corre comandos por herramienta y lee la salida. | Versión corta. El alumno corre el comando y pega las tres cifras; el modelo solo compara con el umbral. | Alucina salidas de comandos que no corrió. Remedio: "Solo compara los números que te pego; no inventes mediciones". |
| `comandos-optimizados` | Completo. Se cumple de forma natural en Claude Code y Codex. | Versión corta como system prompt fijo. El modelo propone el comando, una persona lo ejecuta. | Olvida `&& echo LISTO` o el `tail`. Remedio: ejemplo de comando correcto como primer mensaje. |
| `piedra` | Completo. Los tres niveles funcionan. | Versión corta. Solo `piedra` (sin lite ni dura). Repetir "conserva no, nunca, solo" en cada turno largo. | Pierde negaciones al acortar. Remedio: probar con tres frases con "no" antes de confiar. |

## Problemas frecuentes al adaptar y su remedio

1. **El modelo saluda aunque está en modo piedra.** Pasa en GPT y en Gemma. Remedio: la última línea del system prompt debe ser la regla, no la primera. Los modelos pesan más el final.
2. **El modelo sigue las reglas los dos primeros turnos y luego las olvida.** Pasa en todos los pequeños y en DeepSeek R1 con razonamiento largo. Remedio: repetir la versión corta cada cinco turnos o incluir el formato de salida en cada mensaje de usuario.
3. **El modelo ejecuta algo destructivo sin pedir confirmación.** Pasa cuando la regla está redactada como "evita" en lugar de "nunca sin confirmación". Remedio: lista cerrada bajo "Prohibido sin confirmación:" con los comandos literales.
4. **El modelo inventa la salida de un comando.** Pasa en modelos sin herramientas. Remedio: el modelo escribe el comando dentro de un bloque y se detiene; la persona lo ejecuta y pega el resultado. Pedir explícitamente "Detente después del bloque de código".
5. **El `SKILL.md` no se carga en Claude Code.** El `description` del frontmatter no contiene las palabras que usó el alumno. Remedio: añadir sinónimos al `description` y volver a abrir la sesión.
6. **La ventana se llena antes de terminar el plan.** Pasa con el skill completo en modelos de 32 000 tokens. Remedio: versión corta más plantilla; o pedir la salida en un archivo y continuar en una sesión nueva leyendo solo ese archivo.
7. **El modelo mezcla español e inglés.** Pasa en Llama 3.2 1 B y en Nemotron Nano. Remedio: primera línea del system prompt "Responde siempre en español" y un ejemplo en español; si persiste, cambiar a Qwen3 o Gemma 3.
8. **La aritmética del SUS o de la mediana sale mal.** Pasa en todos los modelos pequeños y a veces en grandes. Remedio: hacer el cálculo con `awk`, hoja de cálculo o calculadora; el modelo solo interpreta.

## Lista de comprobación antes de la clase

- [ ] La fecha de verificación al inicio de este archivo es de hace menos de tres meses.
- [ ] Los enlaces oficiales de la matriz abren.
- [ ] Las filas marcadas "No verificado" se revisaron o se avisará a los alumnos de su estado.
- [ ] Los seis `SKILL.md` están instalados en al menos un modelo grande y uno pequeño del aula.
- [ ] La versión corta de `piedra` se probó en el modelo pequeño con las tres frases con negación.
- [ ] `ollama run <modelo> --verbose` dio más de 8 tokens/s en la laptop más lenta del aula.
- [ ] Hay un ejemplo de comando correcto preparado para cada modelo sin herramientas.

## Cómo convertir un SKILL.md en system prompt

Procedimiento de cinco pasos, válido para cualquier modelo que no lea archivos de skills por sí mismo.

1. **Extrae la versión corta.** Copia desde la línea "## Versión corta para modelos pequeños" hasta el final del archivo. Para modelos grandes (GPT, DeepSeek V3, GLM-4.6) puedes copiar en cambio desde "## Principios" hasta "## Reglas duras" inclusive.
   ```bash
   sed -n '/^## Versión corta para modelos pequeños/,$p' /ruta/skills/piedra/SKILL.md > /tmp/piedra-corta.md
   ```
2. **Quita el encabezado Markdown y pon un rol.** Sustituye la línea `## Versión corta…` por una frase de rol: "Eres un asistente técnico. Sigue estas reglas en cada respuesta." Los modelos pequeños responden mejor a un rol que a un título.
3. **Añade el formato de salida al final.** Una línea que diga exactamente cómo debe verse la respuesta: "Responde en frases cortas en español. Sin saludos." Para modelos de 1 a 4 B, añade un ejemplo de entrada y salida.
4. **Carga el texto como system prompt.** En Ollama, con un `Modelfile`:
   ```
   FROM qwen3:1.7b
   SYSTEM """
   [pega aquí el contenido de /tmp/piedra-corta.md]
   """
   ```
   y crea el modelo: `ollama create piedra-qwen -f Modelfile`. En API compatible con OpenAI (DeepSeek, GLM, Ling, OpenRouter), envía el texto en el mensaje con `"role": "system"`.
5. **Prueba con tres entradas y ajusta.** Una pregunta de sí o no, una instrucción con negación ("no borres X") y una medición con números. Si el modelo pierde la negación o redondea el número, repite esa regla al final del system prompt y vuelve a probar.

### Ejemplo completo con `ollama run qwen3:1.7b`

Sin crear un modelo nuevo, pasando la versión corta como system prompt en una sola línea de terminal:

```bash
# 1. Extraer la versión corta de piedra
sed -n '/^## Versión corta para modelos pequeños/,$p' \
  /Users/david.roncal/Downloads/PjgFactSalud_completo/taller-agentico/skills/piedra/SKILL.md \
  | sed '1s/.*/Eres un asistente técnico. Sigue estas reglas en cada respuesta./' > /tmp/piedra-corta.md

# 2. Comprobar que cabe (debe ser menor de 30 líneas)
wc -l /tmp/piedra-corta.md

# 3. Lanzar el modelo con el system prompt y una pregunta de prueba
ollama run qwen3:1.7b --verbose "$(cat /tmp/piedra-corta.md)

Usuario: /piedra
Usuario: El servidor tiene 2 GiB de RAM y el build del frontend pide 1 GB. ¿Puedo hornear en el servidor?" 2>&1 | tail -8
```

Salida esperada (el texto varía; el formato no debe variar):

```
Modo piedra activo.
No. Build pide 1 GB. Servidor tiene 2 GiB y ya los usa. Hornea fuera y sube la imagen.

total duration:       4.1s
eval rate:            22.4 tokens/s
```

Si la respuesta empieza con "¡Claro!" o pierde el "No", el modelo no obedeció: añade al final de `/tmp/piedra-corta.md` la línea "Primera palabra de la respuesta: nunca un saludo. Conserva siempre la palabra no." y repite el paso 3. Si sigue fallando con qwen3:1.7b, prueba gemma3:4b antes de culpar al skill.
