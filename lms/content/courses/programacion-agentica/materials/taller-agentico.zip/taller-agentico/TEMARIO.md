# Programación agéntica con Edge AI · Temario del curso

**Curso:** Programación agéntica (vibecoding) · LMS: https://jmd-learn.online
**Formato:** tres sesiones presenciales de 2 horas, cada participante con su laptop
**Proyecto guía:** Tecnosito, un asistente con avatar 3D que conversa, escucha, genera imágenes y, al final, atiende por WhatsApp, todo con modelos que corren en la propia máquina

| Sesión | Título | Estado |
|---|---|---|
| 1 | Instalar las herramientas y entender qué hay detrás | Dictada el 08-10-2026 |
| 2 | Construir un asistente con skills, plan de trabajo y Edge AI | Por dictar |
| 3 | Llevarlo a WhatsApp: wireframe, UI, desarrollo, pruebas y despliegue | Por dictar |


---

## Sesión 1 · Instalar las herramientas y entender qué hay detrás

**Dictada el 08-10-2026.** Resumen de lo que ya quedó hecho; el detalle, las diapositivas y los ejemplos están en el LMS (clase `pa-01`).

### Qué se vio

1. **VS Code**: instalación y comprobación con `code --version`.
2. **Docker**: instalación y `docker run --rm hello-world`.
3. **OpenCode**: instalación y conexión al gateway de la clase como proveedor compatible con OpenAI (`opencode.json` con la URL y la clave que entrega el instructor).
4. **Conceptos**: qué es un agente de IA (bucle que observa, decide y actúa con herramientas), qué es un proveedor, qué es un modelo y qué hacen los parámetros `temperature` y `max_tokens` (ejemplo 04).
5. **Ahorrar contexto**: reglas del proyecto en `AGENTS.md` (`/init`); **RTK** (Rust Token Killer) como hook que comprime la salida de los comandos antes de que llegue al modelo (`rtk gain` muestra el ahorro); **caveman** como skill de respuestas cortas. Si se usa la skill y el estilo del gateway a la vez, el recorte se aplica dos veces: dejar uno.
6. **MCP**: qué es y cómo se configura un servidor en OpenCode y en Claude Code (ejemplo 03).
7. **Skills**: dónde van (`.opencode/skills/<nombre>/SKILL.md` o `~/.claude/skills/`), front matter con `name` y `description`, cómo se cargan; práctica con la skill `landing-editorial` del instructor (skills.zip).

### Entregable de referencia

![Landing page construida con el agente](capturas/16-landing-sesion1.png)

### Tarea 1 (vence el 15-10-2026, 20 puntos)

Repositorio `clase-01` con `EVIDENCIA.md` (salida de los tres comandos y captura de OpenCode respondiendo), la skill `saludo` y `REFLEXION.md`. Se entrega por el LMS con URL y SHA del commit.

### Lo que la sesión 2 da por hecho

VS Code, Docker y OpenCode funcionando contra el gateway; saber qué es una skill y haber escrito una; RTK instalado; `AGENTS.md` en el proyecto.

---

## Sesión 2 · Construir un asistente con skills, plan de trabajo y Edge AI

**Duración:** 2 horas. **Resultado:** cada equipo dirige a su agente para construir una variante funcional de Tecnosito con un modelo de lenguaje, reconocimiento de voz y generación de imágenes corriendo en local.

### Resultados de aprendizaje

1. Instalar y usar los 14 skills del taller con el modelo que cada uno tenga (OpenCode con el gateway, Claude Code, Codex, GPT, DeepSeek, GLM, Nemotron u Ollama).
2. Convertir un pedido vago en un plan de trabajo con tareas verificables y seguirlo en vivo con la pantalla de obra.
3. Elegir el modelo de imagen que cabe en su máquina y explicar por qué un modelo de difusión no escribe texto.
4. Probar el resultado con usuarios reales y medir tiempos.

### Dominio de cada equipo

Todos construyen el mismo asistente. Cada equipo lo adapta con el corpus de su propio dominio: el manual, reglamento o guía que usa en su trabajo, en 10 a 20 párrafos.

### Antes de la clase (40 minutos en casa, obligatorio)

La red del aula no aguanta cinco descargas de 2,4 GB. Todo lo pesado se baja la noche anterior.

1. Enviar al grupo de WhatsApp: sistema operativo, RAM, GPU (modelo y VRAM) y CPU. El instructor responde con el nivel de imagen que le toca a cada uno.
2. Instalar Ollama y bajar el modelo de chat: `ollama pull qwen3:1.7b`.
3. Descargar la carpeta del taller, crear el entorno y correr el diagnóstico:
   ```bash
   cd taller-agentico
   python3 -m venv .venv && source .venv/bin/activate   # en Windows: .venv\Scripts\activate
   pip install -r osito/backend/requirements.txt
   python osito/backend/diagnostico.py
   ```
4. Descargar solo el modelo de imagen de su nivel (comandos en `osito/README.md`). Con RTX serie 50, instalar antes torch con CUDA 12.8.
5. Traer el corpus en `manual.txt`, párrafos separados por línea en blanco.

Quien llegue sin modelo de imagen trabaja igual: el sistema cae a modo demo.

### Cronograma

| Tiempo | Bloque | Qué pasa | Entregable |
|---|---|---|---|
| 0:00 a 0:10 | Apertura | Repaso de 2 minutos de la sesión 1. Qué es Edge AI. Demo de Tecnosito: pregunta por voz, respuesta hablada, flyer generado. | Ninguno |
| 0:10 a 0:25 | Skills | `bash instalar.sh` copia los 14 skills; `AGENTS.md` y `prompts/` para quien usa OpenCode u Ollama. Activar modo piedra. Pedir un plan de proyecto sin skill y luego con `planificacion-proyecto`; comparar. | Skills instalados y plan de media página |
| 0:25 a 0:40 | Plan y obra | Con `plan-de-trabajo`, escribir `PLAN_TRABAJO.md`: 6 tareas de 15 minutos con criterio verificable. `obra.py servir` y la pantalla de construcción visible en cada equipo. | Plan con 6 tareas, obra al 0 % |
| 0:40 a 1:10 | Construcción | El agente ejecuta el plan con los skills. Cargar el corpus en `backend/faq.json`, cambiar nombre, saludo y ánimo. Cada tarea cerrada se marca con `obra.py paso`. | Asistente respondiendo preguntas del dominio con voz |
| 1:10 a 1:30 | Edge AI | Micrófono a texto con whisper. Flyer del evento del equipo: revisar los datos que extrajo el LLM, cambiar uno a propósito, regenerar. Por qué el modelo de difusión no escribe y cómo se resolvió. Comparar niveles rápida, buena y máxima. | Flyer con datos correctos |
| 1:30 a 1:50 | Pruebas | Pruebas de uso cruzadas con `pruebas-de-uso`: 5 minutos con el asistente de otro equipo y un guion de 3 tareas. Medir con `pruebas-de-rendimiento`: chat, voz a texto e imagen. | Hoja de hallazgos y tabla de tiempos |
| 1:50 a 2:00 | Cierre | Un minuto por equipo. Lecciones. Tarea 2 y preparación de la sesión 3. | Obra al 100 % |

### Entregable de referencia

![Asistente de ventas con avatar 3D generando un flyer](capturas/13b-chatbot-robot-pregunta.png)

### Notas por bloque

**Skills.** `skills/_perfiles/MODELOS.md` dice dónde pegar cada skill según el modelo. Quien trabaja con OpenCode y el gateway usa `AGENTS.md`; quien usa Ollama o DeepSeek usa `prompts/<skill>.txt` como system prompt. El skill `comandos-optimizados` y RTK se complementan: uno pide comandos baratos, el otro comprime lo que igual sale.

**Plan y obra.** Regla: ninguna tarea sin forma de probarla. Seis tareas sugeridas: cargar el corpus; nombre, saludo y ánimo; tres preguntas del dominio; micrófono; flyer; pruebas de uso. La pantalla de obra se refresca cada 2 segundos y deja ver avanzar al agente sin leer su terminal.

**Construcción.** El respaldo por embeddings devuelve "No estoy seguro de eso todavía" bajo el umbral de similitud; es correcto, no un error. Vigilar que el agente marque cada paso en obra y que no invente respuestas fuera del corpus.

**Edge AI.** La tubería del flyer tiene tres piezas: el LLM extrae los datos, el modelo de difusión pinta solo el fondo, el código compone la tipografía. Un regex protege fecha, hora y precio del LLM. Tiempos de referencia en Mac Apple Silicon de 24 GB: rápida 9 s, buena 7 s en caliente, máxima 45 s. Sin GPU usable, rápida tarda de 25 a 60 s y es normal.

**Pruebas.** Un dato alterado por el LLM que el usuario no detecta es severidad 4. El backend imprime la duración de cada petición en su log.

### Entregables y evaluación (20 puntos)

| Entregable | Puntos | Criterio |
|---|---|---|
| `PLAN_TRABAJO.md` con 6 tareas verificables | 4 | Cada tarea con criterio de aceptación sí o no |
| Asistente respondiendo 3 preguntas del corpus | 6 | Respuesta correcta o "no estoy seguro" justificado; voz con subtítulo |
| Flyer con datos correctos | 4 | Título, fecha, hora y precio exactos al pedido |
| Hoja de hallazgos de pruebas de uso | 4 | 3 tareas, severidades y una mejora propuesta |
| Obra al 100 % con horas reales | 2 | Pasos marcados durante la sesión, no al final |

### Tarea 2 y preparación de la sesión 3

1. Ampliar el corpus del asistente con 10 preguntas y respuestas más de tu dominio en `faq.json`, probar 3 de ellas por voz y entregar una captura de cada respuesta con 5 líneas de lo que aprendiste.
2. Para la sesión 3: `docker pull` de la imagen de Evolution API (comando en el LMS) y conseguir un número de WhatsApp de pruebas del equipo que no sea el personal de nadie (un chip prepago o un número viejo).

---

## Sesión 3 · Llevarlo a WhatsApp: wireframe, UI, desarrollo, pruebas y despliegue

**Duración:** 2 horas. **Resultado:** el asistente de cada equipo atiende mensajes de WhatsApp con su número de pruebas, las conversaciones se ven sincronizadas en el panel de Tecnosito y el conjunto queda desplegado con Docker y comprobado.

### Resultados de aprendizaje

1. Diseñar antes de programar: wireframe de baja fidelidad, flujo feliz y flujos de error, y pasarlo a UI con los skills de diseño, responsividad y accesibilidad.
2. Afiliar un número de WhatsApp a una API local (Evolution API) por código QR y recibir sus mensajes por webhook.
3. Sincronizar el bot con el asistente: cada mensaje entra por el webhook, lo responde el modelo local y se refleja en el panel; un humano puede tomar la conversación.
4. Entender qué es una herramienta del agente y ver un MCP en acción; usar skills, RTK y el modo caveman o piedra para que el agente trabaje barato y rápido.
5. Probar con un teléfono real y con pruebas automáticas, y desplegar con Docker Compose con una comprobación de salud.

### Arquitectura de lo que se construye

```
Teléfono del cliente  <->  WhatsApp  <->  Evolution API (Docker, en la laptop)
                                                |  webhook (Evolution llama al backend en la misma laptop)
                                                v
                                    backend del osito  /api/whatsapp/webhook
                                     |  /api/chat (Ollama + corpus)      |  sendText
                                     v                                   v
                              panel "Bandeja" en el frontend      respuesta al cliente
                              (eventos por SSE, modo humano/bot)
```

### Entregable de referencia

![Maqueta del asistente atendiendo por WhatsApp con la bandeja sincronizada](capturas/15-sesion3-bandeja.png)

### Antes de la clase (30 minutos en casa, obligatorio)

1. Docker corriendo y la imagen de Evolution API ya descargada (la red del aula no la aguanta).
2. Docker con la red por defecto: Evolution API corre en un contenedor y llama al backend de la laptop por `host.docker.internal`. No hace falta nada fuera de la laptop.
3. Número de WhatsApp de pruebas del equipo, con el teléfono presente en clase. Un segundo teléfono para escribirle.
4. RTK instalado y los 14 skills de la sesión 2 en su sitio. Tarea 2 entregada: el asistente ya responde el corpus del equipo.
5. Releer en el LMS qué es una herramienta y qué es un MCP (sesión 1, bloque 6). En clase el instructor muestra uno funcionando; no hay que instalar nada.

### Reglas de uso de WhatsApp en clase

- Solo números de pruebas del equipo. Nadie afilia su número personal.
- Quien escriba al bot debe saber que habla con un bot: el primer mensaje lo dice.
- Nada de envíos masivos, listas de contactos ni mensajes a terceros que no estén en el aula. Un número bloqueado por WhatsApp no se recupera en clase.

### Cronograma

| Tiempo | Bloque | Qué pasa | Entregable |
|---|---|---|---|
| 0:00 a 0:10 | Apertura | Qué se construye hoy y la arquitectura de arriba. Demo del instructor: un mensaje desde un teléfono, el osito cambia de ánimo, responde, y la conversación aparece en la bandeja. | Ninguno |
| 0:10 a 0:25 | Wireframe | Con `ux-flujos` y `ui-componentes`, el agente produce un wireframe en gris de tres pantallas: bandeja de conversaciones, conversación abierta con interruptor humano o bot, y estado del número (QR, conectado, caído). Flujo feliz y dos flujos de error (número desconectado; el modelo no responde). | `WIREFRAME.html` o boceto en Excalidraw, y `FLUJOS.md` |
| 0:25 a 0:40 | UI y UX | Pasar el wireframe a UI con `diseno-visual`, `responsividad` y `accesibilidad` en el mismo estilo del osito. Revisar a 393 px. Microcopy en español claro. | Panel "Bandeja" visible, aún sin datos |
| 0:40 a 1:05 | Afiliación | Levantar Evolution API con `docker compose up -d`, crear la instancia del equipo, escanear el QR con el teléfono de pruebas. Registrar el webhook apuntando a `http://host.docker.internal:8766/api/whatsapp/webhook`. Prueba: escribir "hola" desde el segundo teléfono y ver el JSON en el log del backend. RTK encendido para que el agente no se coma los logs. | Número conectado y primer webhook recibido |
| 1:05 a 1:30 | Desarrollo | Con `plan-de-trabajo` y obra, pedir al agente: endpoint `/api/whatsapp/webhook` que recibe el mensaje, llama a `/api/chat` y responde por `sendText`; eventos por SSE en `/api/whatsapp/eventos` hacia la bandeja; interruptor "modo humano" por conversación que silencia al bot; el osito pasa a `escuchando` al recibir y a `hablando` al responder. El agente trabaja en modo piedra. | Bot respondiendo por WhatsApp y bandeja sincronizada |
| 1:30 a 1:45 | Pruebas | Con un teléfono real: tres mensajes del guion de `pruebas-de-uso` (pregunta del corpus, pregunta fuera del corpus, pedir hablar con una persona). Automáticas: `curl` con un JSON de webhook grabado contra el endpoint. Demostración del instructor: el agente prueba el panel con un MCP de navegador, para ver qué es una herramienta en acción. Medir latencia de mensaje a respuesta con `pruebas-de-rendimiento`. | Hoja de hallazgos y latencia p50 y p95 |
| 1:45 a 2:00 | Despliegue | `docker compose` con backend, Evolution API y sus variables en `.env`; imagen horneada; `/api/salud` en verde; un mensaje real respondido; captura final. Opcional, si el instructor asigna ruta: el mismo compose en el servidor del curso. Cierre y tarea 3. | Stack desplegado con salud verde y obra al 100 % |

### Notas por bloque

**Wireframe.** Gris, sin color ni tipografía final; la intención es decidir qué hay en cada pantalla y en qué orden, no cómo se ve. Tres pantallas como máximo. Los flujos de error se escriben antes que el feliz: número desconectado y modelo caído son lo que pasará en clase.

**UI y UX.** Un asistente que responde por WhatsApp necesita que el humano pueda intervenir: el interruptor humano o bot va en la conversación, no escondido en ajustes. Todo lo que el bot envía se ve en la bandeja; nada sale sin registro.

**Afiliación.** Evolution API expone creación de instancias, QR, webhook y envío por REST. Como Evolution corre en Docker en la misma laptop, el webhook apunta a `host.docker.internal`, que es la forma en que un contenedor llega a la máquina que lo aloja. No hace falta nada fuera de la laptop. Si el QR no aparece, revisar que la instancia exista y que el contenedor vea internet.

**Desarrollo.** El webhook llega con el texto del mensaje y el número; filtrar los mensajes propios y los de grupos. Guardar las conversaciones en memoria o en un JSON; no hace falta base de datos. Responder siempre, aunque sea "No estoy seguro de eso todavía, te paso con una persona". Una herramienta es una función que el agente puede llamar; un MCP es la forma estándar de ofrecerle varias. En clase se ve una sola vez, en manos del instructor.

**Pruebas.** Latencia esperada de mensaje a respuesta con qwen3:1.7b en CPU: de 3 a 8 segundos. Más de 15 segundos sin respuesta es hallazgo de severidad 3.

**Despliegue.** Desplegar es sincronizar, hornear, levantar y comprobar; nunca solo hacer commit. `docker compose config` antes de `up`. Secretos solo en `.env`, fuera de git. Comprobar con `curl` a `/api/salud` y con un mensaje real.

### Entregables y evaluación (20 puntos)

| Entregable | Puntos | Criterio |
|---|---|---|
| Wireframe de 3 pantallas y `FLUJOS.md` con 1 flujo feliz y 2 de error | 3 | Las pantallas cubren bandeja, conversación y estado del número |
| Panel "Bandeja" responsivo y accesible | 3 | Sin desborde a 393 px; foco visible; interruptor humano o bot operable con teclado |
| Número afiliado y webhook recibido | 3 | Captura del QR conectado y del JSON del primer mensaje |
| Bot respondiendo por WhatsApp con la bandeja sincronizada | 5 | Tres mensajes reales con respuesta y reflejo en el panel; modo humano silencia al bot |
| Pruebas: hoja de hallazgos, `curl` del webhook y latencia p50 y p95 | 3 | Tres tareas probadas; latencia medida, no estimada |
| Despliegue con Docker Compose y salud verde | 3 | `docker compose ps` en verde, `/api/salud` correcto, `.env` fuera de git |

### Tarea 3 (cierre del curso)

Un video de 1 minuto con el asistente del equipo respondiendo 3 preguntas por WhatsApp a un compañero de otro equipo. Más `REFLEXION.md` de 10 líneas: qué hizo el agente solo, qué hubo que corregirle y qué aprendiste del curso.

---

## Si algo falla (las tres sesiones)

- Ollama no responde: el asistente cae al respaldo por embeddings; el chip de salud lo muestra en gris. Se puede seguir.
- El micrófono no funciona: Chrome solo lo permite en `localhost`, no por IP.
- La imagen tarda más de un minuto: bajar a calidad rápida o dejar el modo demo.
- Puerto ocupado: `OSITO_PUERTO=8766 bash osito/arrancar.sh` y `python obra/obra.py servir --puerto 8797`.
- Descarga de un modelo quieta: cancelar y repetir con `HF_HUB_DISABLE_XET=1`.
- El webhook no llega: comprobar que el backend está en 8766 y que la URL registrada usa `host.docker.internal`, no `localhost` (dentro del contenedor, `localhost` es el propio contenedor).
- El QR no aparece: la instancia no existe o el contenedor no sale a internet.

