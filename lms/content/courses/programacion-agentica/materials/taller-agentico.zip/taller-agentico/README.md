# Taller de programacion agentica

Material para un taller en el que el alumno construye un proyecto real (el
**osito**, un asistente con avatar 3D, animo, voz y microfono) dejando que un
agente de programacion haga el trabajo pesado, mientras el alumno dirige,
verifica y ve avanzar la obra en una pantalla que se refresca sola.

## Que contiene la carpeta

| Ruta | Que es |
| --- | --- |
| `skills/` | Un skill por carpeta (`skills/<nombre>/SKILL.md`). Cada uno trae una version completa y una "Version corta para modelos pequenos". |
| `skills/_perfiles/` | Perfiles por familia de modelo; `MODELOS.md` explica como adaptar cada skill a Claude, Codex/GPT, DeepSeek, GLM, Nemotron y Ollama. |
| `obra/` | Herramienta "obra en vivo": `obra.py` (CLI), `obra.html` (pantalla), `estado.json` (estado) y `statusline.sh` (status line de Claude Code). |
| `osito/` | El proyecto que se construye en el taller: `backend/` y `frontend/`. Tiene su propio `README.md`. |
| `instalar.sh` | Instala los skills para cada familia de modelo y genera `AGENTS.md` y `prompts/`. |

## Requisitos

- **Python 3.11 o superior** (probado con 3.13). La herramienta `obra` usa
  solo la biblioteca estandar: no hay nada que instalar con `pip`.
- **Chrome** (o cualquier navegador moderno) para la pantalla de la obra y el
  osito.
- **Node** solo si el osito lo pide (ver `osito/README.md`). `obra` no lo
  necesita.
- **Ollama** opcional, para correr los skills con modelos locales pequenos.
- Un agente de programacion: Claude Code, Codex, o un cliente que acepte un
  system prompt (Ollama, DeepSeek, GLM, Nemotron).

## Instalacion en 3 comandos

```bash
cd taller-agentico
bash instalar.sh .            # skills a ~/.claude/skills, AGENTS.md y prompts/ aqui
python3 obra/obra.py ver      # comprueba que la herramienta responde
```

`instalar.sh` es idempotente: se puede repetir sin miedo. Con `--solo-prompts`
no toca `~/.claude` y solo regenera `AGENTS.md` y `prompts/`.

## Como usar los skills con cada familia de modelo

El detalle esta en [`skills/_perfiles/MODELOS.md`](skills/_perfiles/MODELOS.md).
Resumen:

| Familia | Que se usa | Como llega al modelo |
| --- | --- | --- |
| Claude Code | `~/.claude/skills/<nombre>/SKILL.md` | Lo instala `instalar.sh`; el agente lo carga solo cuando la tarea encaja con la `description`. |
| Codex / GPT | `AGENTS.md` en la raiz del proyecto | Lo genera `instalar.sh` con la version corta de cada skill. |
| DeepSeek / GLM / Nemotron / Ollama | `prompts/<skill>.txt` | Se pega como system prompt o se pasa con `ollama run <modelo>` desde un `Modelfile` con `SYSTEM`. |

Los modelos pequenos trabajan mejor con la version corta: menos de 25 lineas,
ordenes literales y pocas reglas. La version completa es para Claude y GPT.

## Los 14 skills

| Skill | Para que sirve |
| --- | --- |
| `planificacion-proyecto` | Convertir un pedido vago en un `PLAN_PROYECTO.md` de dos paginas en 30 minutos: usuario, "hecho significa", entregables verticales, riesgos y "no entra". |
| `plan-de-trabajo` | Pasar de entregables a tareas de 45 minutos con criterio verificable, hitos y registro de avance en `PLAN_TRABAJO.md`. |
| `obra-en-vivo` | Mantener la pantalla de "proyecto en construccion" con `obra/obra.py`: pasos, barra de avance, status line y franja incrustable. |
| `relevar-maquinas` | Antes de un taller con modelos locales, pedir SO, RAM, GPU y VRAM a cada alumno, asignarle nivel y repartir las descargas por USB. |
| `imagenes-locales` | Generar imagenes y flyers con difusion local (sd-turbo, sdxl-turbo, FLUX.2 Klein): tope por maquina, descargas, tuberia LLM + difusion + Pillow. |
| `comandos-optimizados` | Comandos de terminal baratos en tokens, con salida recortada, rutas absolutas, ensayo antes de destruir y sin secretos impresos. |
| `piedra` | Modo de respuesta ultracompacto cuando el contexto se agota o el usuario pide ir al grano. |
| `diseno-visual` | Tokens, paletas kawaii y sobria, profundidad, jerarquia y movimiento con duraciones y curvas permitidas. |
| `ui-componentes` | Boton, campo, tarjeta, modal, toast, chat y panel lateral con todos sus estados y dialogos propios en vez de nativos. |
| `ux-flujos` | Mapa de tareas, camino feliz y de error, microcopy en espanol claro, estados vacios, carga percibida y eco de comprension del asistente. |
| `responsividad` | Movil primero: puntos de corte, unidades fluidas, zonas tactiles de 44 px y prueba a 393 px en Chrome. |
| `accesibilidad` | WCAG 2.2 AA en la practica: contraste, foco, ARIA justa, reduced motion, subtitulos de todo lo que dice el avatar. |
| `pruebas-de-uso` | Cinco personas, pensar en voz alta, SUS y hallazgos con severidad; en voz e imagenes, medir si el usuario detecta un dato alterado. |
| `pruebas-de-rendimiento` | Medir con comandos exactos y umbrales fijados antes: Lighthouse, Three.js, k6, tokens/s de Ollama, RTF de Whisper y huella de modelos locales. |

## Como correr la obra

La obra es la pantalla de "proyecto en construccion". El agente la mantiene al
dia y el alumno la mira.

```bash
python3 obra/obra.py iniciar "Osito" --pasos "Plan de trabajo" "Esqueleto 3D del osito" "Voz del osito"
python3 obra/obra.py servir            # http://localhost:8787/obra.html
python3 obra/obra.py paso "plan" --fase Plan
python3 obra/obra.py paso "esqueleto" --fase Frontend
python3 obra/obra.py error "falta el modelo 3D"
python3 obra/obra.py hecho
python3 obra/obra.py ver
```

- `paso` cierra como hecho el paso en curso y abre el que coincide por texto
  (parcial, sin mayusculas). Si no existe, lo anade.
- `--pct N` fija el porcentaje a mano; sin el, se calcula hechos / total.
- `--archivo otro.json` o la variable `OBRA_ESTADO` cambian la ruta del estado.
- `servir --puerto 8797` si el 8787 ya esta ocupado en tu maquina.
- `obra.html?compacto=1` es una franja de 56 px para incrustar como `iframe`.
- `estado.json` se sirve con `Cache-Control: no-store` y CORS abierto, asi que
  el frontend del osito puede leerlo en `http://localhost:8787/estado.json`.

Para la status line de Claude Code, anade a `~/.claude/settings.json`:

```json
{ "statusLine": { "type": "command",
  "command": "OBRA_ESTADO=/ruta/taller-agentico/obra/estado.json bash /ruta/taller-agentico/obra/statusline.sh" } }
```

El skill `skills/obra-en-vivo/SKILL.md` explica cuando y como debe usarla el
agente.

## Como correr el osito

El osito tiene su propia guia en [`osito/README.md`](osito/README.md). En
resumen:

```bash
bash osito/arrancar.sh
```

y abrir `http://localhost:8765`. Si la obra esta sirviendo en 8787, el osito
puede mostrar la franja compacta de avance dentro de su propia pantalla.

## Flujo sugerido del taller

1. Instalar (`bash instalar.sh .`) y abrir la obra en una pestana.
2. Pedir al agente que arme el plan de trabajo del osito y lo registre con
   `obra.py iniciar`.
3. Dejar que el agente avance paso a paso; el alumno verifica cada paso antes
   de que se marque como hecho.
4. Al final, revisar que la barra llegue a 100 % o que cada pendiente tenga
   una explicacion.

## Licencia

MIT. Puedes copiar, adaptar y redistribuir este material citando la fuente.


## Puertos en la Mac del docente (10-10-2026)

- `8765` lo ocupa `jev-style serve`: arrancar el osito con `OSITO_PUERTO=8766 bash osito/arrancar.sh`.
- `8787` lo ocupa el proxy del plugin caveman: `python3 obra/obra.py servir --puerto 8797` y abrir
  el osito con `http://localhost:8766/?obra=http://localhost:8797`.

## Capturas de la demo

En `capturas/`: chat con Ollama, imagen con sd-turbo, panel Obra, vista móvil a 393 px, la obra al 100 %
y el flyer de PHP en los tres niveles (sd-turbo, sdxl-turbo y FLUX.2 Klein).

## Lecciones de la demo (10-10-2026)

- Un modelo de difusion local no escribe texto legible: el LLM extrae los datos en JSON, un regex manda sobre fecha, hora y precio, la difusion pinta solo el fondo y Pillow compone la tipografia a 1080x1350.
- El LLM pequeno (`qwen3:1.7b`) altera cifras y adorna titulos ("PHP para Dummies") si no se le prohiben marcas y apodos; los datos extraidos se muestran al usuario para que corrija antes de regenerar.
- Niveles medidos en la Mac de 24 GB: sd-turbo 1,4 a 2,3 s y 5 GB; sdxl-turbo 7 s en caliente (27 s la primera) y 12 GB; FLUX.2 Klein 4B a 4 bits 32 a 55 s y 8 GB. sdxl-turbo en caliente es mas rapido que sd-turbo y se ve mucho mejor.
- El nivel lo decide la maquina (`tope_por_capacidad`, `diagnostico.py`): CUDA con 6 GB o mas, sdxl-turbo; Apple Silicon con 16 GB y mflux, Klein; AMD en Windows e integradas, CPU. Relevar SO, RAM, GPU y VRAM de cada alumno antes del taller.
- Descargas de Hugging Face con `HF_HUB_DISABLE_XET=1` (el xet se quedo 2 h en 1,1 GB), una a la vez, solo fp16, la noche anterior o por USB. La red del aula no aguanta 5 × 2,4 GB.
- En macOS la memoria real de un modelo en MPS se mide con `footprint -p <pid>`; `ps -o rss` dio 157 MB donde habia 4,97 GB.
- Pillow `ImageDraw` no mezcla alfa sobre RGBA: un chip semitransparente sale opaco; color solido calculado a mano o capa aparte con `alpha_composite`.
- Cinco agentes en paralelo funcionaron porque el contrato de API (5 rutas con JSON exacto) y el esquema de `estado.json` estaban cerrados antes de arrancar; uno escribio en otro proyecto por un `cd` encadenado: rutas absolutas siempre.
- Trampas de integracion: `<iframe loading="lazy">` dentro de `hidden` tarda 3 s en cargar; faster-whisper 1.2.1 no va con PyAV 19; Playwright con `networkidle` nunca llega si la pagina sondea cada 2 s; `chrome --headless --screenshot` captura antes de que termine la transicion CSS.
- Comprobar puertos con `lsof -i :<puerto>` antes de arrancar: 8765 y 8787 estaban ocupados en la Mac del docente; se usaron 8766 y 8797.
