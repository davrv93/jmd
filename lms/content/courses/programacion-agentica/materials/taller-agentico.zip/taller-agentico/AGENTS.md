# AGENTS.md - taller de programacion agentica

Reglas de trabajo para agentes (Codex, GPT y similares). Generado por
instalar.sh a partir de skills/*/SKILL.md; no editar a mano, volver a
ejecutar `bash instalar.sh`.

Skills incluidos:
- accesibilidad: Aplica WCAG 2.2 nivel AA de forma práctica a una pantalla, componente o asistente con voz: contraste 4.5:1 y 3:1, foco visible y orden de tabulación, ARIA solo cuando el HTML semántico no basta, prefers-reduced-motion obligatorio, subtítulos de todo lo que dice el avatar, texto mínimo de 16 px en móvil, lectores de pantalla y regiones vivas para chat, y herramientas (axe DevTools, Lighthouse, Polypane, WhoCanUse). Úsalo cuando pidan "accesibilidad", "a11y", "WCAG", "contraste", "lector de pantalla", "teclado", "aria", "subtítulos", "daltonismo", "reduced motion" o "que lo pueda usar todo el mundo".
- comandos-optimizados: Úsalo cuando un agente va a ejecutar comandos de terminal (bash, zsh, docker, git, npm, rg) y hay que pedirle comandos baratos en tokens, seguros ante errores y repetibles. Palabras gatillo: terminal, comando, shell, bash, logs, "muéstrame", verificar, dry-run, rsync, docker, grep, salida muy larga, gasto de contexto, tokens.
- diseno-visual: Define o revisa el sistema visual de una app web o de un avatar conversacional: tokens (color, tipografía, espaciado, radios, sombras), paletas listas (kawaii tecnológica y profesional sobria), profundidad, jerarquía y movimiento (duración, easing, anime.js, Lottie). Úsalo cuando pidan "diseño", "look and feel", "paleta", "tema", "tokens", "colores", "animación", "transición", "glassmorphism", "que se vea moderno" o "que se vea bonito".
- imagenes-locales: Genera imágenes y flyers con modelos de difusión que corren en la propia máquina (Edge AI, sin nube) y elige el nivel que cada equipo aguanta: sd-turbo, sdxl-turbo o FLUX.2 Klein con mflux; tubería de flyer donde el LLM extrae los datos, la difusión pinta solo el fondo y Pillow compone el texto; descargas de Hugging Face sin colgarse; medición real de memoria. Palabras gatillo: imagen local, generar imagen, flyer, afiche, póster, difusión, stable diffusion, sd-turbo, sdxl-turbo, FLUX, mflux, diffusers, Hugging Face, "las letras salen mal", "texto inventado", VRAM, "qué modelo cabe en mi máquina".
- obra-en-vivo: Mostrar el proyecto en construccion mientras el agente trabaja: barra de estado, linea de tiempo y status line. Usar al arrancar cualquier plan de trabajo y al cerrar cada tarea.
- piedra: Modo de respuesta ultracompacto del taller. Úsalo cuando el usuario escriba /piedra o "modo piedra", pida respuestas cortas, menos tokens, "sin relleno", "al grano", o cuando el contexto se esté agotando. Se apaga con "modo normal".
- plan-de-trabajo: Úsalo cuando ya existe un PLAN_PROYECTO.md (o un alcance claro) y hay que convertirlo en fases con tareas atómicas de 45 minutos, cada una con criterio de aceptación verificable, hitos demostrables y registro de avance. Palabras gatillo: plan de trabajo, tareas, fases, hitos, desglose, cronograma, "qué sigue", avance, estado del plan, obra.
- planificacion-proyecto: Úsalo cuando alguien llega con un pedido vago ("quiero un sistema de…", "necesito una app que…", "automatiza esto") y hay que cerrar alcance en 30 minutos. Palabras gatillo: planificar, alcance, proyecto nuevo, qué entra y qué no, MVP, propuesta, estimar, descubrimiento, "hecho significa".
- pruebas-de-rendimiento: Úsalo cuando hay que medir si algo es rápido de verdad y decidir pasa/no pasa con números: web (Lighthouse, LCP, INP, CLS, peso de JS), escenas Three.js (draw calls, triángulos, fps en móvil), backend (k6, hey, oha, p50/p95/p99), modelos locales (tokens/s de Ollama) y transcripción (factor de tiempo real de Whisper). Palabras gatillo: lento, rendimiento, performance, Lighthouse, fps, latencia, p95, carga, tokens por segundo, benchmark, presupuesto de peso.
- pruebas-de-uso: Úsalo cuando hay una pantalla, flujo o asistente (con texto o con voz) que ya funciona y hay que saber si una persona real lo entiende y lo termina sin ayuda. Palabras gatillo: prueba de usabilidad, usuarios reales, pensar en voz alta, SUS, hallazgos, severidad, "¿lo entienden?", test con usuarios, piloto, observar.
- relevar-maquinas: Antes de un taller o una demo con modelos locales (Ollama, Whisper, difusión de imágenes), relevar la máquina de cada alumno (SO, RAM, GPU, VRAM), decidir qué nivel le toca, qué descargar y cómo repartirlo sin colgar la red del aula, y qué decir a quien tiene AMD o Intel integrada. Palabras gatillo: relevar máquinas, qué laptop tienen, requisitos del taller, "¿le corre?", VRAM, GPU de los alumnos, descargar modelos antes de clase, USB, diagnóstico, "no tengo NVIDIA", AMD, ROCm, taller con Edge AI.
- responsividad: Haz que una pantalla web funcione en teléfono, tableta y escritorio con enfoque móvil primero: puntos de corte (360/393/768/1024/1440), unidades fluidas con clamp(), container queries, grid auto-fit, tipografía fluida, imágenes srcset, zonas táctiles de 44 px y prueba a 393 px en Chrome. Úsalo cuando pidan "responsive", "adaptable", "que se vea bien en el celular", "móvil", "tablet", "se corta en el teléfono", "scroll horizontal" o "breakpoints".
- ui-componentes: Construye o revisa componentes de interfaz con todos sus estados: botón, campo, tarjeta, modal, toast, barra de estado, chat (burbujas e indicador de escribiendo) y panel lateral; estados reposo/hover/foco/activo/deshabilitado/cargando/error/vacío, foco visible y diálogos propios en vez de nativos. Úsalo cuando pidan "botón", "formulario", "input", "modal", "diálogo", "toast", "notificación", "tarjeta", "card", "chat", "burbuja", "sidebar", "drawer", "componente" o "¿qué componente uso para…?".
- ux-flujos: Diseña o revisa el flujo de una tarea de usuario: mapa de tareas, camino feliz y caminos de error, principios de usabilidad, microcopy en español claro, estados vacíos útiles, carga percibida (esqueletos, actualización optimista) y, para asistentes conversacionales, turnos, confirmación de acciones y mostrar lo que escuchó el micrófono antes de actuar. Úsalo cuando pidan "flujo", "experiencia", "UX", "pasos", "onboarding", "wizard", "asistente", "chatbot", "avatar", "voz", "el usuario se pierde", "textos de la interfaz", "mensajes de error" o "qué pasa si falla".

---

# Skill: accesibilidad

## Versión corta para modelos pequeños

Sigue estas órdenes al pie de la letra:

1. Pon `<html lang="es">`. Una sola `<h1>`. Encabezados en orden: h1, h2, h3.
2. Usa `<button>` para acciones, `<a href>` para enlaces, `<label for>` para cada campo. Nunca `div` clicable.
3. Texto normal: contraste 4.5:1 con el fondo. Texto grande, bordes e iconos: 3:1. Mídelo; no lo adivines.
4. Texto de lectura: mínimo 16 px, escrito como `1rem`.
5. Foco visible: `:focus-visible { outline: 2px solid #1F4FBF; outline-offset: 2px; }`. Nunca `outline: none` solo.
6. Recorre la pantalla con Tab. Todo debe alcanzarse en orden y nada debe quedar atrapado.
7. Modal: Escape cierra y el foco vuelve al botón que lo abrió.
8. Cada imagen tiene `alt`. Si es decorativa, `alt=""`. Botones de solo icono llevan `aria-label`.
9. Errores de campo: `aria-invalid="true"` y texto del error unido con `aria-describedby`.
10. Toda animación va dentro de `@media (prefers-reduced-motion: no-preference)`.
11. Todo lo que el avatar dice por voz se escribe también en pantalla, al mismo tiempo. Pon un botón "Silenciar voz".
12. Chat: la lista tiene `role="log" aria-live="polite"`. Errores con `role="alert"`.
13. Nunca indiques un estado solo con color: añade icono o texto.
14. Nunca `user-scalable=no` en el viewport. Nunca `tabindex` mayor a 0. Nunca autoplay de audio.
15. Antes de entregar: corre axe DevTools y Lighthouse (Accesibilidad 95 o más) y navega una vez solo con teclado.

---

# Skill: comandos-optimizados

## Versión corta para modelos pequeños

Al ejecutar comandos de terminal, sigue estas reglas en cada comando.

1. Un solo comando compuesto con `&&`. Termina con `&& echo LISTO`.
2. Recorta la salida: agrega `| tail -n 20` o `| head -n 20` o `| wc -l`.
3. Nunca muestres un log completo. Usa `tail -n 30` y filtra con `grep -i error`.
4. Para saber si existe un archivo: `test -f /ruta && echo sí || echo no`.
5. Para saber si una web responde: `curl -sf -o /dev/null -w "%{http_code}\n" URL`.
6. Antes de borrar o sobrescribir: ejecuta primero con `-n` o `--dry-run`. Espera confirmación.
7. Usa rutas absolutas. Nunca `cd` solo.
8. Nunca imprimas claves ni tokens. Usa `test -n "$VAR" && echo presente || echo falta`.
9. Usa `rg` en vez de `grep -r`. Usa `fd` en vez de `find`. Si no existen, usa los normales con filtro.
10. Pon `timeout 60` antes de comandos de red o de build.
11. Instala dependencias una sola vez: `npm ci --prefer-offline`.
12. Si la salida es larga, guárdala en un archivo y muestra solo `wc -l`.

Prohibido sin confirmación: `rm -rf`, `git reset --hard`, `git push --force`, `docker compose down`, `DROP`, `TRUNCATE`.

---

# Skill: diseno-visual

## Versión corta para modelos pequeños

Sigue estas órdenes al pie de la letra:

1. Escribe todos los colores, tamaños y sombras como variables CSS en `:root`. No repitas valores sueltos.
2. Usa UN color primario, UN acento y cuatro semánticos: éxito, aviso, error, info.
3. Define los mismos tokens para modo oscuro dentro de `@media (prefers-color-scheme: dark)`.
4. Texto de cuerpo: 16 px, interlineado 1.5. Títulos: peso 600 o 700.
5. Espacios: 4, 8, 12, 16, 24, 32, 48, 64 px. Ningún otro.
6. Radios: 6, 12 o 20 px. Botones redondos: 999 px.
7. Sombras suaves, dos capas, opacidad menor a 0.12. Nunca sombra negra dura.
8. Paleta kawaii: fondo `#FDF8FF`, texto `#2B2440`, lila `#B9A7F5`, rosa `#FFC9DE`, menta `#BDEBD9`. Texto siempre oscuro sobre pastel.
9. Paleta sobria: fondo `#F6F7F9`, texto `#1A1F2B`, azul `#1F4FBF`, borde `#DDE1E7`.
10. Entradas: 250 ms, `cubic-bezier(0.16, 1, 0.3, 1)`. Salidas: 180 ms, `cubic-bezier(0.7, 0, 0.84, 0)`.
11. Anima SOLO `transform` y `opacity`.
12. Toda animación va dentro de `@media (prefers-reduced-motion: no-preference)`.
13. Para secuencias usa anime.js 4.5.0 desde cdnjs, importa `animate` y `stagger`, y el parámetro se llama `ease`.
14. Prohibido: `alert`, `confirm`, `prompt`, parallax, más de dos colores de acento, texto blanco sobre pastel.
15. Al terminar, comprueba el contraste del texto: mínimo 4.5:1.

---

# Skill: imagenes-locales

## Versión corta para modelos pequeños

Generas imágenes con un modelo de difusión local. Sigue estas órdenes:

1. Antes de descargar, corre `python backend/diagnostico.py`. Usa el nivel que diga; no bajes modelos más grandes.
2. Niveles: rápida = sd-turbo (2,4 GB, 5 GB de RAM, 2 s en Mac M). Buena = sdxl-turbo (7 GB, 12 GB de RAM, 7 s). Máxima = FLUX.2 Klein con mflux (4,6 GB, 8 GB de RAM, 45 s, solo Mac con 16 GB o más).
3. Tope: NVIDIA con 6 GB o más de VRAM → sdxl-turbo. Menos → sd-turbo. Solo CPU con 24 GB o más → sdxl-turbo; si no, sd-turbo. AMD o Intel en Windows → CPU.
4. Descarga con `HF_HUB_DISABLE_XET=1` y solo `*.fp16.safetensors`. Una descarga a la vez. Nunca en clase.
5. El modelo de difusión NO escribe texto. Nunca le pidas letras, pantallas ni código. Pídele objetos, luces y formas.
6. Para un flyer: primero regex de fecha, hora y precio. Después el LLM devuelve un JSON con título, subtítulo, descripción, lugar, ponente, contacto y `tema_visual` en inglés sin letras. El regex manda sobre el LLM.
7. Prohíbe al LLM marcas y apodos en el título.
8. Pinta solo el fondo en vertical. Compón el texto con Pillow a 1080x1350: título con sombra, chips de fecha, hora y lugar, insignia de precio.
9. En Pillow, un chip semitransparente se dibuja con color sólido calculado a mano. `ImageDraw` no mezcla alfa.
10. Devuelve al usuario los datos extraídos para que corrija antes de regenerar.
11. Un solo modelo en memoria. Cambiar de nivel descarga el anterior.
12. Mide memoria en Mac con `footprint -p <pid>`, no con `ps`.

Prohibido: texto dibujado por el modelo. Prohibido: cargar por encima del tope. Prohibido: dos descargas o dos modelos a la vez.

---

# Skill: obra-en-vivo

## Version corta para modelos pequenos

Manten visible el avance del proyecto con `obra/obra.py`. No edites
`estado.json` a mano.

1. Al empezar:
   `python3 obra/obra.py iniciar "<proyecto>" --pasos "<paso 1>" "<paso 2>" ...`
   `python3 obra/obra.py servir &` y di al usuario que abra
   `http://localhost:8787/obra.html`.
2. Antes de trabajar en una tarea:
   `python3 obra/obra.py paso "<texto del paso>" --fase <Plan|Backend|Frontend|Pruebas|Entrega>`
   Esto cierra el paso anterior como hecho y abre este.
3. Si una tarea falla: `python3 obra/obra.py error "<motivo corto>"`.
4. Al terminar la ultima: `python3 obra/obra.py hecho`.
5. Para ver en terminal: `python3 obra/obra.py ver`.

Reglas:
- Solo marca un paso como hecho despues de verificarlo (ejecutar la prueba o
  abrir la pantalla). Nunca por suposicion.
- Un paso = una tarea del plan. Texto en espanol, 60 caracteres o menos, sin
  rutas ni nombres tecnicos.
- No saltes pasos sin decirlo al usuario.
- Apaga el servidor al terminar; no borres `estado.json`.

---

# Skill: piedra

## Versión corta para modelos pequeños

Cuando el usuario diga `/piedra` o "modo piedra", responde así hasta que diga "modo normal".

1. Responde "Modo piedra activo." y nada más en ese turno.
2. Escribe frases de máximo 20 palabras.
3. Una idea por frase.
4. No saludes. No agradezcas. No expliques que vas a explicar.
5. Quita "el", "la", "los", "un", "una" si la frase se entiende igual.
6. Nunca quites: no, nunca, solo, excepto, sin, ni.
7. Copia exactos: números, unidades, rutas, comandos, mensajes de error. Ponlos entre comillas invertidas.
8. No inventes abreviaturas. No uses flechas.
9. Da instrucciones con verbos en imperativo: "Ejecuta", "Cambia", "Verifica".
10. Si vas a describir borrar, sobrescribir, desplegar o enviar algo: escribe frases completas y pide confirmación.
11. Si el usuario dice "no entendí": escribe frases completas hasta que diga que entendió.
12. Código, commits, documentos y correos: siempre en prosa normal.
13. Cuando el usuario diga "modo normal", responde "Modo normal activo." y vuelve a escribir como siempre.

Ejemplo. Pregunta: "¿Está corriendo el contenedor?". Respuesta en piedra: "Sí. `docker ps` muestra `Up 3 hours`."

---

# Skill: plan-de-trabajo

## Versión corta para modelos pequeños

Tienes una lista de entregables. Produce `PLAN_TRABAJO.md` con la plantilla de arriba.

1. Crea Fase 0 "Preparación" con máximo 5 tareas: repo, entorno, datos de prueba.
2. Cada entregable es una fase.
3. Escribe tareas en imperativo: "Crear…", "Probar…", "Conectar…".
4. Cada tarea dura 45 minutos o menos. Si dura más, divídela en dos.
5. Cada tarea tiene criterio de aceptación. El criterio es un comando o una acción que responde sí o no.
6. Pon la columna "Depende de" con el ID de la tarea previa.
7. Estado inicial: `pendiente`. Estados permitidos: pendiente, en curso, hecha, bloqueada.
8. Al empezar una tarea: cámbiala a `en curso`. Solo una a la vez.
9. Al terminar: ejecuta el criterio. Si da sí, marca `hecha` y anota fecha y hora.
10. Si existe `obra/obra.py`, ejecuta tras cada cierre: `python obra/obra.py paso "F1-T2 nombre" --pct 40`. El número es hechas dividido por total por 100.
11. Cada fase termina en un hito: qué se muestra y a quién.
12. Las tareas nuevas van al final de la fase con prefijo `(nueva)`.

Prohibido: tarea sin criterio. Prohibido: marcar `hecha` sin ejecutar el criterio. Prohibido: borrar tareas o renumerar IDs.

---

# Skill: planificacion-proyecto

## Versión corta para modelos pequeños

Recibes un pedido vago. Produce `PLAN_PROYECTO.md`.

1. Copia el pedido literal entre comillas.
2. Haz máximo 7 preguntas de esta lista: quién lo usa, qué pasa si no se hace, qué dato existe, cómo se demuestra en 5 minutos, qué no debe hacer nunca, quién aprueba, qué infraestructura hay.
3. Lo que no se responda, escríbelo como "Supongo que …".
4. Escribe el usuario en una línea: rol, lugar, dispositivo, frecuencia.
5. Escribe "Hecho significa" en 3 frases en pasado. Cada frase se debe poder mostrar funcionando.
6. Lista de 3 a 6 entregables. Cada uno empieza con "El usuario puede …".
7. Da talla a cada uno: S = medio día, M = 1 a 2 días, L = 3 a 5 días. Escribe la leyenda.
8. Lista riesgos. Cada riesgo lleva una acción y un responsable.
9. Escribe "No entra en esta versión" con al menos 3 ítems.
10. No pongas fechas.
11. Usa la plantilla de arriba tal cual.

Prohibido: entregables como "base de datos" o "API" sueltos. Prohibido: más de 7 preguntas. Prohibido: inventar respuestas del cliente.

---

# Skill: pruebas-de-rendimiento

## Versión corta para modelos pequeños

Mide con estos comandos y compara con el umbral. Corre cada uno 3 veces. Usa la mediana.

1. Web: `npx lighthouse URL --only-categories=performance --output=json --output-path=lh.json --chrome-flags="--headless" --quiet`
2. Leer: `jq '.audits["largest-contentful-paint"].numericValue, .audits["cumulative-layout-shift"].numericValue, .audits["total-blocking-time"].numericValue' lh.json`
3. Umbrales web: LCP menor de 2500 ms. CLS menor de 0,1. TBT menor de 200 ms.
4. Peso JS: `for f in dist/assets/*.js; do gzip -9 -c "$f" | wc -c; done | awk '{s+=$1} END {print s/1024 " KB"}'`. Umbral: menor de 300 KB.
5. Tramo de código: `const t0=performance.now(); ...; console.log(performance.now()-t0)`.
6. Three.js: imprime `renderer.info.render.calls` y `renderer.info.render.triangles` cada segundo. Umbral: 60 fps, menos de 100 calls.
7. API: `hey -z 30s -c 20 URL | grep -E "50%|95%|99%"`. Umbral: p95 menor de 500 ms, p99 menor de 1000 ms.
8. Alternativa: `oha -z 30s -c 20 --no-tui URL`.
9. Ollama: `ollama run qwen3:1.7b --verbose "hola" 2>&1 | grep "eval rate"`. Umbral: más de 15 tokens/s.
10. Whisper: `ffprobe -v error -show_entries format=duration -of csv=p=0 audio.wav` y `time whisper audio.wav --model small --language es`. RTF = tiempo / duración. Umbral: menor de 0,5.
11. Anota cada resultado en la tabla MEDICIONES.md.
12. Si no pasa, abre tarea en PLAN_TRABAJO.md.

Prohibido: carga contra producción en horario de uso. Prohibido: escribir el token real. Prohibido: reportar la mejor corrida en lugar de la mediana.

---

# Skill: pruebas-de-uso

## Versión corta para modelos pequeños

Ayuda a preparar y registrar una prueba de uso con 5 personas.

1. Escribe el objetivo en una frase.
2. Escribe de 3 a 5 tareas como situaciones: "Terminaron la losa. Deja constancia". No menciones botones.
3. Para cada tarea: qué cuenta como éxito y cuántos minutos máximo.
4. Al inicio di al usuario: "Piensa en voz alta. No te voy a ayudar. Probamos el sistema, no a ti".
5. Lee la tarea literal. Cronometra.
6. Anota: logró sí/no, tiempo, errores, pausas largas, frases textuales.
7. No ayudes. Si pregunta dónde está algo, responde "¿dónde crees tú?".
8. Si es con voz, tras cada turno pregunta: "¿Qué crees que entendió el sistema?". Compara con la transcripción.
9. Al final entrega las 10 preguntas SUS. Calcula: impares resta 1, pares resta de 5, suma, multiplica por 2,5.
10. Severidad: 1 cosmético, 2 menor, 3 frena, 4 impide o produce dato falso sin que se note.
11. Cada hallazgo lleva cita o acción observada.
12. Informe en una página con la plantilla. Propón corrección para severidad 3 y 4.

Prohibido: ayudar durante la tarea. Prohibido: probar con gente del equipo. Prohibido: hallazgo sin evidencia.

---

# Skill: relevar-maquinas

## Versión corta para modelos pequeños

Vas a preparar un taller donde cada alumno corre modelos en su laptop. Sigue estas órdenes:

1. Pide a cada alumno cuatro datos: sistema operativo, RAM, tarjeta de video, VRAM. Usa la plantilla de mensaje de arriba.
2. Haz una tabla: alumno, SO, RAM, GPU, VRAM, nivel, instalación.
3. Asigna nivel: NVIDIA con 6 GB o más de VRAM → buena (sdxl-turbo). NVIDIA con menos → rápida (sd-turbo). AMD o Intel en Windows → CPU; buena solo con 24 GB de RAM, si no rápida. Mac con 16 GB o más → máxima (FLUX con mflux). Sin GPU → rápida en CPU.
4. RTX 50: `pip install torch --index-url https://download.pytorch.org/whl/cu128`. Otras NVIDIA: `cu126`. El resto: torch normal.
5. Pide a cada alumno que corra `python backend/diagnostico.py` y pegue la salida. El nivel que imprime manda sobre tu tabla.
6. Descarga los modelos la noche anterior con `HF_HUB_DISABLE_XET=1`, uno a la vez. Nunca en el aula.
7. Copia la carpeta `models--stabilityai--sd-turbo` de `~/.cache/huggingface/hub/` a un USB y repártela.
8. A quien tiene AMD o Intel integrada dile: "va por CPU, tarda de 25 a 60 s por imagen, no instales drivers".
9. Escribe la tabla final en el plan de trabajo con la fecha.

Prohibido: empezar sin la tabla llena. Prohibido: descargar en clase. Prohibido: pedir a AMD en Windows que use la GPU.

---

# Skill: responsividad

## Versión corta para modelos pequeños

Sigue estas órdenes al pie de la letra:

1. Pon `<meta name="viewport" content="width=device-width, initial-scale=1">`.
2. Escribe primero el CSS para 360 px: una columna, padding 16 px, botones a ancho completo.
3. Usa `@media (min-width: 768px)` para dos columnas y `@media (min-width: 1024px)` para la barra lateral fija. Nunca `max-width`.
4. Texto de cuerpo: `font-size: 1rem` mínimo (16 px). Títulos con `clamp(1.5rem, 1.1rem + 2vw, 2.5rem)`.
5. Rejillas: `grid-template-columns: repeat(auto-fit, minmax(min(100%, 280px), 1fr))`.
6. Imágenes: `max-width: 100%; height: auto;` más atributos `width` y `height` en el HTML.
7. Botones e iconos clicables: `min-height: 44px; min-width: 44px`.
8. Tablas: envuélvelas en un `div` con `overflow-x: auto`. No encojas la letra.
9. Altura completa: `min-height: 100dvh`, no `100vh`.
10. Campos numéricos: `inputmode="numeric"` o `"decimal"`.
11. Prohibido: scroll horizontal de página, `user-scalable=no`, anchos fijos en píxeles, texto menor a 16 px.
12. Al terminar, abre Chrome DevTools a 393 px y a 360 px. Si hay barra horizontal, no está terminado.

---

# Skill: ui-componentes

## Versión corta para modelos pequeños

Sigue estas órdenes al pie de la letra:

1. Para acciones usa `<button>`. Para ir a otra página usa `<a href>`. Nunca `div` con `onclick`.
2. Cada botón tiene estos estados en CSS: `:hover`, `:focus-visible`, `:active`, `:disabled`, `[aria-busy="true"]`.
3. Foco: `outline: 2px solid var(--color-primario); outline-offset: 2px;`. Nunca `outline: none`.
4. Botones miden al menos 44 px de alto. Un solo botón relleno (primario) por pantalla.
5. Mientras carga: deshabilita el botón, escribe "Guardando…" y no cambies su ancho.
6. Campos: etiqueta visible con `<label for>`. El placeholder es un ejemplo, no la etiqueta.
7. Error en campo: borde rojo, texto debajo que dice cómo arreglarlo, `aria-invalid="true"`.
8. Lista vacía: icono, una frase y un botón para crear el primer elemento.
9. Confirmar o pedir un dato: usa `<dialog>` con `showModal()`. Prohibido `alert`, `confirm`, `prompt`.
10. Modal: Escape cierra, hay botón Cancelar, el foco vuelve al botón que lo abrió.
11. Toast: aparece abajo, dura 4 s, se puede cerrar, va en un contenedor con `aria-live="polite"`. Errores graves no usan toast.
12. Chat: lista con `role="log" aria-live="polite"`, burbujas del usuario a la derecha, indicador de tres puntos con `aria-label="El asistente está escribiendo"`.
13. Panel lateral: ancho completo en móvil, cierra con Escape, botones de acción siempre visibles abajo.
14. Prueba todo con la tecla Tab y a 393 px de ancho antes de entregar.

---

# Skill: ux-flujos

## Versión corta para modelos pequeños

Sigue estas órdenes al pie de la letra:

1. Escribe la tarea en una frase: quién, qué verbo, qué objeto.
2. Lista los pasos del camino feliz. Quita todo paso que no sea una decisión del usuario.
3. Para cada paso escribe qué pasa si: dato inválido, sin internet, sin permiso, falla el servidor.
4. Cada error dice: qué pasó, por qué, qué hacer, y tiene un botón para hacerlo.
5. No preguntes lo que el sistema ya sabe (usuario, fecha, obra actual).
6. Botones con verbo y objeto: "Guardar avance", no "OK".
7. Confirmación destructiva: nombra el objeto y la consecuencia. Nunca solo "¿Está seguro?".
8. Pantalla sin datos: una frase de qué va aquí y un botón para crear el primero.
9. Espera de 300 ms a 2 s: esqueleto gris con la forma del contenido. Más de 2 s: texto que dice qué está haciendo.
10. Habla siempre de "tú" (o siempre de "usted"). No mezcles.
11. Asistente: una pregunta por turno. Antes de crear, borrar, enviar o pagar, muestra lo que entendió y pide "Confirmar".
12. Micrófono: muestra la transcripción en pantalla, deja corregirla, y envía solo cuando el usuario toque "Enviar".
13. Todo lo que el avatar dice en voz también se escribe en una burbuja.
14. Nunca pierdas lo que el usuario escribió: guarda borrador si falla algo.

