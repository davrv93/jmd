# Instala las skills del taller «¿Difícil de explicar? ¡No!» para JMD, Claude Code y OpenCode (Windows).
# Uso: .\instalar.ps1 [carpeta]   (la carpeta que contiene skills\; por defecto, la actual)
param([string]$Raiz = ".")
Set-Location $Raiz
if (-not (Test-Path "skills")) {
  Write-Error "No encuentro la carpeta skills\ en $(Get-Location). Entra a la carpeta donde descomprimiste el zip."
  exit 1
}
$destinos = @("$HOME\.claude\skills", "$HOME\.config\jmd\skills")
foreach ($d in $destinos) { New-Item -ItemType Directory -Force -Path $d | Out-Null }
New-Item -ItemType Directory -Force -Path "prompts" | Out-Null
$n = 0
Get-ChildItem -Directory "skills" | ForEach-Object {
  $skill = Join-Path $_.FullName "SKILL.md"
  if (-not (Test-Path $skill)) { return }
  $nombre = $_.Name
  foreach ($d in $destinos) {
    $dst = Join-Path $d $nombre
    if (Test-Path $dst) { Remove-Item -Recurse -Force $dst }
    Copy-Item -Recurse $_.FullName $dst
  }
  $lineas = Get-Content $skill
  $i = [array]::IndexOf($lineas, ($lineas | Where-Object { $_ -like "## Versión corta*" } | Select-Object -First 1))
  if ($i -ge 0) {
    $lineas[($i+1)..($lineas.Length-1)] | Where-Object { $_ -notlike '```*' } | Set-Content "prompts\$nombre.txt" -Encoding UTF8
  }
  Write-Host "  OK $nombre -> $HOME\.claude\skills y $HOME\.config\jmd\skills (versión corta: prompts\$nombre.txt)"
  $n++
}
Write-Host "Skills encontrados : $n"
Write-Host "Comprueba con: jmd skills   (Claude Code y OpenCode leen ~\.claude\skills solos)"
