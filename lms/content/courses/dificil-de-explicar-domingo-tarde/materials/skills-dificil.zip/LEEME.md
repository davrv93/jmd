# skills-dificil · las dos skills del taller «¿Difícil de explicar? ¡No!»

- `skills/pedido-seis-partes/SKILL.md`: cómo escribir y revisar un pedido a la IA con rol, contexto,
  tarea, límites, formato y comprobación, y cómo corregir con un segundo pedido preciso.
- `skills/animacion-abierta/SKILL.md`: construir piezas animadas y video con herramientas abiertas
  (HTML, CSS, SVG, JavaScript, Playwright y FFmpeg): la pieza como línea de tiempo, el estilo
  «Difícil de explicar», cámara, profundidad, principios de animación y las reglas sobre Willie.

## Instalar

```bash
bash instalar.sh .        # macOS, Linux y WSL
```

```powershell
.\instalar.ps1            # Windows (PowerShell)
```

Copia cada skill a `~/.claude/skills/` (la leen Claude Code y OpenCode) y a `~/.config/jmd/skills/`
(la lee `jmd`), y deja en `prompts/` la versión corta de cada una para pegarla como system prompt
en DeepSeek u Ollama. Termina con «Skills encontrados : 2». Comprueba con `jmd skills`.

## Usar

En el chat del agente: `usa las skills pedido-seis-partes y animacion-abierta` y después pega el
prompt de seis partes (está en Materiales de la sesión 1, «Prompt para ejecutar»). En `jmd`, también
`/skill animacion-abierta <pedido>`.

Las skills son de solo lectura en el curso; una vez copiadas, son tuyas: edítalas.
