#!/bin/sh
# Instala las skills del taller «¿Difícil de explicar? ¡No!» para JMD, Claude Code y OpenCode.
# Uso: bash instalar.sh [carpeta]   (la carpeta que contiene skills/; por defecto, la actual)
set -e
RAIZ="${1:-.}"
cd "$RAIZ"
if [ ! -d skills ]; then
  echo "No encuentro la carpeta skills/ en $(pwd). Entra a la carpeta donde descomprimiste el zip." >&2
  exit 1
fi
mkdir -p "$HOME/.claude/skills" "$HOME/.config/jmd/skills" prompts
n=0
for d in skills/*/; do
  [ -f "$d/SKILL.md" ] || continue
  nombre=$(basename "$d")
  rm -rf "$HOME/.claude/skills/$nombre" "$HOME/.config/jmd/skills/$nombre"
  cp -r "$d" "$HOME/.claude/skills/$nombre"
  cp -r "$d" "$HOME/.config/jmd/skills/$nombre"
  # Versión corta (para DeepSeek, Ollama y otros modelos pequeños): desde «## Versión corta» hasta el final.
  awk '/^## Versión corta/{f=1} f' "$d/SKILL.md" | sed '1d' | sed '/^```/d' > "prompts/$nombre.txt"
  echo "  ✓ $nombre → ~/.claude/skills y ~/.config/jmd/skills (versión corta: prompts/$nombre.txt)"
  n=$((n+1))
done
echo "Skills encontrados : $n"
echo "Comprueba con: jmd skills   (Claude Code y OpenCode leen ~/.claude/skills solos)"
