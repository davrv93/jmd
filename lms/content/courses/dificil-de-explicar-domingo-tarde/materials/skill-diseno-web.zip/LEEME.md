# skill-diseno-web · diseña tu web sin programar

`skills/diseno-web/` diseña la web de un negocio y entrega un **tablero de diseño** en un solo HTML
para que el cliente lo apruebe antes de programar: objetivo y público, mapa del sitio, wireframes en
gris a 1280 y 360 px sobre la rejilla, portada en alta fidelidad con el pliegue marcado, guía de estilo
(paleta con contrastes calculados, tipografías, espaciado de 8 px, botones y estados, iconos),
componentes, reglas de dimensión y checklist.

- `skills/diseno-web/SKILL.md`: la skill (reglas y procedimiento).
- `skills/diseno-web/motor/tablero.mjs`: el motor (Node o Bun, sin dependencias). Valida las reglas.
- `skills/diseno-web/motor/diseno.plantilla.json`: el brief que llenas.
- `skills/diseno-web/motor/ejemplos/`: una perfumería y un restaurante completos.
- `skills/diseno-web/motor/capturar.sh`: captura PNG con Chrome headless (opcional).

## Instalar

```bash
bash instalar.sh .        # macOS, Linux y WSL
```

```powershell
.\instalar.ps1            # Windows (PowerShell)
```

Copia la skill a `~/.claude/skills/` (Claude Code y OpenCode) y a `~/.config/jmd/skills/` (`jmd`), y deja
en `prompts/diseno-web.txt` la versión corta para pegarla como system prompt en DeepSeek u Ollama.

## Usar sin agente

```bash
cp skills/diseno-web/motor/diseno.plantilla.json diseno.json   # llénalo con los datos de tu cliente
node skills/diseno-web/motor/tablero.mjs diseno.json --salida tablero.html
```

Si sale `ERROR`, corrige `diseno.json` y vuelve a generar. Abre `tablero.html` en el navegador.
