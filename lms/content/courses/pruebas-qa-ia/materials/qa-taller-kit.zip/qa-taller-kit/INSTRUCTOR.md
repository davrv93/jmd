# Guía del instructor (NO compartir con los alumnos antes del taller)

Domingo 1-11-2026 · 9:00–13:00 (Lima) · Zoom

## Los defectos sembrados

Se activan por defecto (`BUGS=1`). Con `BUGS=0` la app sale corregida y todo pasa en verde.
Ambos viven en el **front** (`app/publico/js/venta.js`) detrás de banderas que entrega
`/js/config.js` — parecen «feature flags» reales, no comentarios que digan «bug».

### Defecto A — el POS cobra el total aunque el efectivo no alcance
- Bandera `cobroExacto`: «pensada para tarjeta». En `confirmar()`:
  `const pago = TIENDA.cobroExacto ? total : efectivo;` → envía al servidor `efectivo = total`.
- Efecto: con S/ 5.00 para S/ 17.01 la venta **se registra** y el comprobante dice «Vuelto S/ 0.00».
  También rompe el vuelto de una venta normal: con S/ 50 por S/ 29.50 dice «Vuelto S/ 0.00».
- Lo detectan: **E2E-VEN-002** (pago insuficiente) y **E2E-VEN-001** (vuelto del comprobante).
- **No** lo detecta **API-VEN-001**: el servidor valida bien y responde 422. Esta es LA lección:
  *el servidor está bien, el defecto está en la pantalla; una suite solo de API no lo ve.*

### Defecto B — la promo de 10 % se aplica dos veces al recalcular
- Bandera `recalculoIncremental` («optimización»). Al cambiar la cantidad, `recalcularLinea()`
  aplica el descuento sobre el precio **ya descontado**: 18.90 → 17.01 → 15.31.
- Efecto: Café Altomayo × 2 muestra **S/ 30.62** en vez de **S/ 34.02**. Si el cajero cobra lo que
  ve, el servidor (que calcula bien) responde «Efectivo insuficiente: el total es S/ 34.02»: un
  cliente confundido en caja.
- Lo detecta: **E2E-VEN-003**. Solo se ve al **cambiar la cantidad** (agregar dos veces desde el
  catálogo no lo dispara): buen ejemplo de flujo alterno que nadie prueba a mano.

### Resultado esperado

| | API (8) | Chromium | Lightpanda | Obscura |
|---|---|---|---|---|
| `BUGS=1` (por defecto) | 8 ✓ | 11 ✓ · 3 ✗ (VEN-001/002/003) · 1 omitida (visual) | 11 ✓ · 3 ✗ | 11 ✓ · 3 ✗ |
| `BUGS=0` | 8 ✓ | 14 ✓ · 1 omitida | 14 ✓ | 13 ✓ · 1 ✗ (VEN-003, limitación de Obscura) |

La visual se omite hasta que alguien corre `npm run test:visual:base` en su máquina.

## Antes de empezar (8:30)

```bash
cd ~/Documents/qa-taller-kit
cd pruebas && npm install && npx playwright install chromium && cd ..
cd motores && docker compose up -d && cd ..         # Lightpanda 9222, Obscura 9223
docker pull prom/prometheus:v3.15.1 prom/blackbox-exporter:v0.29.1 grafana/grafana:13.3.0
cd pruebas && npm run test:todos; npm run portal     # deja el portal listo con la corrida en rojo
```

Ten abiertas 4 terminales: `app/` (npm start), `pruebas/`, `monitoreo/` y una libre.

## Guion por bloque

### 9:00 · QA con IA y POM (45 min)
1. Muestra la app (`cd app && npm start`, <http://localhost:3000>): login, catálogo, venta, reporte, `/salud`.
2. `docs/casos-de-uso.md` → `docs/matriz.csv`: de un flujo alterno sale un caso de prueba.
3. POM: abre `pages/VentaPage.ts` junto a `specs/venta.spec.ts`. Que el spec «se lea como el caso de uso».
4. IA: con `ia/prompts.md` prompt 1, pega `app/publico/reporte.html` en un asistente y compara su Page
   Object con `pages/ReportePage.ts`. Discute: ¿usó getByRole? ¿metió waitForTimeout?
5. `pruebas/AGENTS.md`: las reglas que le damos a la IA.

### 9:45 · Primeras pruebas E2E (45 min)
1. `npx playwright test specs/login.spec.ts --project=chromium` → verde. `npx playwright show-report`.
2. `npm test` → **3 rojos**. No digas cuál es el defecto: lee con ellos el mensaje en español
   (`Received: "Venta N° 1 registrada. Total S/ 17.01 · Vuelto S/ 0.00"`).
3. Pregunta: «¿el defecto está en el servidor o en la pantalla?» → `npm run test:api` sale verde.
   API-VEN-001 dice que el servidor rechaza bien. Entonces está en la pantalla.
4. `npx playwright test -g VEN-003 --headed --project=chromium` para que vean el total cambiar a 30.62.
5. Semillas: `cd app && node semilla.mjs --aleatoria` dos veces (semillas distintas) y luego con
   `--semilla=` (iguales). Explica por qué `workers: 1`.
6. Ejercicio (15 min): escribir E2E-VEN-005 (quitar producto) con la IA (prompt 2).
7. Cierra mostrando verde: `npm run test:corregido` (o `BUGS=0 npm test`).

### 10:30 · Navegadores sin interfaz (45 min)
1. `fixtures.ts`: el `browser` se lanza o se conecta por CDP según el proyecto (`motor`).
2. `npm run test:lightpanda` → mismos 3 rojos, ~2 s la suite en verde, ~20 MiB.
   En otra terminal durante la corrida: `docker stats --no-stream taller-lightpanda taller-obscura`.
3. `npm run test:obscura` → mismos 3 rojos… y luego `BUGS=0 npm run test:obscura` → **VEN-003 sigue
   rojo**. Lee el `Received: "S/ 17.01"`: Obscura no dispara `change` al perder el foco. Lección:
   **un rojo no siempre es un defecto de la app; puede ser el motor.** Compara con Chromium
   (`Received: "S/ 30.62"`).
4. Cuenta las otras dos diferencias que ya se arreglaron en la app (ver `docs/motores-resultados.md`):
   `form.usuario` no existe en Obscura y los `<a>` en línea miden 0×0.
5. Tabla de `docs/motores-resultados.md` y `docs/herramientas.md`.

### 11:15 · Portal y reproducción paso a paso (45 min)
1. `npm run test:todos && npm run portal` → abre `portal/index.html`.
2. Clic en una celda roja → error → «Abrir en el reporte HTML» → «View Trace».
3. `npx playwright show-trace test-results/…/trace.zip`: acciones, DOM antes/después, red (el POST
   a `/api/ventas` con `efectivo: 17.01` aunque se escribió 5 → evidencia del defecto A).
4. `npm run test:traza` (traza siempre) vs `retain-on-failure` (por defecto): costo vs beneficio.
5. El JSON del reporte (`pruebas/resultados/resultados.json`) → cómo lo lee `portal/generar.mjs`.

### 12:00 · Monitoreo, disponibilidad y alertas (45 min)
1. Terminal app: `npm start`. Terminal monitoreo: `node receptor.mjs`, luego `docker compose up -d`.
2. Grafana <http://localhost:3001> (abre el tablero solo). Prometheus <http://localhost:9090>, consulta `probe_success`.
3. **Romper en vivo**:
   ```bash
   curl -X POST http://localhost:3000/api/caos -H "content-type: application/json" -d '{"caida":true}'
   ```
   El tablero pasa a **CAÍDA** en ≤ 15 s; la alerta llega al receptor en ~90 s (medido: 93 s).
   Mientras esperas, explica `for: 1m` (evitar falsas alarmas) y disponibilidad (99,9 % = 43 min/mes).
4. Lentitud: `-d '{"latenciaMs":2000}'` → sube la latencia; con `{"latenciaMs":6000}` el sondeo
   (timeout 5 s) cuenta como caída.
5. Volver: `-d '{"caida":false,"latenciaMs":0}'` → llega «RESUELTA».
6. Sin Docker: `node vigia.mjs --cada=2 --webhook=http://127.0.0.1:9099/alerta`.
7. Cómo conectar Telegram / correo / WhatsApp: `monitoreo/README.md` (no envíes mensajes reales en clase).

### 12:45 · Cierre (15 min)
Matriz → pruebas → portal → monitoreo: el ciclo completo. Tarea: los 2 casos pendientes de la matriz.

## Si algo falla en vivo

| Problema | Qué decir / hacer |
|---|---|
| **Lightpanda no conecta** (`No pude conectarme a lightpanda`) | `docker compose -f motores/docker-compose.yml up -d lightpanda`; `curl http://127.0.0.1:9222/json/version` debe responder. Si Docker no está: «Lightpanda es joven (1.0 en 2026); justamente por eso medimos antes de adoptarlo». Muestra los números de `docs/motores-resultados.md`. |
| Lightpanda conecta pero una prueba se cuelga | `docker restart taller-lightpanda`. Prueba `lightpanda/browser:nightly` en el compose. Mensaje: una conexión y un contexto a la vez; `workers: 1`. |
| Alumno en Windows sin Docker | Lightpanda no tiene binario Windows: que siga con Chromium; Obscura sí tiene `.zip` para Windows (`obscura serve --port 9223 --allow-private-network`, y correr con `URL_MOTOR=http://127.0.0.1:3100`). No verificado en Windows. |
| Linux: el motor no ve la app | `HOST=0.0.0.0 npm run test:lightpanda`. |
| Puerto 3100 ocupado | Quedó una corrida colgada: cerrar, o `PUERTO=3200 npm test`. |
| Docker: «all predefined address pools have been fully subnetted» | Por eso los compose usan la red `bridge` por defecto y no crean redes nuevas. Si igual aparece: `docker network prune` (solo si sabes qué borras). |
| Grafana no muestra datos | ¿La app corre en 3000? `curl http://localhost:9115/probe?target=http://host.docker.internal:3000/salud&module=http_2xx` muestra el sondeo crudo. |
| La alerta no llega | ¿`receptor.mjs` corriendo? Mira Grafana → Alerting → Alert rules (estado Pending → Firing tarda 1 min). |

## Comandos para romper cosas en vivo

```bash
node app/servidor.mjs --caida=1                 # arranca ya caída
node app/servidor.mjs --latencia_ms=800         # todo responde lento
curl -X POST localhost:3000/api/caos -d '{"caida":true}'          # caer
curl -X POST localhost:3000/api/caos -d '{"latenciaMs":3000}'     # lentitud
curl -X POST localhost:3000/api/caos -d '{"caida":false,"latenciaMs":0}'   # sanar
BUGS=0 npm test        # (en pruebas/) versión corregida, todo verde
```

`/api/semilla` solo existe con `--modo=prueba`. `/api/caos` existe salvo con `--modo=produccion`.
