# Guía del instructor (NO compartir con los alumnos antes del taller)

Domingo 1-11-2026 · 9:00–13:00 (Lima) · Zoom

## Los defectos sembrados

Se activan por defecto (`BUGS=1`). Con `BUGS=0` la app sale corregida y todo pasa en verde.
Ambos viven en el **front** (`app/publico/js/venta.js`) detrás de banderas que entrega
`/js/config.js` — parecen «feature flags» reales, no comentarios que digan «bug».

### Defecto A — el POS cobra el total aunque el efectivo no alcance
- Bandera `cobroExacto`: «pensada para tarjeta». En `confirmar()`:
  `const pago = TIENDA.cobroExacto ? total : efectivo;` → envía al servidor `efectivo = total`.
- Efecto: con S/ 5.00 para S/ 17.01 la venta **se registra** y el comprobante dice «Vuelto S/ 0.00».
  También rompe el vuelto de una venta normal: con S/ 50 por S/ 29.50 dice «Vuelto S/ 0.00».
- Lo detectan: **E2E-VEN-002** (pago insuficiente) y **E2E-VEN-001** (vuelto del comprobante).
- **No** lo detecta **API-VEN-001**: el servidor valida bien y responde 422. Esta es LA lección:
  *el servidor está bien, el defecto está en la pantalla; una suite solo de API no lo ve.*

### Defecto B — la promo de 10 % se aplica dos veces al recalcular
- Bandera `recalculoIncremental` («optimización»). Al cambiar la cantidad, `recalcularLinea()`
  aplica el descuento sobre el precio **ya descontado**: 18.90 → 17.01 → 15.31.
- Efecto: Café Altomayo × 2 muestra **S/ 30.62** en vez de **S/ 34.02**. Si el cajero cobra lo que
  ve, el servidor (que calcula bien) responde «Efectivo insuficiente: el total es S/ 34.02»: un
  cliente confundido en caja.
- Lo detecta: **E2E-VEN-003**. Solo se ve al **cambiar la cantidad** (agregar dos veces desde el
  catálogo no lo dispara): buen ejemplo de flujo alterno que nadie prueba a mano.

### Resultado esperado

| | API (8) | Chromium | Lightpanda | Obscura |
|---|---|---|---|---|
| `BUGS=1` (por defecto) | 8 ✓ | 11 ✓ · 3 ✗ (VEN-001/002/003) · 1 omitida (visual) | 11 ✓ · 3 ✗ | 11 ✓ · 3 ✗ |
| `BUGS=0` | 8 ✓ | 14 ✓ · 1 omitida | 14 ✓ | 13 ✓ · 1 ✗ (VEN-003, limitación de Obscura) |

La visual se omite hasta que alguien corre `npm run test:visual:base` en su máquina.

## Antes de empezar (8:30)

1. **Tienda Sol en la nube arriba**: abre <https://jmd-learn.online/tienda-sol/> dos veces (ventana normal y privada) y comprueba que da dos códigos distintos y que `…/TU_CODIGO/salud` responde. Cada alumno abre esa URL y obtiene su tienda; es lo primero del taller (README §0). La app local es solo el plan B sin internet.
2. Ten tu propio código a mano: `export BASE_URL=https://jmd-learn.online/tienda-sol/TU_CODIGO` y corre `npm run escanear` para enseñar el mapa (`docs/mapa-tienda.md`) en vivo.

```bash
cd ~/Documents/qa-taller-kit
cd pruebas && npm install && npx playwright install chromium && cd ..
cd motores && docker compose up -d && cd ..         # Lightpanda 9222, Obscura 9223
docker pull prom/prometheus:v3.15.1 prom/blackbox-exporter:v0.29.1 grafana/grafana:13.3.0
cd pruebas && npm run test:todos; npm run portal     # deja el portal listo con la corrida en rojo
```

Ten abiertas 4 terminales: `pruebas/` (con BASE_URL), `monitoreo/`, `app/` (solo si se cae internet) y una libre.

## Guion por bloque

### 9:00 · QA con IA y POM (45 min)
1. Muestra la app en la nube (<https://jmd-learn.online/tienda-sol/> → tu código): login, catálogo, venta, reporte, `/salud`. Luego `npm run escanear` y abre `docs/mapa-tienda.md`: «así sabe la prueba cómo se llama cada botón».
2. `docs/casos-de-uso.md` → `docs/matriz.csv`: de un flujo alterno sale un caso de prueba.
3. POM: abre `pages/VentaPage.ts` junto a `specs/venta.spec.ts`. Que el spec «se lea como el caso de uso».
4. IA: con `ia/prompts.md` prompt 1, pega `app/publico/reporte.html` en un asistente y compara su Page
   Object con `pages/ReportePage.ts`. Discute: ¿usó getByRole? ¿metió waitForTimeout?
5. `pruebas/AGENTS.md`: las reglas que le damos a la IA.

### 9:45 · Primeras pruebas E2E (45 min)
1. `npx playwright test specs/login.spec.ts --project=chromium` → verde. `npx playwright show-report`.
2. `npm test` → **3 rojos**. No digas cuál es el defecto: lee con ellos el mensaje en español
   (`Received: "Venta N° 1 registrada. Total S/ 17.01 · Vuelto S/ 0.00"`).
3. Pregunta: «¿el defecto está en el servidor o en la pantalla?» → `npm run test:api` sale verde.
   API-VEN-001 dice que el servidor rechaza bien. Entonces está en la pantalla.
4. `npx playwright test -g VEN-003 --headed --project=chromium` para que vean el total cambiar a 30.62.
5. Semillas: `cd app && node semilla.mjs --aleatoria` dos veces (semillas distintas) y luego con
   `--semilla=` (iguales). Explica por qué `workers: 1`.
6. Ejercicio (15 min): escribir E2E-VEN-005 (quitar producto) con la IA (prompt 2).
7. Cierra mostrando verde: `npm run test:corregido` (o `BUGS=0 npm test`).

### 10:30 · Navegadores sin interfaz (45 min)
1. `fixtures.ts`: el `browser` se lanza o se conecta por CDP según el proyecto (`motor`).
2. `npm run test:lightpanda` → mismos 3 rojos, ~2 s la suite en verde, ~20 MiB.
   En otra terminal durante la corrida: `docker stats --no-stream taller-lightpanda taller-obscura`.
3. `npm run test:obscura` → mismos 3 rojos… y luego `BUGS=0 npm run test:obscura` → **VEN-003 sigue
   rojo**. Lee el `Received: "S/ 17.01"`: Obscura no dispara `change` al perder el foco. Lección:
   **un rojo no siempre es un defecto de la app; puede ser el motor.** Compara con Chromium
   (`Received: "S/ 30.62"`).
4. Cuenta las otras dos diferencias que ya se arreglaron en la app (ver `docs/motores-resultados.md`):
   `form.usuario` no existe en Obscura y los `<a>` en línea miden 0×0.
5. Tabla de `docs/motores-resultados.md` y `docs/herramientas.md`.

### 11:15 · Portal y reproducción paso a paso (45 min)
1. `npm run test:todos && npm run portal` → abre `portal/index.html`.
2. Clic en una celda roja → error → «Abrir en el reporte HTML» → «View Trace».
3. `npx playwright show-trace test-results/…/trace.zip`: acciones, DOM antes/después, red (el POST
   a `/api/ventas` con `efectivo: 17.01` aunque se escribió 5 → evidencia del defecto A).
4. `npm run test:traza` (traza siempre) vs `retain-on-failure` (por defecto): costo vs beneficio.
5. El JSON del reporte (`pruebas/resultados/resultados.json`) → cómo lo lee `portal/generar.mjs`.

### 12:00 · Monitoreo, disponibilidad y alertas (45 min)
1. Terminal app: `npm start`. Terminal monitoreo: `node receptor.mjs`, luego `docker compose up -d`.
2. Grafana <http://localhost:3001> (abre el tablero solo). Prometheus <http://localhost:9090>, consulta `probe_success`.
3. **Romper en vivo**:
   ```bash
   curl -X POST http://localhost:3000/api/caos -H "content-type: application/json" -d '{"caida":true}'
   ```
   El tablero pasa a **CAÍDA** en ≤ 15 s; la alerta llega al receptor en ~90 s (medido: 93 s).
   Mientras esperas, explica `for: 1m` (evitar falsas alarmas) y disponibilidad (99,9 % = 43 min/mes).
4. Lentitud: `-d '{"latenciaMs":2000}'` → sube la latencia; con `{"latenciaMs":6000}` el sondeo
   (timeout 5 s) cuenta como caída.
5. Volver: `-d '{"caida":false,"latenciaMs":0}'` → llega «RESUELTA».
6. Sin Docker: `node vigia.mjs --cada=2 --webhook=http://127.0.0.1:9099/alerta`.
7. Cómo conectar Telegram / correo / WhatsApp: `monitoreo/README.md` (no envíes mensajes reales en clase).

### 12:30 · Informe de pruebas en Word (antes del cierre, 6 min)

- Escena LIVE 19. Mensaje: «QA entrega un documento, no un verde en la terminal».
- En vivo: `npm run informe` con la tienda con defectos → abre el .docx → portada con **NO APTO**,
  sección 5 con los 3 defectos y su traza, sección 9 con la regla. Luego `npm run test:corregido` y
  otra vez `npm run informe` → **APTO CON RIESGO** (los 2 pendientes de la matriz).
- Pide que llenen `informe/datos.json` con su nombre antes de entregar: el .docx va en la entrega.
- Si alguien pregunta por la plantilla: es el Test Summary Report de IEEE 829 / ISTQB, reducido.

### 12:45 · Cierre (15 min)
Matriz → pruebas → portal → monitoreo: el ciclo completo. Tarea: los 2 casos pendientes de la matriz.

## Si algo falla en vivo

| Problema | Qué decir / hacer |
|---|---|
| **Lightpanda no conecta** (`No pude conectarme a lightpanda`) | `docker compose -f motores/docker-compose.yml up -d lightpanda`; `curl http://127.0.0.1:9222/json/version` debe responder. Si Docker no está: «Lightpanda es joven (1.0 en 2026); justamente por eso medimos antes de adoptarlo». Muestra los números de `docs/motores-resultados.md`. |
| Lightpanda conecta pero una prueba se cuelga | `docker restart taller-lightpanda`. Prueba `lightpanda/browser:nightly` en el compose. Mensaje: una conexión y un contexto a la vez; `workers: 1`. |
| Alumno en Windows sin Docker | Lightpanda no tiene binario Windows: que siga con Chromium; Obscura sí tiene `.zip` para Windows (`obscura serve --port 9223 --allow-private-network`, y correr con `URL_MOTOR=http://127.0.0.1:3100`). No verificado en Windows. |
| Linux: el motor no ve la app | `HOST=0.0.0.0 npm run test:lightpanda`. |
| Puerto 3100 ocupado | Quedó una corrida colgada: cerrar, o `PUERTO=3200 npm test`. |
| Docker: «all predefined address pools have been fully subnetted» | Por eso los compose usan la red `bridge` por defecto y no crean redes nuevas. Si igual aparece: `docker network prune` (solo si sabes qué borras). |
| Grafana no muestra datos | ¿La app corre en 3000? `curl http://localhost:9115/probe?target=http://host.docker.internal:3000/salud&module=http_2xx` muestra el sondeo crudo. |
| La alerta no llega | ¿`receptor.mjs` corriendo? Mira Grafana → Alerting → Alert rules (estado Pending → Firing tarda 1 min). |

## Comandos para romper cosas en vivo

```bash
node app/servidor.mjs --caida=1                 # arranca ya caída
node app/servidor.mjs --latencia_ms=800         # todo responde lento
curl -X POST localhost:3000/api/caos -d '{"caida":true}'          # caer
curl -X POST localhost:3000/api/caos -d '{"latenciaMs":3000}'     # lentitud
curl -X POST localhost:3000/api/caos -d '{"caida":false,"latenciaMs":0}'   # sanar
BUGS=0 npm test        # (en pruebas/) versión corregida, todo verde
```

`/api/semilla` solo existe con `--modo=prueba`. `/api/caos` existe salvo con `--modo=produccion`.

## Robot 24/7 y reproducción del error del usuario (escenas 21 y 22, bloque 5 y 4)

- **Robot:** antes de clase, `cd robot && BASE_URL=https://jmd-learn.online/tienda-sol/ docker compose up -d --build`
  (o `node robot/robot.mjs` en tu laptop). Muestra http://localhost:3200: KPIs, tira de corridas, «Correr ahora».
  Medido el 01-11 en el Mac: Lightpanda + runner contra la tienda web = 19 pasan / 3 fallan en 58 s, 201 MiB el runner
  y 16 MiB Lightpanda. En la escena 21 avanza el reloj, activa «Desplegaron un bug a las 15:00» y muestra que el robot
  lo ve a las 15:10. Pregunta: ¿quién se enteró primero, el robot o el cliente?
- **Semilla frontend:** abre la tienda en una ventana nueva (o modo incógnito, para que vuelva a preguntar), acepta
  grabar, cobra S/ 5 por el café, abre `/reproducir.html`, reproduce paso a paso (muestra «Enviado: efectivo 17.01»),
  pulsa «Generar prueba Playwright», copia el spec a `pruebas/specs/` y córrelo: rojo; `BUGS=0`: verde. Remata con
  la Ley 29733: qué se graba, para qué, cuánto tiempo, cómo revocar; nunca clave, tarjeta ni DNI.
- A Playwright/codegen no se le pregunta consentimiento (`navigator.webdriver`): la suite no ve el aviso.
