# Kit de práctica · Automatización de pruebas y QA con IA

Taller en vivo · domingo 1 de noviembre de 2026 · 9:00 a. m. (hora de Lima)

En este kit tienes:

| Carpeta | Qué hay |
|---|---|
| `app/` | **Tienda Sol**, la app que vamos a probar: login, catálogo, venta, reporte. Node puro, sin instalar nada. |
| `pruebas/` | Pruebas con **Playwright** y **Page Object Model**: E2E, API y visual; tres motores. |
| `docs/` | Casos de uso, matriz de casos de prueba, mapa de herramientas, resultados por motor. |
| `portal/` | Genera una página con la matriz en verde/rojo y enlaces para reproducir cada falla. |
| `monitoreo/` | Prometheus + Grafana con alertas, o `vigia.mjs` si no tienes Docker. |
| `motores/` | Lightpanda y Obscura (navegadores sin interfaz) con Docker. |
| `ia/` | Prompts listos para que la IA escriba y repare pruebas; Playwright MCP y agentes. |

---

## 0. Antes del taller (10 minutos, con buen internet)

Necesitas:

- **Node.js 20 o más nuevo** → `node -v` debe decir `v20…`, `v22…` o `v24…`. Si no: <https://nodejs.org> (versión LTS).
- **Chrome** o cualquier navegador.
- Opcional: **Docker Desktop** (para Lightpanda, Obscura y Grafana). Si no lo tienes, igual haces casi todo.

Descomprime `qa-taller-kit.zip` donde quieras (por ejemplo en Documentos) y abre una terminal ahí:

- **Windows**: en la carpeta, clic derecho → «Abrir en Terminal» (PowerShell).
- **Mac**: Terminal → `cd ~/Documents/qa-taller-kit`
- **Linux**: tu terminal de siempre.

Instala Playwright y su Chromium (≈ 150 MB, hazlo antes de la clase):

```bash
cd pruebas
npm install
npx playwright install chromium
```

En **Linux** usa `npx playwright install --with-deps chromium` (instala librerías del sistema).

---

## 1. Levanta la app (2 minutos)

```bash
cd app
npm start
```

Abre <http://localhost:3000> e ingresa con **cajero / cajero123**. Vende algo. Mira el reporte.
Prueba también <http://localhost:3000/salud>: es lo que mira el monitoreo.

Deja esa terminal abierta y abre **otra** para lo que sigue. (Para parar la app: `Ctrl + C`.)

> No necesitas tener la app abierta para correr las pruebas: Playwright la levanta sola en el
> puerto **3100**, en modo prueba. La del puerto 3000 es para que tú la uses y para el monitoreo.

---

## 2. Tu primera prueba en verde (3 minutos)

```bash
cd pruebas
npx playwright test specs/login.spec.ts --project=chromium
```

Debes ver `3 passed`. Ahora mira el reporte:

```bash
npx playwright show-report
```

---

## 3. Toda la suite

```bash
npm test                 # pruebas de API + E2E en Chromium
```

**Algunas pruebas salen en rojo. Es a propósito.** La app tiene defectos y tu trabajo en el taller es
encontrarlos, entender qué regla de negocio rompen y demostrarlo con una prueba. Lee el mensaje
de cada falla: está escrito en español y dice qué se esperaba.

Otros comandos útiles:

| Comando | Para qué |
|---|---|
| `npx playwright test --project=chromium --headed` | Ver el navegador mientras corre |
| `npx playwright test --ui` | Modo interactivo: elige pruebas, mira cada paso |
| `npx playwright test -g "VEN-003"` | Correr una sola prueba por su ID |
| `npm run test:traza` | Igual que chromium pero graba la traza de TODAS las pruebas |
| `npx playwright show-trace test-results/<carpeta>/trace.zip` | Reproducir una prueba paso a paso |
| `npm run codegen` | Grabar clics y obtener código (con la app corriendo en 3000: `npm start` en `app/`) |
| `npm run test:visual:base` | Crear la «foto base» de la prueba visual en TU máquina |

### La traza: reproducir paso a paso

Cuando una prueba falla, Playwright guarda `trace.zip` en `test-results/`. Ábrela con
`npx playwright show-trace <ruta>` (o arrastra el archivo a <https://trace.playwright.dev>):
verás cada acción, el DOM antes y después, la red y la consola. Es la mejor forma de explicarle
a un desarrollador **cómo reproducir** un defecto.

---

## 4. Cómo están organizadas las pruebas

```
pruebas/
├── playwright.config.ts   ← proyectos (api, chromium, lightpanda, obscura), webServer, reporteros
├── fixtures.ts            ← navegador por motor, semilla antes de cada prueba, Page Objects listos
├── pages/                 ← Page Objects: LoginPage, CatalogoPage, VentaPage, ReportePage
├── specs/                 ← las pruebas: login, catalogo, venta, reporte, api, visual
├── AGENTS.md / CLAUDE.md  ← reglas del proyecto para personas y asistentes de IA
└── resultados/resultados.json   ← lo lee el portal
```

**Page Object Model (POM)**: cada pantalla es una clase con sus localizadores y acciones con nombre
de negocio. La prueba dice *qué* hace el usuario (`ventaPage.cobrar(50)`); el Page Object sabe
*cómo* (`getByLabel('Efectivo recibido (S/)')`). Si cambia la pantalla, arreglas un solo archivo.

**Localizadores accesibles**: usamos `getByRole('button', { name: 'Confirmar venta' })` y
`getByLabel('Usuario')`. Así la prueba busca lo que **ve una persona** (y lo que lee un lector de
pantalla), no clases CSS que cambian cada semana.

---

## 5. Semillas: por qué las pruebas no fallan «porque sí»

Antes de **cada** prueba, el fixture `semilla` llama a `POST /api/semilla` y la app vuelve a los
mismos datos: los mismos 2 usuarios, los mismos 20 productos, el mismo stock y ninguna venta
(ver `app/datos/semilla.json`).

Si los datos cambiaran entre corridas (otro stock, ventas que dejó la prueba anterior), una prueba
podría pasar hoy y fallar mañana **sin que nadie toque el código**: eso es una prueba *inestable*
(flaky), y una suite con pruebas inestables deja de ser creíble.

Por eso además corremos con `workers: 1`: la app guarda todo en memoria y dos pruebas en paralelo
se reiniciarían los datos una a la otra.

¿Y si quiero datos variados? Usa una semilla **aleatoria pero reproducible**:

```bash
cd app
node semilla.mjs --aleatoria                  # imprime la semilla usada, ej. 48213907
node semilla.mjs --aleatoria --semilla=48213907   # exactamente los mismos datos otra vez
```

En las pruebas: `POST /api/semilla` con `{"semilla": 2026}` (mira `API-SEM-001`). Si una prueba falla
con datos aleatorios, anotas la semilla y la reproduces cuando quieras.

---

## 6. Tres motores de navegador

| Motor | Qué es | Comando |
|---|---|---|
| **Chromium** | El de Chrome, lo lanza Playwright | `npm run test:chromium` |
| **Lightpanda** | Navegador sin interfaz y sin motor gráfico (Zig), muy liviano | `npm run test:lightpanda` |
| **Obscura** | Navegador sin interfaz en Rust con V8 | `npm run test:obscura` |

Lightpanda y Obscura se levantan con Docker y Playwright se conecta a ellos por **CDP**
(`chromium.connectOverCDP`), dentro de `fixtures.ts`:

```bash
cd motores
docker compose up -d          # Lightpanda en 127.0.0.1:9222, Obscura en 127.0.0.1:9223
cd ../pruebas
npm run test:lightpanda
npm run test:obscura
docker compose -f ../motores/docker-compose.yml down     # al terminar
```

Límites que debes conocer:

- **Lightpanda no dibuja** la página: no hay capturas ni pruebas visuales. Las pruebas con la
  etiqueta `@visual` se excluyen (`grepInvert`) en los proyectos lightpanda y obscura.
- Una conexión CDP por motor y `workers: 1`.
- Lightpanda **no tiene versión nativa para Windows**: usa Docker Desktop (o WSL2).
- Sin Docker: binarios en <https://github.com/lightpanda-io/browser/releases> y
  <https://github.com/h4ckf0r0day/obscura/releases> (`lightpanda serve --host 127.0.0.1 --port 9222`,
  `obscura serve --port 9223 --allow-private-network`). En ese caso corre con
  `URL_MOTOR=http://127.0.0.1:3100` para que el navegador entre a la app por localhost.
- Mira `docs/motores-resultados.md`: tiempos, RAM y las diferencias reales que encontramos.

---

## 7. Portal de resultados

```bash
cd pruebas
npm run test:todos      # api + chromium + lightpanda + obscura (necesita Docker con los motores)
# o solo:  npm test
npm run portal
```

Abre `portal/index.html` con doble clic. Verás la matriz **caso de uso × motor** en verde/rojo,
cuánto tardó cada prueba y, al hacer clic en una celda, el error, el enlace al reporte HTML y el
comando para abrir la traza.

---

## 8. Monitoreo y alertas

Instrucciones completas en [`monitoreo/README.md`](monitoreo/README.md). Lo corto:

```bash
cd app && npm start                         # terminal 1
cd monitoreo && node receptor.mjs           # terminal 2 (recibe las alertas)
cd monitoreo && docker compose up -d        # terminal 3 → http://localhost:3001
# Sin Docker:
cd monitoreo && node vigia.mjs --cada=5 --webhook=http://127.0.0.1:9099/alerta
```

---

## 9. IA para escribir pruebas

[`ia/prompts.md`](ia/prompts.md): prompts listos (Page Object desde HTML, caso de uso → spec,
arreglar una prueba inestable, generar semillas), Playwright MCP, `codegen` y los agentes de
Playwright (`npx playwright init-agents`).

Ejercicio sugerido: en `docs/matriz.csv` hay dos casos **pendientes** (`E2E-LOG-004`,
`E2E-VEN-005`). Escríbelos con ayuda de la IA, córrelos y regenera el portal.

---

## Problemas frecuentes

| Síntoma | Solución |
|---|---|
| `http://127.0.0.1:3100/salud is already used` | Ya hay algo en el puerto 3100 (¿otra corrida?). Ciérralo, o usa `PUERTO=3200`. |
| `Executable doesn't exist … chromium` | Falta `npx playwright install chromium`. |
| `No pude conectarme a lightpanda en ws://127.0.0.1:9222` | `cd motores && docker compose up -d lightpanda` |
| La prueba visual sale «skipped» | Normal: primero crea la foto base con `npm run test:visual:base`. |
| En Linux, Lightpanda/Obscura no ven la app | Corre las pruebas con `HOST=0.0.0.0` (ver `monitoreo/README.md`). |
| `npm start` dice `EADDRINUSE` | Otro programa usa el 3000: `node servidor.mjs --port=3005`. |
| Windows: `curl` raro en PowerShell | Usa `curl.exe` o `Invoke-RestMethod` (ver `monitoreo/README.md`). |

Variables de entorno: en Mac/Linux `PUERTO=3200 npm test`; en PowerShell `$env:PUERTO="3200"; npm test`.


## Tienda web por alumno · versión del taller

Abre https://jmd-learn.online/tienda-sol/ y copia tu URL privada con código.
Cada visitante tiene datos, sesión, caos y modo con bugs propios. El código permite acceder a tu tienda: no lo compartas. Se borra tras 30 minutos sin actividad.

Desde `pruebas/`, usa `BASE_URL` para probar tu tienda. No se levanta un servidor local cuando existe esta variable. La semilla automática selecciona `BUGS=1` o `BUGS=0` solo en tu espacio.

```bash
# Mac / Linux
BASE_URL=https://jmd-learn.online/tienda-sol/TU_CODIGO npm test
BASE_URL=https://jmd-learn.online/tienda-sol/TU_CODIGO BUGS=0 npm test
```

```powershell
# Windows PowerShell
$env:BASE_URL="https://jmd-learn.online/tienda-sol/TU_CODIGO"
npm test
$env:BUGS="0"
npm test
```

La visual requiere una referencia propia: `npm run test:visual:base`. Local y web usan archivos de referencia distintos; se enmascaran el nombre del usuario y los controles de la tienda. Para capturar con Chrome instalado, configura `CANAL=chrome` (PowerShell: `$env:CANAL="chrome"`).
Si recibes 410, vuelve a abrir `/tienda-sol/` y actualiza `BASE_URL`. Detalles y resultados reales: `docs/verificacion-v2.md`.
