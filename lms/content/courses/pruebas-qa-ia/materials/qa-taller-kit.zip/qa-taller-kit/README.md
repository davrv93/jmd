# Kit de práctica · Automatización de pruebas y QA con IA

Taller en vivo · domingo 1 de noviembre de 2026 · 9:00 a. m. (hora de Lima)

En este kit tienes:

| Carpeta | Qué hay |
|---|---|
| `app/` | **Tienda Sol**, la app que vamos a probar: login, catálogo, venta, reporte. Node puro, sin instalar nada. |
| `pruebas/` | Pruebas con **Playwright** y **Page Object Model**: E2E, API y visual; tres motores. |
| `docs/` | Casos de uso, matriz de casos de prueba, mapa de herramientas, resultados por motor. |
| `portal/` | Genera una página con la matriz en verde/rojo y enlaces para reproducir cada falla. |
| `monitoreo/` | Prometheus + Grafana con alertas, o `vigia.mjs` si no tienes Docker. |
| `motores/` | Lightpanda y Obscura (navegadores sin interfaz) con Docker. |
| `ia/` | Prompts listos para que la IA escriba y repare pruebas; Playwright MCP y agentes. |

---

## 0. Abre tu Tienda Sol en la nube (1 minuto)

No necesitas instalar la app: cada alumno tiene **su propia Tienda Sol** en la nube, aislada de las demás.

1. Abre <https://jmd-learn.online/tienda-sol/>. Te redirige a tu tienda: `https://jmd-learn.online/tienda-sol/TU_CODIGO/`.
2. Copia esa URL (con tu código). Es privada: no la compartas. La tienda se borra tras 30 minutos sin actividad; si recibes **410**, vuelve a abrir `/tienda-sol/` y copia el código nuevo.
3. Entra con **cajero / cajero123**. Vende algo. Mira el reporte. Prueba también `TU_URL/salud`.

Tu tienda viene **con bugs** a propósito (interruptor «Con bugs» en el login); «Reiniciar mi tienda» no toca la de nadie más. Nadie puede tumbar tu tienda ni tú la de otro.

Guarda la URL en una variable para todo lo que sigue (desde `pruebas/`):

```bash
# Mac / Linux
export BASE_URL=https://jmd-learn.online/tienda-sol/TU_CODIGO
```
```powershell
# Windows PowerShell
$env:BASE_URL="https://jmd-learn.online/tienda-sol/TU_CODIGO"
```

---

## 1. Instala las pruebas (5 minutos, con buen internet)

Necesitas **Node.js 20 o más nuevo** (`node -v` → `v20…`, `v22…` o `v24…`; si no: <https://nodejs.org>, versión LTS) y Chrome.
Opcional: Docker Desktop (para Lightpanda, Obscura y Grafana).

Descomprime `qa-taller-kit.zip` (por ejemplo en Documentos) y abre una terminal ahí
(Windows: clic derecho → «Abrir en Terminal»; Mac: `cd ~/Documents/qa-taller-kit`).

```bash
cd pruebas
npm install
npx playwright install chromium     # Linux: npx playwright install --with-deps chromium
```

Solo se instala la carpeta `pruebas/`: la app corre en la nube.

---

## 2. Escanea tu tienda (2 minutos)

Antes de escribir una prueba hay que saber qué hay en cada pantalla y cómo se llama cada botón.
El escáner entra como cajero, recorre login, catálogo, venta y reporte y escribe el mapa:

```bash
npm run escanear        # usa BASE_URL; sin ella, http://localhost:3000
```

Salida:

- `docs/mapa-tienda.md`: por pantalla, cada elemento con su **localizador recomendado** (`getByRole`, `getByLabel`…), los formularios y las llamadas a la API observadas, más el árbol de accesibilidad.
- `pages/generado/*.ts`: esqueletos de Page Object (solo localizadores y métodos `TODO`). Compáralos con `pages/*.ts`, que son los «buenos».

Con IA: en `ia/prompts.md`, sección «Escanea mi tienda», tienes el prompt para que Claude Code (con Playwright MCP) recorra tu tienda y escriba el mapa y los page objects él mismo.

---

## 2 bis. Tu primera prueba en verde (3 minutos)

```bash
npx playwright test specs/login.spec.ts --project=chromium
```

Debes ver `3 passed`. Ahora mira el reporte:

```bash
npx playwright show-report
```

---

## 3. Toda la suite

```bash
npm test                 # pruebas de API + E2E en Chromium
```

**Algunas pruebas salen en rojo. Es a propósito.** La app tiene defectos y tu trabajo en el taller es
encontrarlos, entender qué regla de negocio rompen y demostrarlo con una prueba. Lee el mensaje
de cada falla: está escrito en español y dice qué se esperaba.

Otros comandos útiles:

| Comando | Para qué |
|---|---|
| `npx playwright test --project=chromium --headed` | Ver el navegador mientras corre |
| `npx playwright test --ui` | Modo interactivo: elige pruebas, mira cada paso |
| `npx playwright test -g "VEN-003"` | Correr una sola prueba por su ID |
| `npm run test:traza` | Igual que chromium pero graba la traza de TODAS las pruebas |
| `npx playwright show-trace test-results/<carpeta>/trace.zip` | Reproducir una prueba paso a paso |
| `npm run codegen` | Grabar clics y obtener código (con la app corriendo en 3000: `npm start` en `app/`) |
| `npm run test:visual:base` | Crear la «foto base» de la prueba visual en TU máquina |

### La traza: reproducir paso a paso

Cuando una prueba falla, Playwright guarda `trace.zip` en `test-results/`. Ábrela con
`npx playwright show-trace <ruta>` (o arrastra el archivo a <https://trace.playwright.dev>):
verás cada acción, el DOM antes y después, la red y la consola. Es la mejor forma de explicarle
a un desarrollador **cómo reproducir** un defecto.

---

## 4. Cómo están organizadas las pruebas

```
pruebas/
├── playwright.config.ts   ← proyectos (api, chromium, lightpanda, obscura), webServer, reporteros
├── fixtures.ts            ← navegador por motor, semilla antes de cada prueba, Page Objects listos
├── pages/                 ← Page Objects: LoginPage, CatalogoPage, VentaPage, ReportePage
├── specs/                 ← las pruebas: login, catalogo, venta, reporte, api, visual
├── AGENTS.md / CLAUDE.md  ← reglas del proyecto para personas y asistentes de IA
└── resultados/resultados.json   ← lo lee el portal
```

**Page Object Model (POM)**: cada pantalla es una clase con sus localizadores y acciones con nombre
de negocio. La prueba dice *qué* hace el usuario (`ventaPage.cobrar(50)`); el Page Object sabe
*cómo* (`getByLabel('Efectivo recibido (S/)')`). Si cambia la pantalla, arreglas un solo archivo.

**Localizadores accesibles**: usamos `getByRole('button', { name: 'Confirmar venta' })` y
`getByLabel('Usuario')`. Así la prueba busca lo que **ve una persona** (y lo que lee un lector de
pantalla), no clases CSS que cambian cada semana.

---

## 5. Semillas: por qué las pruebas no fallan «porque sí»

Antes de **cada** prueba, el fixture `semilla` llama a `POST /api/semilla` y la app vuelve a los
mismos datos: los mismos 2 usuarios, los mismos 20 productos, el mismo stock y ninguna venta
(ver `app/datos/semilla.json`).

Si los datos cambiaran entre corridas (otro stock, ventas que dejó la prueba anterior), una prueba
podría pasar hoy y fallar mañana **sin que nadie toque el código**: eso es una prueba *inestable*
(flaky), y una suite con pruebas inestables deja de ser creíble.

Por eso además corremos con `workers: 1`: la app guarda todo en memoria y dos pruebas en paralelo
se reiniciarían los datos una a la otra.

¿Y si quiero datos variados? Usa una semilla **aleatoria pero reproducible**:

```bash
cd app
node semilla.mjs --aleatoria                  # imprime la semilla usada, ej. 48213907
node semilla.mjs --aleatoria --semilla=48213907   # exactamente los mismos datos otra vez
```

En las pruebas: `POST /api/semilla` con `{"semilla": 2026}` (mira `API-SEM-001`). Si una prueba falla
con datos aleatorios, anotas la semilla y la reproduces cuando quieras.

---

## 6. Tres motores de navegador

| Motor | Qué es | Comando |
|---|---|---|
| **Chromium** | El de Chrome, lo lanza Playwright | `npm run test:chromium` |
| **Lightpanda** | Navegador sin interfaz y sin motor gráfico (Zig), muy liviano | `npm run test:lightpanda` |
| **Obscura** | Navegador sin interfaz en Rust con V8 | `npm run test:obscura` |

Lightpanda y Obscura se levantan con Docker y Playwright se conecta a ellos por **CDP**
(`chromium.connectOverCDP`), dentro de `fixtures.ts`:

```bash
cd motores
docker compose up -d          # Lightpanda en 127.0.0.1:9222, Obscura en 127.0.0.1:9223
cd ../pruebas
npm run test:lightpanda
npm run test:obscura
docker compose -f ../motores/docker-compose.yml down     # al terminar
```

Límites que debes conocer:

- **Lightpanda no dibuja** la página: no hay capturas ni pruebas visuales. Las pruebas con la
  etiqueta `@visual` se excluyen (`grepInvert`) en los proyectos lightpanda y obscura.
- Una conexión CDP por motor y `workers: 1`.
- Lightpanda **no tiene versión nativa para Windows**: usa Docker Desktop (o WSL2).
- Sin Docker: binarios en <https://github.com/lightpanda-io/browser/releases> y
  <https://github.com/h4ckf0r0day/obscura/releases> (`lightpanda serve --host 127.0.0.1 --port 9222`,
  `obscura serve --port 9223 --allow-private-network`). En ese caso corre con
  `URL_MOTOR=http://127.0.0.1:3100` para que el navegador entre a la app por localhost.
- Mira `docs/motores-resultados.md`: tiempos, RAM y las diferencias reales que encontramos.

---

## 7. Portal de resultados

```bash
cd pruebas
npm run test:todos      # api + chromium + lightpanda + obscura (necesita Docker con los motores)
# o solo:  npm test
npm run portal
```

Abre `portal/index.html` con doble clic. Verás la matriz **caso de uso × motor** en verde/rojo,
cuánto tardó cada prueba y, al hacer clic en una celda, el error, el enlace al reporte HTML y el
comando para abrir la traza.

---

## 8. Monitoreo y alertas

Instrucciones completas en [`monitoreo/README.md`](monitoreo/README.md). Lo corto:

```bash
cd app && npm start                         # terminal 1
cd monitoreo && node receptor.mjs           # terminal 2 (recibe las alertas)
cd monitoreo && docker compose up -d        # terminal 3 → http://localhost:3001
# Sin Docker:
cd monitoreo && node vigia.mjs --cada=5 --webhook=http://127.0.0.1:9099/alerta
```

---

## 9. IA para escribir pruebas

[`ia/prompts.md`](ia/prompts.md): prompts listos (Page Object desde HTML, caso de uso → spec,
arreglar una prueba inestable, generar semillas), Playwright MCP, `codegen` y los agentes de
Playwright (`npx playwright init-agents`).

Ejercicio sugerido: en `docs/matriz.csv` hay dos casos **pendientes** (`E2E-LOG-004`,
`E2E-VEN-005`). Escríbelos con ayuda de la IA, córrelos y regenera el portal.

---

## 10. Informe de pruebas (Word): tú lo escribes

Un proceso de QA termina con un documento que alguien lee, firma y guarda, no con una terminal en verde.
El kit arma el **informe de pruebas** (estilo ISTQB / IEEE 829, «Test Summary Report») en Word, pero
**las tablas las pone la herramienta y el juicio lo pones tú**:

1. Corre la suite: `npm test` (deja `resultados/resultados.json`).
2. Abre `informe/datos.json`: es tu hoja de trabajo. Cada campo vacío tiene un `_guia` que dice qué va
   ahí y un ejemplo. Redacta: objetivo, alcance, fuera de alcance, criterio de salida, riesgos,
   conclusión, recomendación y firma. Cita **IDs** (`E2E-VEN-002`, `DEF-01`) y **cifras** (23 ejecutados, 3 fallan).
3. Genera: `npm run informe` → `informe/informe-de-pruebas.docx`. Lo que no escribiste sale en
   **amarillo** como `[Completa: …]`.
4. Revísalo como lo haría el jefe de QA: `npm run informe:revisar`. Falla si quedan marcadores, si la
   conclusión no dice APTO / NO APTO, si no cita cifras o si un defecto **Alta** no aparece ni en la
   conclusión ni en la recomendación.
5. Ábrelo (`open informe/informe-de-pruebas.docx`; Windows: `start …`) y entrégalo con tu carpeta de pruebas.

Un ejemplo completo: `informe/ejemplo-datos.json` → `informe/ejemplo-informe-de-pruebas.docx`
(`DATOS=../informe/ejemplo-datos.json npm run informe` lo regenera). Léelo, no lo copies: tus cifras salen de tu corrida.

| Sección | Qué dice | Quién la pone |
|---|---|---|
| Portada | Proyecto, versión, tester, fechas y veredicto calculado | tú + resultados |
| 1 · Objetivo, alcance, fuera de alcance, criterio de salida | Qué se prometió probar y con qué regla se decide | **tú** |
| 2 · Entorno | SO, Node, Playwright, motores, URL, semilla | detectado + tú |
| 3 · Casos planificados vs ejecutados | Toda la matriz con su resultado | `docs/matriz.csv` + JSON |
| 4 · Resultados | Totales, % por módulo, duración | JSON de Playwright |
| 5 · Defectos | Un cuadro por caso rojo: esperado, recibido, severidad, evidencia | JSON de Playwright |
| 6 · Cobertura | Caso de uso ↔ pruebas | matriz + JSON |
| 7 · Motores | Lo medido ahora y la referencia del kit | JSON + `docs/motores-resultados.md` |
| 8 · Riesgos y pendientes | Casos sin automatizar + tus riesgos | matriz + **tú** |
| 9 · Conclusión y recomendación | Veredicto calculado como pista; **tu** conclusión argumentada; firma | **tú** |
| Anexo | Comandos para repetir la corrida | fijo |

**Criterio de salida** de referencia: cualquier caso de prioridad **Alta** en rojo → **NO APTO**; solo
Media o Baja → APTO con observaciones; todo verde con pendientes → APTO con riesgo; todo verde y nada
pendiente → APTO. Acuérdalo con tu equipo **antes** de correr, y escríbelo en `criterio_de_salida`.

Con la tienda con defectos el veredicto calculado es NO APTO (3 defectos Alta: VEN-001, 002 y 003).
Con `npm run test:corregido`, APTO CON RIESGO (quedan 2 casos pendientes en la matriz).

## Problemas frecuentes

| Síntoma | Solución |
|---|---|
| `http://127.0.0.1:3100/salud is already used` | Ya hay algo en el puerto 3100 (¿otra corrida?). Ciérralo, o usa `PUERTO=3200`. |
| `Executable doesn't exist … chromium` | Falta `npx playwright install chromium`. |
| `No pude conectarme a lightpanda en ws://127.0.0.1:9222` | `cd motores && docker compose up -d lightpanda` |
| La prueba visual sale «skipped» | Normal: primero crea la foto base con `npm run test:visual:base`. |
| En Linux, Lightpanda/Obscura no ven la app | Corre las pruebas con `HOST=0.0.0.0` (ver `monitoreo/README.md`). |
| `npm start` dice `EADDRINUSE` | Otro programa usa el 3000: `node servidor.mjs --port=3005`. |
| Windows: `curl` raro en PowerShell | Usa `curl.exe` o `Invoke-RestMethod` (ver `monitoreo/README.md`). |

Variables de entorno: en Mac/Linux `PUERTO=3200 npm test`; en PowerShell `$env:PUERTO="3200"; npm test`.


## Opcional: sin internet (tienda local)

Si no hay internet, la misma app corre en tu laptop:

```bash
cd app
npm start           # http://localhost:3000 · cajero / cajero123 · /salud para el monitoreo
```

Sin `BASE_URL`, Playwright levanta su propia copia en el puerto **3100** (modo prueba) para cada corrida;
la del 3000 es para que tú la uses y para el monitoreo. `BUGS=0` corre la versión corregida.
Con `BASE_URL` definido no se levanta nada local: la semilla automática elige `BUGS=1` o `BUGS=0` solo en tu tienda de la nube.
Detalles y resultados reales: `docs/verificacion-v2.md`.
