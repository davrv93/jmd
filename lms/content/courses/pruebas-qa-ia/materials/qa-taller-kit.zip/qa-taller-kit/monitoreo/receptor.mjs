// Receptor de alertas para el taller (sin dependencias).
// Grafana y vigia.mjs le envían un POST cuando el servicio cae o se recupera.
//   node receptor.mjs            -> escucha en http://127.0.0.1:9099/alerta
// En la vida real este papel lo cumple Telegram, correo, Slack, PagerDuty, etc.
import { createServer } from 'node:http';

const PUERTO = Number(process.env.PUERTO ?? 9099);
const HOST = process.env.HOST ?? '0.0.0.0'; // 0.0.0.0 para que Grafana (en Docker) llegue

createServer(async (req, res) => {
  let cuerpo = '';
  for await (const t of req) cuerpo += t;
  const hora = new Date().toLocaleTimeString('es-PE', { timeZone: 'America/Lima' });
  try {
    const j = JSON.parse(cuerpo || '{}');
    if (Array.isArray(j.alerts)) {
      // Formato de Grafana
      for (const a of j.alerts) {
        const icono = a.status === 'firing' ? '[DISPARADA]' : '[RESUELTA] ';
        console.log(`[${hora}] ${icono}  ${a.labels?.alertname} · ${a.annotations?.summary ?? ''}`);
      }
    } else {
      // Formato de vigia.mjs
      console.log(`[${hora}] ${j.estado === 'caido' ? '[CAIDA]' : '[OK]   '} ${j.mensaje ?? cuerpo}`);
    }
  } catch {
    console.log(`[${hora}] (cuerpo no JSON) ${cuerpo.slice(0, 200)}`);
  }
  res.writeHead(200, { 'content-type': 'application/json' });
  res.end('{"ok":true}');
}).listen(PUERTO, HOST, () => console.log(`Receptor de alertas en http://127.0.0.1:${PUERTO}/alerta — esperando avisos…`));
