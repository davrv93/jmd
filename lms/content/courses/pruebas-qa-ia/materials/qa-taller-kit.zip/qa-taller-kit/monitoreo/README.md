# Monitoreo de Tienda Sol

Dos caminos. Elige según tu laptop:

| | Con Docker | Sin Docker |
|---|---|---|
| Qué corre | Prometheus + blackbox_exporter + Grafana | `vigia.mjs` (Node puro) |
| Qué ves | Tablero con estado, latencia y disponibilidad 1 h / 24 h; alerta a los 60 s de caída | Una línea por sondeo en la terminal y avisos al cambiar de estado |
| RAM | ~370 MiB (Grafana ~300) | ~40 MiB |

## 1. Con Docker

```bash
# Terminal 1: la app
cd app && npm start                 # http://localhost:3000

# Terminal 2: el receptor de alertas (hace de «teléfono del equipo»)
cd monitoreo && node receptor.mjs   # escucha en el puerto 9099

# Terminal 3: el monitoreo
cd monitoreo && docker compose up -d
```

- Grafana: <http://localhost:3001> → abre directo el tablero **Tienda Sol · disponibilidad**
  (entras como visor sin clave; para editar: `admin` / `taller`).
- Prometheus: <http://localhost:9090> → prueba la consulta `probe_success`.

### Romperla a propósito

```bash
# Caída: /salud responde 503
curl -X POST http://localhost:3000/api/caos -H "content-type: application/json" -d "{\"caida\":true}"
# Lentitud: cada respuesta tarda 2 s
curl -X POST http://localhost:3000/api/caos -H "content-type: application/json" -d "{\"latenciaMs\":2000}"
# Volver a la normalidad
curl -X POST http://localhost:3000/api/caos -H "content-type: application/json" -d "{\"caida\":false,\"latenciaMs\":0}"
```

En PowerShell usa `curl.exe` (no `curl`) con las mismas comillas escapadas, o:

```powershell
Invoke-RestMethod -Method Post -Uri http://localhost:3000/api/caos -ContentType 'application/json' -Body '{"caida":true}'
```

También puedes arrancar la app ya caída o lenta: `node servidor.mjs --caida=1` o `--latencia_ms=800`.

Qué pasa (medido): el tablero se pone en **CAÍDA** en el siguiente sondeo (≤ 15 s). La alerta
«Tienda Sol caída» llega al receptor ~90 s después (1 min de `for` + sondeo + evaluación + espera
de agrupación). Al volver, llega «RESUELTA».

### Apagar

```bash
docker compose down
```

## 2. Sin Docker: el vigía

```bash
cd monitoreo
node receptor.mjs                                               # terminal A (opcional)
node vigia.mjs --cada=5 --webhook=http://127.0.0.1:9099/alerta  # terminal B
```

Opciones: `--url=` (por defecto `http://127.0.0.1:3000/salud`), `--cada=` segundos,
`--webhook=` URL a la que avisa, `--tiempo-max=` ms antes de dar el sondeo por caído (3000).

## Conectar avisos reales

La alerta sale por un **punto de contacto** definido en `grafana/provisioning/alerting/alertas.yml`.
Hoy es un webhook a `ALERTA_WEBHOOK_URL` (por defecto el receptor local).

- **Otro webhook** (n8n, Make, Zapier, tu backend): `ALERTA_WEBHOOK_URL=https://… docker compose up -d`.
- **Telegram**: crea un bot con @BotFather, consigue el `chat_id` y agrega otro receptor:
  ```yaml
      - uid: telegram-equipo
        type: telegram
        settings:
          bottoken: $TELEGRAM_BOT_TOKEN
          chatid: "123456789"
  ```
  Pasa el token por variable de entorno, **nunca** escrito en el archivo.
- **Correo**: tipo `email` con `addresses: equipo@tuempresa.pe`, y configura SMTP en Grafana con
  las variables `GF_SMTP_ENABLED=true`, `GF_SMTP_HOST=…`, `GF_SMTP_USER=…`, `GF_SMTP_PASSWORD=…`.
- **WhatsApp**: Grafana no lo trae directo. Se hace con un **webhook** hacia un servicio que sí
  envía WhatsApp (WhatsApp Business Cloud API de Meta, Twilio, o una pasarela propia). El webhook
  recibe el JSON de Grafana (mira lo que imprime `receptor.mjs`) y lo reenvía como mensaje.
  Ojo: los mensajes automáticos fuera de la ventana de 24 h requieren plantillas aprobadas.

Con `vigia.mjs` es lo mismo: `--webhook=` apunta a cualquiera de esos servicios.

## Linux

En Docker Engine (Linux), `host.docker.internal` apunta a la interfaz de Docker, no a
`127.0.0.1`. Arranca la app escuchando en todas las interfaces: `HOST=0.0.0.0 npm start`.
