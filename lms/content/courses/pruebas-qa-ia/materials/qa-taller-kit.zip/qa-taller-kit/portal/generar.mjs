// Portal de resultados — sin dependencias.
// Lee el reporte JSON de Playwright + docs/matriz.csv y escribe portal/index.html.
//
// Uso (desde la carpeta pruebas/):   npm run portal
// o directamente:                   node portal/generar.mjs [ruta/resultados.json]

import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { dirname, join, relative } from 'node:path';
import { fileURLToPath } from 'node:url';

const aqui = dirname(fileURLToPath(import.meta.url));
const raiz = join(aqui, '..');
const rutaJson = process.argv[2] ?? join(raiz, 'pruebas', 'resultados', 'resultados.json');
const rutaCsv = join(raiz, 'docs', 'matriz.csv');
const salida = join(aqui, 'index.html');

// ---------- leer la matriz ----------
function leerCsv(texto) {
  const filas = [];
  for (const linea of texto.split(/\r?\n/).filter(Boolean)) {
    const celdas = [];
    let actual = '', comillas = false;
    for (const c of linea) {
      if (c === '"') comillas = !comillas;
      else if (c === ',' && !comillas) { celdas.push(actual); actual = ''; }
      else actual += c;
    }
    celdas.push(actual);
    filas.push(celdas);
  }
  const [cab, ...resto] = filas;
  return resto.map((f) => Object.fromEntries(cab.map((k, i) => [k.trim(), (f[i] ?? '').trim()])));
}
const matriz = leerCsv(readFileSync(rutaCsv, 'utf8'));

// ---------- leer resultados de Playwright ----------
const sinAnsi = (s = '') => s.replace(/\u001b\[[0-9;]*m/g, '');
const resultados = new Map(); // id -> { proyecto -> {estado, ms, error, traza, archivo} }
let reporte = null;
const proyectos = new Set();

if (existsSync(rutaJson)) {
  reporte = JSON.parse(readFileSync(rutaJson, 'utf8'));
  const recorrer = (suite) => {
    for (const spec of suite.specs ?? []) {
      const id = (/^([A-Z0-9]{2,4}-[A-Z]{3}-\d{3})/.exec(spec.title) ?? [])[1] ?? spec.title;
      for (const t of spec.tests) {
        const ultimo = t.results.at(-1);
        if (!ultimo) continue;
        proyectos.add(t.projectName);
        let estado = { passed: 'verde', failed: 'rojo', timedOut: 'rojo', interrupted: 'rojo', skipped: 'omitida' }[ultimo.status] ?? 'rojo';
        if (t.status === 'flaky') estado = 'inestable';
        const error = sinAnsi(ultimo.errors?.[0]?.message ?? ultimo.error?.message ?? '').split('\n').filter(Boolean).slice(0, 7).join('\n');
        const traza = ultimo.attachments?.find((a) => a.name === 'trace')?.path;
        const motivo = t.annotations?.find((a) => a.type === 'skip')?.description;
        if (!resultados.has(id)) resultados.set(id, { titulo: spec.title, archivo: spec.file, porProyecto: {} });
        resultados.get(id).porProyecto[t.projectName] = {
          estado, ms: ultimo.duration, error: error || motivo || '',
          traza: traza ? relative(join(raiz, 'pruebas'), traza) : null,
        };
      }
    }
    for (const s of suite.suites ?? []) recorrer(s);
  };
  for (const s of reporte.suites) recorrer(s);
}

const ORDEN = ['api', 'chromium', 'chromium-traza', 'lightpanda', 'obscura'];
const columnas = [...proyectos].sort((a, b) => (ORDEN.indexOf(a) + 99 * (ORDEN.indexOf(a) < 0)) - (ORDEN.indexOf(b) + 99 * (ORDEN.indexOf(b) < 0)));

// Casos que corrieron pero no están en la matriz (para que nadie se pierda).
const enMatriz = new Set(matriz.map((f) => f.id_prueba));
for (const [id, r] of resultados) {
  if (!enMatriz.has(id)) matriz.push({ caso_uso: 'Fuera de la matriz', modulo: '—', id_prueba: id, descripcion: r.titulo, spec: r.archivo, prioridad: '—', estado: 'sin registrar' });
}

// ---------- resumen ----------
const resumen = Object.fromEntries(columnas.map((p) => [p, { verde: 0, rojo: 0, omitida: 0, inestable: 0, ms: 0 }]));
for (const r of resultados.values()) {
  for (const [p, x] of Object.entries(r.porProyecto)) { resumen[p][x.estado]++; resumen[p].ms += x.ms; }
}

// ---------- HTML ----------
const esc = (s = '') => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const seg = (ms) => (ms >= 1000 ? (ms / 1000).toFixed(1) + ' s' : ms + ' ms');
const ICONO = { verde: '✓', rojo: '✗', omitida: '–', inestable: '!', 'sin-correr': '·' };
const TEXTO = { verde: 'Pasa', rojo: 'Falla', omitida: 'Omitida', inestable: 'Inestable', 'sin-correr': 'Sin correr' };
const enlaceReporte = (proyecto, id) => `../pruebas/playwright-report/index.html#?q=${encodeURIComponent(`p:${proyecto} ${id}`)}`;

function celda(fila, proyecto) {
  const r = resultados.get(fila.id_prueba)?.porProyecto[proyecto];
  if (!r) {
    // Corrió en otro motor pero no en este (p. ej. una prueba de API en Lightpanda): no aplica.
    if (resultados.has(fila.id_prueba)) return `<td class="celda no-aplica" title="No aplica en ${esc(proyecto)}"></td>`;
    return `<td class="celda sin-correr" title="Sin correr"><span class="pastilla">${ICONO['sin-correr']}</span></td>`;
  }
  const detalle = [
    `<strong>${esc(TEXTO[r.estado])}</strong> en <code>${esc(proyecto)}</code> · ${seg(r.ms)}`,
    r.error ? `<pre>${esc(r.error)}</pre>` : '',
    `<a href="${esc(enlaceReporte(proyecto, fila.id_prueba))}" target="_blank" rel="noopener">Abrir en el reporte HTML →</a>`,
    r.traza ? `<div class="traza"><span>Reproducir paso a paso (desde <code>pruebas/</code>):</span><code class="cmd">npx playwright show-trace "${esc(r.traza)}"</code><button type="button" class="copiar">Copiar</button></div>` : '',
  ].join('');
  return `<td class="celda ${r.estado}"><details><summary><span class="pastilla">${ICONO[r.estado]}</span><span class="ms">${seg(r.ms)}</span></summary><div class="globo">${detalle}</div></details></td>`;
}

const grupos = new Map();
for (const f of matriz) {
  if (!grupos.has(f.caso_uso)) grupos.set(f.caso_uso, []);
  grupos.get(f.caso_uso).push(f);
}

const filasHtml = [...grupos].map(([caso, filas]) => `
  <tr class="grupo"><th colspan="${4 + columnas.length}" scope="rowgroup">${esc(caso)}</th></tr>
  ${filas.map((f) => `
  <tr>
    <td><span class="modulo">${esc(f.modulo)}</span></td>
    <th scope="row"><code>${esc(f.id_prueba)}</code></th>
    <td>${esc(f.descripcion)}<div class="spec">${esc(f.spec)}${f.estado === 'pendiente' ? ' · <em>pendiente de automatizar</em>' : ''}</div></td>
    <td><span class="prio prio-${esc(f.prioridad.toLowerCase())}">${esc(f.prioridad)}</span></td>
    ${columnas.map((p) => celda(f, p)).join('')}
  </tr>`).join('')}`).join('');

const tarjetas = columnas.map((p) => {
  const r = resumen[p];
  const corridas = r.verde + r.rojo + r.inestable;
  const pct = corridas ? Math.round((r.verde / corridas) * 100) : 0;
  return `<div class="tarjeta"><div class="motor">${esc(p)}</div><div class="pct ${r.rojo ? 'mal' : 'bien'}">${pct}%</div>
    <div class="det"><span class="v">${r.verde} pasan</span> · <span class="r">${r.rojo} fallan</span>${r.omitida ? ` · ${r.omitida} omitidas` : ''}${r.inestable ? ` · ${r.inestable} inestables` : ''}</div>
    <div class="barra"><i style="width:${pct}%"></i></div><div class="det">${seg(r.ms)} sumando pruebas</div></div>`;
}).join('');

const fecha = reporte ? new Date(reporte.stats.startTime).toLocaleString('es-PE', { timeZone: 'America/Lima', dateStyle: 'long', timeStyle: 'short' }) : '—';
const pendientes = matriz.filter((f) => f.estado === 'pendiente').length;

const html = `<!doctype html>
<html lang="es-PE">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Portal de pruebas · Tienda Sol</title>
<style>
:root { --fondo:#f7f5ef; --papel:#fff; --tinta:#1c1917; --suave:#78716c; --borde:#e7e5e4; --verde:#15803d; --verde-f:#dcfce7; --rojo:#b91c1c; --rojo-f:#fee2e2; --gris-f:#f5f5f4; --ambar:#b45309; --ambar-f:#fef3c7; --acento:#f59e0b; }
@media (prefers-color-scheme: dark) { :root { --fondo:#141210; --papel:#1e1b18; --tinta:#f5f5f4; --suave:#a8a29e; --borde:#33302c; --verde:#4ade80; --verde-f:#14532d55; --rojo:#f87171; --rojo-f:#7f1d1d55; --gris-f:#292524; --ambar:#fbbf24; --ambar-f:#78350f55; } }
* { box-sizing: border-box; }
body { margin:0; background:var(--fondo); color:var(--tinta); font:15px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif; }
header { padding:28px 16px 8px; max-width:1200px; margin:0 auto; }
h1 { margin:0; font-size:1.7rem; letter-spacing:-.01em; } h1 span { color:var(--acento); }
.sub { color:var(--suave); margin:4px 0 0; }
main { max-width:1200px; margin:0 auto; padding:8px 16px 48px; }
.tarjetas { display:grid; gap:12px; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); margin:16px 0 24px; }
.tarjeta { background:var(--papel); border:1px solid var(--borde); border-radius:14px; padding:14px 16px; }
.motor { font-weight:700; text-transform:uppercase; font-size:.8rem; letter-spacing:.06em; color:var(--suave); }
.pct { font-size:2rem; font-weight:800; } .pct.bien { color:var(--verde); } .pct.mal { color:var(--rojo); }
.det { color:var(--suave); font-size:.85rem; } .det .v { color:var(--verde); } .det .r { color:var(--rojo); }
.barra { height:6px; background:var(--rojo-f); border-radius:9px; margin:8px 0 6px; overflow:hidden; } .barra i { display:block; height:100%; background:var(--verde); }
.tabla-envoltura { overflow-x:auto; background:var(--papel); border:1px solid var(--borde); border-radius:14px; }
table { border-collapse:collapse; width:100%; min-width:760px; }
th, td { padding:8px 10px; border-bottom:1px solid var(--borde); text-align:left; vertical-align:top; }
thead th { position:sticky; top:0; background:var(--papel); font-size:.8rem; text-transform:uppercase; letter-spacing:.05em; color:var(--suave); }
thead th.motor-col { text-align:center; }
tr.grupo th { background:var(--gris-f); font-size:.9rem; }
th[scope=row] { font-weight:500; white-space:nowrap; }
code { font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace; font-size:.85em; }
.spec { color:var(--suave); font-size:.8rem; }
.modulo { font-size:.8rem; padding:1px 8px; border-radius:99px; background:var(--gris-f); white-space:nowrap; }
.prio { font-size:.75rem; font-weight:700; } .prio-alta { color:var(--rojo); } .prio-media { color:var(--ambar); } .prio-baja { color:var(--suave); }
td.celda { text-align:center; min-width:96px; position:relative; }
.pastilla { display:inline-grid; place-items:center; width:26px; height:26px; border-radius:50%; font-weight:800; }
.verde .pastilla { background:var(--verde-f); color:var(--verde); }
.rojo .pastilla { background:var(--rojo-f); color:var(--rojo); }
.omitida .pastilla, .sin-correr .pastilla { background:var(--gris-f); color:var(--suave); }
.inestable .pastilla { background:var(--ambar-f); color:var(--ambar); }
.ms { display:block; font-size:.72rem; color:var(--suave); }
details summary { list-style:none; cursor:pointer; } details summary::-webkit-details-marker { display:none; }
.globo { position:absolute; z-index:5; right:0; top:100%; width:min(460px,85vw); text-align:left; background:var(--papel); border:1px solid var(--borde); border-radius:12px; padding:12px; box-shadow:0 12px 30px #0003; }
.globo pre { white-space:pre-wrap; background:var(--rojo-f); padding:8px; border-radius:8px; font-size:.8rem; margin:8px 0; }
.globo a { display:inline-block; margin-top:6px; color:var(--ambar); font-weight:600; }
.traza { margin-top:8px; display:grid; gap:4px; font-size:.8rem; } .traza .cmd { background:var(--gris-f); padding:6px; border-radius:6px; word-break:break-all; }
.copiar { justify-self:start; border:1px solid var(--borde); background:var(--papel); color:var(--tinta); border-radius:6px; padding:2px 10px; cursor:pointer; }
.leyenda { display:flex; flex-wrap:wrap; gap:14px; color:var(--suave); font-size:.85rem; margin:12px 0; }
.leyenda span { display:inline-flex; gap:6px; align-items:center; }
footer { color:var(--suave); font-size:.8rem; margin-top:20px; }
</style>
</head>
<body>
<header>
  <h1>Portal de pruebas · Tienda <span>Sol</span></h1>
  <p class="sub">Corrida del ${esc(fecha)} · ${matriz.length} casos en la matriz (${pendientes} pendientes) · ${reporte ? `${reporte.stats.expected} pasan, ${reporte.stats.unexpected} fallan, ${reporte.stats.skipped} omitidas, duración ${seg(Math.round(reporte.stats.duration))}` : 'aún no hay resultados: corre las pruebas primero'}</p>
</header>
<main>
  <section class="tarjetas" aria-label="Resumen por motor">${tarjetas || '<p>Sin resultados.</p>'}</section>
  <div class="leyenda" aria-label="Leyenda">
    ${Object.keys(ICONO).map((k) => `<span class="${k}"><span class="pastilla">${ICONO[k]}</span>${TEXTO[k]}</span>`).join('')}
    <span>Haz clic en una celda para ver el error, el reporte y la traza.</span>
  </div>
  <div class="tabla-envoltura">
    <table aria-label="Matriz de casos de prueba por motor">
      <thead><tr><th scope="col">Módulo</th><th scope="col">ID</th><th scope="col">Caso de prueba</th><th scope="col">Prioridad</th>${columnas.map((p) => `<th scope="col" class="motor-col">${esc(p)}</th>`).join('')}</tr></thead>
      <tbody>${filasHtml}</tbody>
    </table>
  </div>
  <footer>Generado por portal/generar.mjs a partir de pruebas/resultados/resultados.json y docs/matriz.csv. Reporte completo: <a href="../pruebas/playwright-report/index.html">playwright-report</a>.</footer>
</main>
<script>
  document.addEventListener('click', (e) => {
    const b = e.target.closest('.copiar');
    if (b) { navigator.clipboard?.writeText(b.previousElementSibling.textContent); b.textContent = 'Copiado'; setTimeout(() => (b.textContent = 'Copiar'), 1500); return; }
    // Abrir un globo cierra los demás.
    const d = e.target.closest('details');
    document.querySelectorAll('details[open]').forEach((x) => { if (x !== d) x.open = false; });
  });
</script>
</body>
</html>
`;

writeFileSync(salida, html);
console.log(`Portal escrito en ${salida}`);
console.log(`Ábrelo en el navegador (doble clic) — ${columnas.length} motores, ${matriz.length} casos.`);
