// Informe de pruebas en Word (.docx) — el resumen que entrega QA al final de un ciclo.
// Lee el reporte JSON de Playwright, docs/matriz.csv, docs/motores-resultados.md (si existe) e
// informe/datos.json (tus datos) y escribe informe/informe-de-pruebas.docx.
//
// Uso (desde la carpeta pruebas/, después de npm test):   npm run informe
// o directamente:                                          node informe/generar.mjs [ruta/resultados.json]
//
// Estructura (estilo ISTQB / IEEE 829 «Test Summary Report»):
//   Portada · 1 Objetivo y alcance · 2 Entorno · 3 Casos planificados vs ejecutados · 4 Resultados ·
//   5 Defectos encontrados · 6 Cobertura de casos de uso · 7 Motores sin interfaz · 8 Riesgos y pendientes ·
//   9 Conclusión y recomendación · Anexo: cómo reproducir.

import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { dirname, join, relative } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
import os from 'node:os';

const aqui = dirname(fileURLToPath(import.meta.url));
const raiz = join(aqui, '..');
const carpetaPruebas = join(raiz, 'pruebas');
const REVISAR = process.argv.includes('--revisar');
const rutaJson = process.argv.slice(2).find((a) => !a.startsWith('--')) ?? join(carpetaPruebas, 'resultados', 'resultados.json');
const rutaCsv = join(raiz, 'docs', 'matriz.csv');
const rutaMotores = join(raiz, 'docs', 'motores-resultados.md');
const rutaDatos = process.env.DATOS ?? join(aqui, 'datos.json'); // DATOS=ruta.json para usar otra hoja (p. ej. ejemplo-datos.json)
const salida = join(aqui, 'informe-de-pruebas.docx');

if (!existsSync(rutaJson)) {
  console.error(`No encuentro el reporte de Playwright en ${relative(raiz, rutaJson)}.`);
  console.error('Primero corre las pruebas desde la carpeta pruebas/:   npm test');
  console.error('y después genera el informe:                            npm run informe');
  process.exit(1);
}

// La librería docx vive en pruebas/node_modules; se resuelve desde ahí para que el script funcione
// aunque se lance desde otra carpeta.
const require = createRequire(join(carpetaPruebas, 'package.json'));
const docx = require('docx');
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, Header, Footer, PageNumber,
  AlignmentType, HeadingLevel, BorderStyle, WidthType, ShadingType, PageBreak, TabStopType, LevelFormat,
} = docx;

// ---------- datos del estudiante ----------
const datos = existsSync(rutaDatos) ? JSON.parse(readFileSync(rutaDatos, 'utf8')) : {};
datos.entorno ??= {};
// Campos que el estudiante REDACTA (los _guia de datos.json dicen qué va en cada uno).
const NARRATIVOS = ['tester', 'objetivo', 'alcance', 'fuera_de_alcance', 'criterio_de_salida', 'riesgos', 'conclusion', 'recomendacion', 'firmado_por'];
const vacio = (v) => (Array.isArray(v) ? v.length === 0 : !String(v ?? '').trim());
const faltan = NARRATIVOS.filter((k) => vacio(datos[k]));
const AMARILLO = 'FFFF00';
// Texto del estudiante o un marcador amarillo «[Completa: …]» si aún no lo escribió.
const redactado = (clave, o = {}) => vacio(datos[clave])
  ? new Paragraph({ spacing: { after: 120 }, children: [new TextRun({ text: `[Completa: ${clave}] ` + (datos['_guia_' + clave] ?? ''), font: 'Arial', size: 20, italics: true, highlight: 'yellow' })] })
  : parrafo(String(datos[clave]), o);
const versionPlaywright = (() => {
  try { return require('@playwright/test/package.json').version; } catch { return ''; }
})();
const entorno = {
  sistema: datos.entorno.sistema || `${os.type()} ${os.release()} (${os.arch()})`,
  node: datos.entorno.node || process.version,
  playwright: datos.entorno.playwright || versionPlaywright || 'no detectada',
  navegadores: datos.entorno.navegadores || 'Chromium headless (Playwright)',
  url_base: datos.entorno.url_base || '',
};

// ---------- matriz ----------
function leerCsv(texto) {
  const filas = [];
  for (const linea of texto.split(/\r?\n/).filter(Boolean)) {
    const celdas = [];
    let actual = '', comillas = false;
    for (const c of linea) {
      if (c === '"') comillas = !comillas;
      else if (c === ',' && !comillas) { celdas.push(actual); actual = ''; }
      else actual += c;
    }
    celdas.push(actual);
    filas.push(celdas);
  }
  const [cab, ...resto] = filas;
  return resto.map((f) => Object.fromEntries(cab.map((k, i) => [k.trim(), (f[i] ?? '').trim()])));
}
const matriz = leerCsv(readFileSync(rutaCsv, 'utf8'));

// ---------- resultados de Playwright ----------
const sinAnsi = (s = '') => s.replace(/\u001b\[[0-9;]*m/g, '');
const reporte = JSON.parse(readFileSync(rutaJson, 'utf8'));
const resultados = new Map(); // id -> { titulo, archivo, porProyecto: { proyecto -> {...} } }
const proyectos = new Set();
const recorrer = (suite) => {
  for (const spec of suite.specs ?? []) {
    const id = (/^([A-Z0-9]{2,4}-[A-Z]{3}-\d{3})/.exec(spec.title) ?? [])[1] ?? spec.title;
    for (const t of spec.tests) {
      const ultimo = t.results.at(-1);
      if (!ultimo) continue;
      proyectos.add(t.projectName);
      let estado = { passed: 'pasa', failed: 'falla', timedOut: 'falla', interrupted: 'falla', skipped: 'omitida' }[ultimo.status] ?? 'falla';
      if (t.status === 'flaky') estado = 'inestable';
      const mensaje = sinAnsi(ultimo.errors?.[0]?.message ?? ultimo.error?.message ?? '');
      const lineas = mensaje.split('\n').map((l) => l.trim()).filter(Boolean);
      const esperado = lineas.find((l) => /^Expected/i.test(l)) ?? '';
      const recibido = lineas.find((l) => /^Received/i.test(l)) ?? '';
      const motivo = lineas.find((l) => /^Error:/.test(l))?.replace(/^Error:\s*/, '') ?? lineas[0] ?? '';
      const evidencias = (ultimo.attachments ?? []).filter((a) => a.path).map((a) => `${a.name}: ${relative(carpetaPruebas, a.path)}`);
      if (!resultados.has(id)) resultados.set(id, { titulo: spec.title, archivo: spec.file, porProyecto: {} });
      resultados.get(id).porProyecto[t.projectName] = { estado, ms: ultimo.duration, motivo, esperado, recibido, evidencias };
    }
  }
  for (const s of suite.suites ?? []) recorrer(s);
};
for (const s of reporte.suites) recorrer(s);

const ORDEN = ['api', 'chromium', 'chromium-traza', 'lightpanda', 'obscura'];
const columnas = [...proyectos].sort((a, b) => (ORDEN.indexOf(a) + 99 * (ORDEN.indexOf(a) < 0)) - (ORDEN.indexOf(b) + 99 * (ORDEN.indexOf(b) < 0)));
const enMatriz = new Set(matriz.map((f) => f.id_prueba));
for (const [id, r] of resultados) {
  if (!enMatriz.has(id)) matriz.push({ caso_uso: 'Fuera de la matriz', modulo: '—', id_prueba: id, descripcion: r.titulo, spec: r.archivo, prioridad: '—', estado: 'sin registrar' });
}

// Estado consolidado de un caso: falla si falla en cualquier motor; pasa si pasa en todos los que corrió.
function estadoCaso(id) {
  const r = resultados.get(id);
  if (!r) return 'sin correr';
  const estados = Object.values(r.porProyecto).map((x) => x.estado);
  if (estados.includes('falla')) return 'falla';
  if (estados.includes('inestable')) return 'inestable';
  if (estados.every((e) => e === 'omitida')) return 'omitida';
  return 'pasa';
}
const porCaso = matriz.map((f) => ({ ...f, resultado: estadoCaso(f.id_prueba) }));
const totales = { pasa: 0, falla: 0, omitida: 0, inestable: 0, 'sin correr': 0 };
for (const f of porCaso) totales[f.resultado]++;
const ejecutados = totales.pasa + totales.falla + totales.inestable;
const defectos = porCaso.filter((f) => f.resultado === 'falla');
const pendientes = porCaso.filter((f) => f.estado === 'pendiente');
const fallaAlta = defectos.some((f) => f.prioridad === 'Alta');
const veredicto = fallaAlta ? 'NO APTO' : defectos.length ? 'APTO CON OBSERVACIONES' : pendientes.length ? 'APTO CON RIESGO' : 'APTO';

// ---------- módulos ----------
const modulos = new Map();
for (const f of porCaso) {
  if (!modulos.has(f.modulo)) modulos.set(f.modulo, { pasa: 0, falla: 0, otros: 0, ms: 0 });
  const m = modulos.get(f.modulo);
  if (f.resultado === 'pasa') m.pasa++; else if (f.resultado === 'falla') m.falla++; else m.otros++;
  const r = resultados.get(f.id_prueba);
  if (r) m.ms += Math.max(...Object.values(r.porProyecto).map((x) => x.ms));
}

// ---------- motores (docs/motores-resultados.md) ----------
let filasMotores = [];
if (existsSync(rutaMotores)) {
  const md = readFileSync(rutaMotores, 'utf8');
  const bloque = md.split(/^## /m).find((s) => s.startsWith('Suite E2E')) ?? '';
  filasMotores = bloque.split('\n').filter((l) => /^\| \*?\*?(Chromium|Lightpanda|Obscura)/.test(l))
    .map((l) => l.split('|').slice(1, -1).map((c) => c.replace(/\*\*/g, '').replace(/`/g, '').trim()));
}
// También lo medido en esta corrida, por motor.
const medidoAhora = columnas.map((p) => {
  const c = { pasa: 0, falla: 0, omitida: 0, ms: 0 };
  for (const r of resultados.values()) { const x = r.porProyecto[p]; if (x) { c[x.estado === 'inestable' ? 'pasa' : x.estado]++; c.ms += x.ms; } }
  return [p, `${c.pasa} pasan · ${c.falla} fallan${c.omitida ? ` · ${c.omitida} omitidas` : ''}`, seg(c.ms)];
});

// ---------- utilidades de texto ----------
function seg(ms) { return ms >= 1000 ? (ms / 1000).toFixed(1).replace('.', ',') + ' s' : Math.round(ms) + ' ms'; }
const fechaLima = (d) => new Date(d).toLocaleString('es-PE', { timeZone: 'America/Lima', dateStyle: 'long', timeStyle: 'short' });
const fechaCorrida = fechaLima(reporte.stats.startTime);
const fechaInforme = datos.fecha || fechaLima(new Date());
const pct = (a, b) => (b ? Math.round((a / b) * 100) + ' %' : '—');

// ---------- piezas de Word ----------
const FUENTE = 'Arial';
const AZUL = '1F3864', GRIS = 'F2F2F2', VERDE = 'E2F0D9', ROJO = 'FBE4E4', AMBAR = 'FFF2CC';
const borde = { style: BorderStyle.SINGLE, size: 4, color: 'BFBFBF' };
const bordes = { top: borde, bottom: borde, left: borde, right: borde };

const texto = (t, o = {}) => new TextRun({ text: t, font: FUENTE, size: o.size ?? 20, bold: o.bold, color: o.color, italics: o.italics });
const parrafo = (t, o = {}) => new Paragraph({ alignment: o.alineacion, spacing: { after: o.despues ?? 120, before: o.antes ?? 0 }, children: Array.isArray(t) ? t : [texto(t, o)] });
const titulo = (t, nivel = 1) => new Paragraph({
  heading: nivel === 1 ? HeadingLevel.HEADING_1 : HeadingLevel.HEADING_2,
  spacing: { before: nivel === 1 ? 360 : 240, after: 120 },
  children: [texto(t, { size: nivel === 1 ? 28 : 24, bold: true, color: AZUL })],
});
const vineta = (t) => new Paragraph({ numbering: { reference: 'vinetas', level: 0 }, spacing: { after: 60 }, children: Array.isArray(t) ? t : [texto(t)] });
const mono = (t) => new Paragraph({ spacing: { after: 60 }, shading: { type: ShadingType.CLEAR, fill: GRIS }, children: [new TextRun({ text: t, font: 'Consolas', size: 18 })] });

function celda(contenido, o = {}) {
  const hijos = (Array.isArray(contenido) ? contenido : [contenido]).map((c) =>
    typeof c === 'string' ? new Paragraph({ spacing: { after: 0 }, alignment: o.alineacion, children: [texto(c, { size: o.size ?? 18, bold: o.bold, color: o.color })] }) : c);
  return new TableCell({
    children: hijos, borders: bordes, width: o.ancho ? { size: o.ancho, type: WidthType.PERCENTAGE } : undefined,
    shading: o.fondo ? { type: ShadingType.CLEAR, fill: o.fondo, color: 'auto' } : undefined,
    margins: { top: 60, bottom: 60, left: 100, right: 100 },
  });
}
function tabla(cabecera, filas, anchos, colorFila) {
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows: [
      new TableRow({ tableHeader: true, children: cabecera.map((c, i) => celda(c, { bold: true, color: 'FFFFFF', fondo: AZUL, ancho: anchos?.[i] })) }),
      ...filas.map((f) => new TableRow({ children: f.map((c, i) => celda(c, { ancho: anchos?.[i], fondo: colorFila?.(f, i) })) })),
    ],
  });
}
const fondoEstado = (estado) => ({ pasa: VERDE, falla: ROJO, inestable: AMBAR, omitida: GRIS, 'sin correr': GRIS })[estado];

// ---------- portada ----------
const portada = [
  new Paragraph({ spacing: { before: 2400, after: 200 }, alignment: AlignmentType.CENTER, children: [texto('INFORME DE PRUEBAS', { size: 44, bold: true, color: AZUL })] }),
  new Paragraph({ spacing: { after: 600 }, alignment: AlignmentType.CENTER, children: [texto('Resumen de ejecución y recomendación de despliegue', { size: 24, color: '595959' })] }),
  new Paragraph({ spacing: { after: 120 }, alignment: AlignmentType.CENTER, children: [texto(datos.proyecto || 'Proyecto', { size: 32, bold: true })] }),
  new Paragraph({ spacing: { after: 800 }, alignment: AlignmentType.CENTER, children: [texto(`Versión ${datos.version || '—'}`, { size: 22 })] }),
  new Table({
    width: { size: 70, type: WidthType.PERCENTAGE }, alignment: AlignmentType.CENTER,
    rows: [
      ['Elaborado por', datos.tester || '—'],
      ['Fecha del informe', fechaInforme],
      ['Fecha de la corrida', fechaCorrida],
      ['Resultado', `${totales.pasa} pasan · ${totales.falla} fallan · ${totales.omitida + totales['sin correr']} sin ejecutar`],
      ['Veredicto', veredicto],
    ].map(([k, v]) => new TableRow({ children: [celda(k, { bold: true, fondo: GRIS, ancho: 40 }), celda(v, { ancho: 60, bold: k === 'Veredicto', color: k === 'Veredicto' ? (fallaAlta ? 'C00000' : '2E7D32') : undefined })] })),
  }),
  new Paragraph({ children: [new PageBreak()] }),
];

// ---------- secciones ----------
const s1 = [
  titulo('1. Objetivo y alcance'),
  redactado('objetivo'),
  titulo('Alcance', 2),
  redactado('alcance'),
  parrafo(`Dato de la corrida: ${matriz.length} casos en docs/matriz.csv, ${ejecutados} ejecutados.`, { italics: true, size: 18, color: '7F7F7F' }),
  titulo('Fuera de alcance', 2),
  redactado('fuera_de_alcance'),
  titulo('Criterio de salida (acordado antes de probar)', 2),
  redactado('criterio_de_salida'),
];

const s2 = [
  titulo('2. Entorno de pruebas'),
  tabla(['Elemento', 'Valor'], [
    ['Sistema operativo', entorno.sistema],
    ['Node.js', entorno.node],
    ['Playwright', entorno.playwright],
    ['Navegadores / motores', entorno.navegadores],
    ['URL bajo prueba', entorno.url_base || '—'],
    ['Proyectos ejecutados', columnas.join(', ') || '—'],
    ['Datos de prueba', 'Semilla determinista (app/datos/semilla.json) cargada antes de cada prueba con POST /api/semilla'],
  ], [35, 65]),
];

const s3 = [
  titulo('3. Casos planificados vs ejecutados'),
  parrafo(`Planificados en la matriz: ${matriz.length}. Ejecutados en esta corrida: ${ejecutados}. Pendientes de automatizar: ${pendientes.length}.`),
  tabla(['ID', 'Módulo', 'Descripción', 'Prioridad', 'Resultado'],
    porCaso.map((f) => [f.id_prueba, f.modulo, f.descripcion, f.prioridad, f.resultado === 'sin correr' && f.estado === 'pendiente' ? 'pendiente' : f.resultado]),
    [16, 12, 48, 11, 13], (f, i) => (i === 4 ? fondoEstado(f[4] === 'pendiente' ? 'sin correr' : f[4]) : undefined)),
];

const s4 = [
  titulo('4. Resultados'),
  tabla(['Indicador', 'Valor'], [
    ['Casos ejecutados', String(ejecutados)],
    ['Pasan', `${totales.pasa} (${pct(totales.pasa, ejecutados)})`],
    ['Fallan', `${totales.falla} (${pct(totales.falla, ejecutados)})`],
    ['Inestables (flaky)', String(totales.inestable)],
    ['Omitidas', String(totales.omitida)],
    ['Sin correr / pendientes', String(totales['sin correr'])],
    ['Duración total de la corrida', seg(reporte.stats.duration)],
  ], [50, 50]),
  parrafo(''),
  titulo('Por módulo', 2),
  tabla(['Módulo', 'Pasan', 'Fallan', 'Otros', '% éxito', 'Duración'],
    [...modulos].map(([m, c]) => [m, String(c.pasa), String(c.falla), String(c.otros), pct(c.pasa, c.pasa + c.falla), seg(c.ms)]),
    [25, 13, 13, 13, 16, 20], (f, i) => (i === 2 && Number(f[2]) > 0 ? ROJO : undefined)),
];

const s5 = [titulo('5. Defectos encontrados')];
if (!defectos.length) s5.push(parrafo('No se encontraron defectos en esta corrida.'));
else {
  s5.push(parrafo(`Se encontraron ${defectos.length} defecto(s). Cada uno se reproduce con su traza (npx playwright show-trace RUTA).`));
  defectos.forEach((f, n) => {
    const r = resultados.get(f.id_prueba);
    const motor = Object.entries(r.porProyecto).find(([, x]) => x.estado === 'falla');
    const x = motor?.[1] ?? {};
    const severidad = f.prioridad === 'Alta' ? 'Alta (bloquea el despliegue)' : f.prioridad === 'Media' ? 'Media' : 'Baja';
    s5.push(titulo(`DEF-${String(n + 1).padStart(2, '0')} · ${f.id_prueba} · ${f.descripcion}`, 2));
    s5.push(tabla(['Campo', 'Detalle'], [
      ['Caso de uso', f.caso_uso],
      ['Spec', `${f.spec} (${motor?.[0] ?? '—'})`],
      ['Severidad', severidad],
      ['Qué debía pasar', x.esperado || 'Ver el resultado esperado del caso'],
      ['Qué pasó', x.recibido || x.motivo || '—'],
      ['Mensaje del runner', x.motivo || '—'],
      ['Evidencia', x.evidencias?.length ? x.evidencias.join('\n') : 'Reporte HTML: npx playwright show-report'],
    ], [28, 72], (fila, i) => (i === 1 && fila[0] === 'Severidad' && f.prioridad === 'Alta' ? ROJO : undefined)));
    s5.push(parrafo(''));
  });
}

const casosUso = new Map();
for (const f of porCaso) {
  if (!casosUso.has(f.caso_uso)) casosUso.set(f.caso_uso, []);
  casosUso.get(f.caso_uso).push(f);
}
const s6 = [
  titulo('6. Cobertura de casos de uso'),
  tabla(['Caso de uso', 'Pruebas', 'Pasan', 'Fallan', 'Pendientes', 'Cubierto'],
    [...casosUso].map(([cu, fs]) => {
      const p = fs.filter((f) => f.resultado === 'pasa').length, fa = fs.filter((f) => f.resultado === 'falla').length, pe = fs.filter((f) => f.estado === 'pendiente').length;
      return [cu, String(fs.length), String(p), String(fa), String(pe), fa ? 'Con defectos' : pe === fs.length ? 'Sin automatizar' : pe ? 'Parcial' : 'Sí'];
    }), [36, 12, 12, 12, 14, 14], (f, i) => (i === 5 ? (f[5] === 'Con defectos' ? ROJO : f[5] === 'Sí' ? VERDE : AMBAR) : undefined)),
];

const s7 = [
  titulo('7. Motores sin interfaz comparados'),
  parrafo('Medido en esta corrida (por proyecto de Playwright):'),
  tabla(['Motor', 'Resultado', 'Duración sumada'], medidoAhora, [30, 45, 25]),
];
if (filasMotores.length) {
  s7.push(parrafo(''), parrafo('Referencia medida al preparar el kit (docs/motores-resultados.md):', { italics: true }));
  s7.push(tabla(['Motor', 'App corregida', 'Con defectos', 'Tiempo (corregida)', 'RAM pico'], filasMotores.map((f) => f.slice(0, 5)), [16, 22, 22, 20, 20]));
}
s7.push(parrafo(''), parrafo('Lightpanda no dibuja la página: no sirve para capturas ni pruebas visuales. Obscura no dispara el evento change al perder el foco: un rojo solo en Obscura se verifica en Chromium antes de registrarlo como defecto.', { italics: true, size: 18 }));

const s8 = [titulo('8. Riesgos y pendientes')];
if (pendientes.length) {
  s8.push(parrafo('Casos de la matriz aún no automatizados:'));
  for (const f of pendientes) s8.push(vineta(`${f.id_prueba} · ${f.descripcion} (${f.prioridad})`));
}
if (vacio(datos.riesgos)) s8.push(redactado('riesgos'));
else for (const r of datos.riesgos) s8.push(vineta(r));

const motivoVeredicto = fallaAlta
  ? `Hay ${defectos.filter((f) => f.prioridad === 'Alta').length} defecto(s) de prioridad Alta sin corregir. Regla aplicada: cualquier caso de prioridad Alta en rojo bloquea el despliegue.`
  : defectos.length ? 'Los defectos encontrados son de prioridad Media o Baja: se puede desplegar registrándolos como deuda y con fecha de corrección.'
  : pendientes.length ? `Todos los casos ejecutados pasan. Quedan ${pendientes.length} caso(s) sin automatizar: se despliega aceptando ese riesgo y se cubren en la siguiente iteración.`
  : 'Todos los casos de la matriz se ejecutaron y pasan.';
const s9 = [
  titulo('9. Conclusión y recomendación'),
  new Paragraph({ spacing: { after: 160 }, shading: { type: ShadingType.CLEAR, fill: fallaAlta ? ROJO : VERDE }, children: [texto(`Veredicto calculado por la herramienta: ${veredicto} para desplegar`, { size: 24, bold: true, color: fallaAlta ? 'C00000' : '2E7D32' })] }),
  parrafo(motivoVeredicto, { italics: true, size: 18, color: '7F7F7F' }),
  titulo('Conclusión del tester', 2),
  redactado('conclusion'),
  titulo('Recomendación', 2),
  redactado('recomendacion'),
  parrafo(''),
  parrafo('Regla general de referencia (ajústala en tu criterio de salida):', { bold: true, size: 18 }),
  vineta('Prioridad Alta en rojo → NO APTO.'),
  vineta('Solo Media o Baja en rojo → APTO CON OBSERVACIONES (defectos registrados con responsable y fecha).'),
  vineta('Todo verde con casos pendientes → APTO CON RIESGO (se declara qué no se probó).'),
  vineta('Todo verde y nada pendiente → APTO.'),
  parrafo(''),
  parrafo('Firma', { bold: true }),
  redactado('firmado_por'),
];

const anexo = [
  titulo('Anexo. Cómo reproducir esta corrida'),
  parrafo('Desde la carpeta pruebas/ del kit:'),
  mono('npm install && npx playwright install chromium'),
  mono('npm test                      # API + E2E en Chromium (tienda con defectos)'),
  mono('npm run test:corregido        # misma suite con BUGS=0'),
  mono('npm run test:lightpanda && npm run test:obscura   # motores sin interfaz (Docker en motores/)'),
  mono('npx playwright show-report    # reporte HTML'),
  mono('npx playwright show-trace test-results/CARPETA/trace.zip   # reproducir un caso paso a paso'),
  mono('npm run portal && npm run informe   # portal de resultados e informe Word'),
  parrafo(''),
  parrafo(`Reporte JSON usado: ${relative(raiz, rutaJson)} · Generado el ${fechaLima(new Date())} (hora de Lima).`, { size: 16, italics: true, color: '7F7F7F' }),
];

// ---------- documento ----------
const doc = new Document({
  creator: datos.tester || 'QA',
  title: `Informe de pruebas · ${datos.proyecto || ''}`,
  styles: {
    default: { document: { run: { font: FUENTE, size: 20 } } },
    paragraphStyles: [
      { id: 'Heading1', name: 'Heading 1', basedOn: 'Normal', next: 'Normal', quickFormat: true, run: { font: FUENTE, size: 28, bold: true, color: AZUL } },
      { id: 'Heading2', name: 'Heading 2', basedOn: 'Normal', next: 'Normal', quickFormat: true, run: { font: FUENTE, size: 24, bold: true, color: AZUL } },
    ],
  },
  numbering: { config: [{ reference: 'vinetas', levels: [{ level: 0, format: LevelFormat.BULLET, text: '•', alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 270 } } } }] }] },
  sections: [{
    properties: { page: { margin: { top: 1134, bottom: 1134, left: 1247, right: 1247 } } },
    headers: { default: new Header({ children: [new Paragraph({ tabStops: [{ type: TabStopType.RIGHT, position: 9000 }], children: [texto(`Informe de pruebas · ${datos.proyecto || ''}`, { size: 16, color: '7F7F7F' }), new TextRun({ text: '\t' }), texto(fechaInforme, { size: 16, color: '7F7F7F' })] })] }) },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [texto('Página ', { size: 16, color: '7F7F7F' }), new TextRun({ font: FUENTE, size: 16, color: '7F7F7F', children: [PageNumber.CURRENT] }), texto(' de ', { size: 16, color: '7F7F7F' }), new TextRun({ font: FUENTE, size: 16, color: '7F7F7F', children: [PageNumber.TOTAL_PAGES] })] })] }) },
    children: [...portada, ...s1, ...s2, ...s3, ...s4, ...s5, ...s6, ...s7, ...s8, ...s9, ...anexo],
  }],
});

// ---------- revisión del informe (como lo haría el jefe de QA) ----------
function revisar() {
  const problemas = [];
  for (const k of faltan) problemas.push(`Falta redactar «${k}» (ver _guia_${k} en informe/datos.json).`);
  const concl = String(datos.conclusion ?? '');
  const palabraVeredicto = /\bNO APTO|NO APTA|APTO|APTA\b/i;
  if (!vacio(concl) && !palabraVeredicto.test(concl)) problemas.push('La conclusión no dice si la aplicación es APTA o NO APTA.');
  if (!vacio(concl) && fallaAlta && !/NO APT/i.test(concl)) problemas.push(`Hay ${defectos.filter((f) => f.prioridad === 'Alta').length} defecto(s) de prioridad Alta, pero la conclusión no dice NO APTO. Si tu criterio de salida es otro, explícalo ahí.`);
  if (!vacio(concl) && !/\d/.test(concl)) problemas.push('La conclusión no cita ninguna cifra (casos ejecutados, cuántos pasan, cuántos fallan).');
  const altas = defectos.filter((f) => f.prioridad === 'Alta');
  for (const [n, f] of defectos.entries()) {
    const def = `DEF-${String(n + 1).padStart(2, '0')}`;
    if (f.prioridad === 'Alta' && !(concl.includes(f.id_prueba) || concl.includes(def) || String(datos.recomendacion ?? '').includes(f.id_prueba) || String(datos.recomendacion ?? '').includes(def)))
      problemas.push(`El defecto ${def} (${f.id_prueba}, Alta) no aparece ni en la conclusión ni en la recomendación.`);
  }
  if (!vacio(datos.alcance) && !/\d/.test(String(datos.alcance))) problemas.push('El alcance no dice cuántos casos se probaron.');
  return { problemas, altas: altas.length };
}
const revision = revisar();

if (REVISAR) {
  console.log(`Revisión del informe · corrida: ${ejecutados} ejecutados · ${totales.pasa} pasan · ${totales.falla} fallan · veredicto calculado: ${veredicto}`);
  if (!revision.problemas.length) { console.log('✓ Informe completo: sin marcadores, conclusión con veredicto y cifras, defectos Alta citados.'); process.exit(0); }
  console.log(`✗ ${revision.problemas.length} cosa(s) por corregir:`);
  for (const p of revision.problemas) console.log('  - ' + p);
  process.exit(2);
}

const buffer = await Packer.toBuffer(doc);
writeFileSync(salida, buffer);
console.log(`Informe escrito en ${relative(process.cwd(), salida) || salida}`);
console.log(`Casos: ${ejecutados} ejecutados · ${totales.pasa} pasan · ${totales.falla} fallan · ${pendientes.length} pendientes · Veredicto calculado: ${veredicto} (tú lo argumentas en «conclusion»)`);
if (faltan.length) {
  console.log(`Faltan ${faltan.length} campo(s) por redactar en informe/datos.json: ${faltan.join(', ')}.`);
  console.log('En el Word aparecen en amarillo como [Completa: …]. Cuando termines: npm run informe:revisar');
} else if (revision.problemas.length) {
  console.log(`Todos los campos tienen texto, pero la revisión encontró ${revision.problemas.length} cosa(s): npm run informe:revisar`);
} else console.log('✓ Campos completos y revisión sin observaciones.');
