// Robot de pruebas: corre la suite E2E del kit cada N minutos y publica una página de estado.
// Sin dependencias (usa la carpeta pruebas/ del kit con npx playwright).
//
//   node robot/robot.mjs                      -> cada 10 min, Chromium, app local en modo prueba (la levanta Playwright)
//   CADA_MIN=5 MOTOR=lightpanda node robot/robot.mjs
//   BASE_URL=https://jmd-learn.online/tienda-sol/ node robot/robot.mjs   -> crea su propia tienda y la mantiene viva
//
// Variables: PUERTO (3200), CADA_MIN (10), MOTOR (chromium | lightpanda | obscura), BASE_URL (opcional),
//            CDP_URL (ws://127.0.0.1:9222 para Lightpanda), HOST (127.0.0.1; 0.0.0.0 dentro de Docker).
// Página de estado: http://localhost:3200  ·  API: /api/estado  ·  POST /api/correr  ·  /reporte/ (HTML de Playwright)

import { createServer } from 'node:http';
import { spawn } from 'node:child_process';
import { mkdir, readdir, readFile, writeFile, unlink, stat } from 'node:fs/promises';
import { join, dirname, normalize, extname } from 'node:path';
import { fileURLToPath } from 'node:url';

const aqui = dirname(fileURLToPath(import.meta.url));
const PRUEBAS = process.env.PRUEBAS_DIR ?? join(aqui, '..', 'pruebas');
const HISTORIAL = join(aqui, 'historial');
const PUERTO = Number(process.env.PUERTO ?? 3200);
const HOST = process.env.HOST ?? '127.0.0.1';
const CADA_MS = Math.max(1, Number(process.env.CADA_MIN ?? 10)) * 60_000;
const MOTOR = process.env.MOTOR ?? 'chromium';
const MAX_HISTORIAL = 200;

let corriendo = false;
let ultima = null;
let proxima = Date.now() + CADA_MS;
let historial = [];
let cookieTienda = ''; // cuando BASE_URL es /tienda-sol/ (sin código), el robot crea su tienda y la conserva
let baseResuelta = process.env.BASE_URL ?? '';

const fechaLima = (d = new Date()) => new Intl.DateTimeFormat('es-PE', { timeZone: 'America/Lima', dateStyle: 'short', timeStyle: 'medium' }).format(d);

// ---------- tienda propia en la web pública (opcional) ----------
async function resolverBase() {
  const base = process.env.BASE_URL ?? '';
  if (!/\/tienda-sol\/?$/.test(base)) return base;
  // ¿sigue viva la tienda anterior?
  if (baseResuelta !== base) {
    try { const r = await fetch(baseResuelta + 'salud', { headers: { cookie: cookieTienda } }); if (r.ok) return baseResuelta; } catch { /* se vuelve a crear */ }
  }
  const r = await fetch(base.replace(/\/?$/, '/'), { redirect: 'manual', headers: { cookie: cookieTienda } });
  const destino = r.headers.get('location');
  const galleta = r.headers.get('set-cookie');
  if (!destino) throw new Error(`No pude crear una tienda en ${base} (HTTP ${r.status})`);
  if (galleta) cookieTienda = galleta.split(';')[0];
  baseResuelta = new URL(destino, base).toString();
  console.log('Tienda del robot:', baseResuelta);
  return baseResuelta;
}

// ---------- una corrida ----------
function ejecutar(cmd, args, opciones) {
  return new Promise((resolver) => {
    const p = spawn(cmd, args, { ...opciones, shell: process.platform === 'win32' });
    let salida = '';
    p.stdout.on('data', (d) => { salida += d; });
    p.stderr.on('data', (d) => { salida += d; });
    p.on('close', (codigo) => resolver({ codigo, salida }));
    p.on('error', (err) => resolver({ codigo: -1, salida: String(err) }));
  });
}

async function correr(motivo = 'programada') {
  if (corriendo) return;
  corriendo = true;
  const inicio = Date.now();
  const archivoJson = join(HISTORIAL, 'ultima-corrida.json');
  let resumen = { inicio: new Date(inicio).toISOString(), motivo, motor: MOTOR, baseUrl: '', pasan: 0, fallan: 0, omitidas: 0, inestables: 0, duracionMs: 0, pruebas: [], error: null };
  try {
    const base = await resolverBase();
    resumen.baseUrl = base || `(app local en modo prueba, puerto ${process.env.PUERTO_APP ?? 3100})`;
    const env = { ...process.env, PLAYWRIGHT_JSON_OUTPUT_NAME: archivoJson, CI: '', FORCE_COLOR: '0' };
    if (base) env.BASE_URL = base; else delete env.BASE_URL;
    if (process.env.PUERTO_APP) env.PUERTO = process.env.PUERTO_APP; else delete env.PUERTO; // PUERTO es del robot, no de la app
    const proyectos = ['api', MOTOR].flatMap((p) => ['--project', p]);
    const r = await ejecutar('npx', ['playwright', 'test', ...proyectos, '--reporter=json,html', '--retries=0'], { cwd: PRUEBAS, env });
    let json = null;
    try { json = JSON.parse(await readFile(archivoJson, 'utf8')); } catch { resumen.error = 'Playwright no dejó reporte JSON. Salida:\n' + r.salida.slice(-1500); }
    if (json) {
      const recorrer = (suite, archivo) => {
        for (const s of suite.suites ?? []) recorrer(s, s.file ?? archivo);
        for (const spec of suite.specs ?? []) for (const t of spec.tests ?? []) {
          const res = t.results?.[t.results.length - 1] ?? {};
          const estado = t.status === 'expected' ? 'pasa' : t.status === 'skipped' ? 'omitida' : t.status === 'flaky' ? 'inestable' : 'falla';
          resumen.pruebas.push({ id: /^([A-Z0-9-]+)/.exec(spec.title)?.[1] ?? spec.title, titulo: spec.title, archivo: spec.file ?? archivo, proyecto: t.projectName, estado, duracionMs: res.duration ?? 0, error: res.error?.message?.split('\n').slice(0, 3).join(' ') ?? null });
        }
      };
      for (const s of json.suites ?? []) recorrer(s, s.file);
      resumen.pasan = json.stats?.expected ?? 0; resumen.fallan = json.stats?.unexpected ?? 0; resumen.omitidas = json.stats?.skipped ?? 0; resumen.inestables = json.stats?.flaky ?? 0;
    }
  } catch (err) {
    resumen.error = String(err.message ?? err);
  }
  resumen.duracionMs = Date.now() - inicio;
  resumen.fin = new Date().toISOString();
  ultima = resumen;
  const nombre = resumen.inicio.replace(/[:.]/g, '-') + '.json';
  await writeFile(join(HISTORIAL, nombre), JSON.stringify(resumen));
  historial.push({ archivo: nombre, inicio: resumen.inicio, pasan: resumen.pasan, fallan: resumen.fallan, omitidas: resumen.omitidas, duracionMs: resumen.duracionMs, error: resumen.error ? 'sí' : null });
  while (historial.length > MAX_HISTORIAL) { const viejo = historial.shift(); await unlink(join(HISTORIAL, viejo.archivo)).catch(() => {}); }
  console.log(`${fechaLima()} · ${motivo} · ${resumen.pasan} pasan · ${resumen.fallan} fallan · ${(resumen.duracionMs / 1000).toFixed(1)} s${resumen.error ? ' · ERROR: ' + resumen.error.split('\n')[0] : ''}`);
  corriendo = false;
  proxima = Date.now() + CADA_MS;
}

// ---------- página de estado ----------
const PAGINA = `<!doctype html><html lang="es-PE"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Robot de pruebas · Tienda Sol</title>
<style>
body{margin:0;font:15px/1.45 system-ui,sans-serif;background:#f6f7fb;color:#1d2433}header{background:#171b28;color:#fff;padding:14px 22px;display:flex;gap:14px;align-items:center}
header b{color:#f5a623}main{padding:18px 22px;max-width:1100px;margin:auto}.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin:14px 0}
.kpi{background:#fff;border:1px solid #e2e5ec;border-radius:12px;padding:12px 14px}.kpi b{display:block;font-size:30px}.ok{color:#1e7f3b}.bad{color:#b3261e}
.tira{display:flex;gap:2px;height:46px;align-items:flex-end;background:#fff;border:1px solid #e2e5ec;border-radius:12px;padding:8px}.tira i{flex:1;background:#2fa65a;border-radius:2px;min-width:3px}.tira i.bad{background:#d8322a}.tira i.err{background:#9aa0ad}.tira i.vacio{background:#eceef3}
table{width:100%;border-collapse:collapse;background:#fff;border:1px solid #e2e5ec;border-radius:12px;overflow:hidden;font-size:14px}th,td{padding:7px 10px;border-bottom:1px solid #eef0f4;text-align:left}th{background:#f1f3f8}td.err{color:#b3261e;font-family:ui-monospace,monospace;font-size:12px}
button{font:600 14px system-ui,sans-serif;padding:8px 14px;border-radius:9px;border:1px solid #f5a623;background:#f5a623;cursor:pointer}small{color:#5b6472}
</style>
<header>🤖 <b>Robot de pruebas</b> · Tienda Sol <span id="motor"></span><span style="margin-left:auto"><button id="correr">Correr ahora</button></span></header>
<main>
<p id="resumen">Cargando…</p>
<div class="kpis"><div class="kpi"><b id="pasan" class="ok">–</b>pasan</div><div class="kpi"><b id="fallan" class="bad">–</b>fallan</div><div class="kpi"><b id="disp">–</b>corridas en verde (24 h)</div><div class="kpi"><b id="dur">–</b>duración</div><div class="kpi"><b id="prox">–</b>próxima corrida</div></div>
<p><small>Últimas 24 h · cada barra es una corrida (verde: todo pasó · rojo: algo falló · gris: el robot no pudo correr)</small></p>
<div class="tira" id="tira"></div>
<h2>Última corrida</h2>
<p><a id="reporte" href="reporte/" target="_blank">Reporte HTML de Playwright ↗</a> · <small id="base"></small></p>
<table><thead><tr><th>ID</th><th>Prueba</th><th>Estado</th><th>ms</th><th>Error</th></tr></thead><tbody id="filas"></tbody></table>
<p id="error" class="bad"></p>
</main>
<script>
const $=id=>document.getElementById(id);
async function pintar(){const e=await (await fetch('api/estado')).json();$('motor').textContent='· motor: '+e.motor+' · cada '+e.cadaMin+' min';
if(!e.ultima){$('resumen').textContent=e.corriendo?'Corriendo la primera vez…':'Todavía no corrió.';return}
const u=e.ultima;$('resumen').innerHTML='<b>'+(u.fallan||u.error?'🔴 Hay fallos':'🟢 Todo en verde')+'</b> · última corrida '+new Date(u.fin).toLocaleString('es-PE',{timeZone:'America/Lima'})+(e.corriendo?' · <em>corriendo ahora…</em>':'');
$('pasan').textContent=u.pasan;$('fallan').textContent=u.fallan;$('dur').textContent=(u.duracionMs/1000).toFixed(0)+' s';$('base').textContent=u.baseUrl;
const h=e.historial.filter(x=>Date.now()-new Date(x.inicio)<864e5);const verdes=h.filter(x=>!x.fallan&&!x.error).length;$('disp').textContent=h.length?Math.round(100*verdes/h.length)+' %':'–';
$('prox').textContent=e.corriendo?'ahora':Math.max(0,Math.round((new Date(e.proxima)-Date.now())/60000))+' min';
$('tira').innerHTML=(h.length?h:[]).map(x=>'<i class="'+(x.error?'err':x.fallan?'bad':'')+'" title="'+new Date(x.inicio).toLocaleTimeString('es-PE')+' · '+x.pasan+' pasan · '+x.fallan+' fallan"></i>').join('')||'<i class="vacio"></i>';
$('filas').innerHTML=u.pruebas.map(p=>'<tr><td>'+p.id+'</td><td>'+p.titulo.replace(/^[A-Z0-9-]+ /,'')+' <small>'+p.proyecto+'</small></td><td class="'+(p.estado==='pasa'?'ok':p.estado==='omitida'?'':'bad')+'">'+p.estado+'</td><td>'+p.duracionMs+'</td><td class="err">'+(p.error??'')+'</td></tr>').join('');
$('error').textContent=u.error??'';}
$('correr').onclick=async()=>{await fetch('api/correr',{method:'POST'});pintar()};pintar();setInterval(pintar,15000);
</script></html>`;

const TIPOS = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.zip': 'application/zip', '.json': 'application/json', '.md': 'text/markdown', '.webm': 'video/webm', '.svg': 'image/svg+xml' };
async function estatico(res, raiz, ruta) {
  const archivo = normalize(join(raiz, ruta === '' || ruta === '/' ? 'index.html' : ruta));
  if (!archivo.startsWith(raiz)) { res.writeHead(404); return res.end(); }
  try {
    if ((await stat(archivo)).isDirectory()) return estatico(res, raiz, join(ruta, 'index.html'));
    res.writeHead(200, { 'content-type': TIPOS[extname(archivo)] ?? 'application/octet-stream' });
    res.end(await readFile(archivo));
  } catch { res.writeHead(404, { 'content-type': 'text/plain' }); res.end('No hay reporte todavía. Espera la primera corrida.'); }
}

await mkdir(HISTORIAL, { recursive: true });
for (const f of (await readdir(HISTORIAL)).filter((f) => /^\d{4}-.*\.json$/.test(f)).sort().slice(-MAX_HISTORIAL)) {
  try { const r = JSON.parse(await readFile(join(HISTORIAL, f), 'utf8')); historial.push({ archivo: f, inicio: r.inicio, pasan: r.pasan, fallan: r.fallan, omitidas: r.omitidas, duracionMs: r.duracionMs, error: r.error ? 'sí' : null }); if (!ultima || r.inicio > ultima.inicio) ultima = r; } catch { /* archivo roto */ }
}

createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  const ruta = url.pathname.replace(/^\/qa-robot/, ''); // también sirve bajo /qa-robot/ detrás de nginx
  if (ruta === '/api/estado') { res.writeHead(200, { 'content-type': 'application/json', 'cache-control': 'no-store' }); return res.end(JSON.stringify({ corriendo, motor: MOTOR, cadaMin: CADA_MS / 60_000, proxima: new Date(proxima).toISOString(), ultima, historial })); }
  if (ruta === '/api/correr' && req.method === 'POST') { correr('manual'); res.writeHead(202, { 'content-type': 'application/json' }); return res.end('{"ok":true}'); }
  if (ruta === '/salud') { res.writeHead(200, { 'content-type': 'application/json' }); return res.end(JSON.stringify({ estado: 'ok', corriendo, ultima: ultima?.fin ?? null })); }
  if (ruta.startsWith('/reporte')) return estatico(res, join(PRUEBAS, 'playwright-report'), ruta.replace(/^\/reporte\/?/, ''));
  if (ruta.startsWith('/trazas')) return estatico(res, join(PRUEBAS, 'test-results'), ruta.replace(/^\/trazas\/?/, ''));
  if (ruta === '' || ruta === '/' || ruta === '/index.html') { res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' }); return res.end(PAGINA); }
  res.writeHead(404, { 'content-type': 'text/plain' }); res.end('No encontrado');
}).listen(PUERTO, HOST, () => console.log(`Robot de pruebas en http://localhost:${PUERTO}  · motor ${MOTOR} · cada ${CADA_MS / 60_000} min`));

correr('arranque');
setInterval(() => { if (Date.now() >= proxima) correr('programada'); }, 15_000);
for (const senal of ['SIGINT', 'SIGTERM']) process.on(senal, () => process.exit(0));
