# Resultados medidos por motor

Medido el **1 de noviembre de 2026, ~01:00 (Lima)** al preparar el kit, en una Mac con Apple Silicon
(arm64), macOS 15, Node 24.2, Docker Desktop 28.1, **Playwright 1.64.1**. Misma suite, misma app,
`workers: 1`. Son números de UNA máquina: en tu laptop serán otros. Lo que importa es la
**comparación** y **por qué** falla cada cosa.

## Versiones probadas

| Motor | Cómo se levantó | Versión | Imagen |
|---|---|---|---|
| Chromium | Playwright lo lanza (`chromium.launch`, headless) | chromium-1248 de Playwright 1.64.1 | — |
| Lightpanda | `docker compose up -d lightpanda` → `ws://127.0.0.1:9222` | Lightpanda 1.0.2 (`lightpanda/browser:latest`, arm64) | 59 MB |
| Obscura | `docker compose up -d obscura` → `ws://127.0.0.1:9223` | Obscura 0.2.6 (`h4ckf0r0day/obscura:latest`, arm64) | 102 MB |

Las dos imágenes existen para **arm64** y **amd64**: corren en Mac con chip M y en PC.

## Suite E2E (14 pruebas; Chromium 15 con la visual)

| Motor | App corregida (`BUGS=0`) | Con defectos (`BUGS=1`) | Tiempo de la suite* (BUGS=0) | RAM del navegador en el pico** |
|---|---|---|---|---|
| Chromium | **15/15 pasan** (incluye la visual) | 12 pasan · **3 fallan** (VEN-001, 002, 003) | 4,5 s | ~335 MiB (suma de procesos) |
| Lightpanda | **14/14 pasan** (visual excluida) | 11 pasan · **3 fallan** (las mismas) | **2,2 s** | **~14–24 MiB** |
| Obscura | 13 pasan · **1 falla** (VEN-003, falso rojo) | 11 pasan · 3 fallan | 9,7 s (5 s son la espera de la prueba fallida) | ~26–28 MiB |

\* Tiempo que informa Playwright, sin contar el arranque de la app. Con `BUGS=1` todas las suites
tardan ~19–21 s porque cada prueba roja espera 5 s (`expect.timeout`) antes de rendirse.

\** Chromium: suma del RSS de sus procesos con `ps` (sobreestima porque cuenta memoria
compartida). Lightpanda y Obscura: `docker stats --no-stream` del contenedor, muestreado cada
0,5 s. En reposo: Lightpanda 3–9 MiB, Obscura 5–16 MiB.

Las pruebas de API (8) no usan navegador: 8/8 pasan en ~0,1 s en total.

## Lo que encontramos (y es lo más valioso para el taller)

1. **Lightpanda 1.0.2: todo lo funcional pasa.** Login, búsqueda, carrito, cobro, reporte.
   No dibuja la página, así que **no hay capturas**: el proyecto `lightpanda` excluye `@visual`
   y tiene `screenshot: 'off'`. Las **trazas sí se graban** (probado con `--trace on`).

2. **Obscura 0.2.6 tenía tres diferencias con Chromium.** Dos se resolvieron cambiando la app y
   una se dejó a propósito como ejemplo:
   - **No soporta `form.usuario`** (acceso a un campo por su nombre). El login fallaba en
     silencio y **13 de 14 pruebas salían rojas**. Se cambió a `document.getElementById(...)`.
   - **Da caja 0×0 a los `<a>` en línea**, así que Playwright los cree invisibles y no les hace
     clic. Se puso `display: inline-block` en los enlaces del menú.
   - **No dispara el evento `change`** al sacar el foco de un campo (ni con `blur()` ni con Tab).
     Por eso **E2E-VEN-003 sale rojo en Obscura aunque la app esté bien**. Con `BUGS=1` también
     sale rojo, pero el mensaje es otro: Obscura muestra `Received: "S/ 17.01"` (no recalculó) y
     Chromium/Lightpanda muestran `Received: "S/ 30.62"` (descuento doble). **El mismo rojo,
     otra causa: hay que leer el `Received`.**
   - Además: Obscura **bloquea las IP privadas** por defecto (protección SSRF), y la app está en
     `host.docker.internal`, que es una IP privada. En el compose va `OBSCURA_ALLOW_PRIVATE_NETWORK=1`.
   - Obscura **revisa que la cabecera `Host` coincida con su puerto** y exige una ficha (token) de
     32 caracteres o más si escucha fuera de loopback. Por eso en el compose escucha en 9223
     también dentro del contenedor, y Playwright le manda `Authorization: Bearer …`.

3. **Los tres motores encuentran los dos defectos de la app**, porque las pruebas usan
   `getByRole`/`getByLabel`, que Playwright resuelve con su propio JavaScript dentro de la página
   y no dependen del árbol de accesibilidad del motor.

## Cómo repetir las mediciones

```bash
cd motores && docker compose up -d          # Lightpanda en 9222, Obscura en 9223
cd ../pruebas
npm run test:chromium
npm run test:lightpanda
npm run test:obscura
# RAM de los motores mientras corren (en otra terminal):
docker stats --no-stream taller-lightpanda taller-obscura
```

## Monitoreo (también medido)

| Contenedor | RAM en reposo |
|---|---|
| Prometheus 3.15.1 | ~37 MiB |
| blackbox_exporter 0.29.1 | ~29 MiB |
| Grafana 13.3.0 | ~300 MiB |

Prueba de caída real: `POST /api/caos {"caida":true}` a las 06:01:17 UTC →
`probe_success` llegó a 0 en el siguiente sondeo → la alerta «Tienda Sol caída» llegó al webhook
a las 06:02:50 (**~93 s**: 1 min de `for` + sondeo de 15 s + evaluación de 10 s + `group_wait` de 10 s).
Al recuperarla llegó «RESUELTA» ~57 s después.

## Lo que NO se verificó

- Windows y Linux: el kit se probó solo en macOS arm64. Los comandos de Windows del README siguen la
  documentación, pero no se ejecutaron en Windows.
- Los binarios nativos de Lightpanda y Obscura (sin Docker): solo se usaron las imágenes Docker.
- Lightpanda **no tiene binario para Windows** (según su README): en Windows, Docker Desktop o WSL2.
