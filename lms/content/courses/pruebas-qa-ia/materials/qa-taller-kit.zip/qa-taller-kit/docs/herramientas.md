# Mapa de herramientas de pruebas (noviembre 2026)

Tabla corta y honesta. «Cuándo sí» es la razón para elegirla; «cuándo no», la razón para buscar otra.
En el taller usamos **Playwright** + **Lightpanda/Obscura** + **Grafana/Prometheus**; lo demás
es para que sepas qué existe.

## Automatizar el navegador (E2E)

| Herramienta | Qué es | Cuándo sí | Cuándo no |
|---|---|---|---|
| **Playwright** | Framework de pruebas E2E de Microsoft (JS/TS, Python, Java, .NET). Chromium, Firefox y WebKit. | Opción por defecto hoy: espera automática, trazas, reporte HTML, pruebas de API, `codegen`, agentes. | Si tu equipo ya tiene una suite grande y estable en otra herramienta. |
| **Puppeteer** | Librería de Google para manejar Chrome/Firefox por CDP o WebDriver BiDi. | Scripts y raspado (scraping) con Chrome; generar PDF; tareas sueltas. | Como framework de pruebas: no trae runner, reportes ni fixtures. |
| **Selenium / WebDriver BiDi** | El estándar W3C de automatización. BiDi es la versión nueva, bidireccional (eventos, consola, red). | Muchos lenguajes, grillas (Selenium Grid), navegadores reales en la nube, equipos con suites Java. | Proyectos nuevos en JS que quieren arrancar rápido. |
| **Cypress** | Runner E2E que corre dentro del navegador. Muy buena experiencia local. | Apps de front con muchos componentes; depurar viendo la app «en vivo». | Varias pestañas o dominios, Safari real, paralelismo sin pagar su nube. |
| **WebdriverIO** | Framework Node sobre WebDriver/BiDi (y Appium para móvil). | Web **y móvil** con la misma API; ecosistema de servicios. | Si solo necesitas web: Playwright es más directo. |
| **Vitest browser mode** | Corre pruebas unitarias o de componentes en un navegador real (usa Playwright o WebdriverIO por debajo). | Probar componentes React/Vue/Svelte en un DOM real, rápido. | Flujos completos de usuario (eso es E2E). |

## Navegadores sin interfaz alternativos

| Herramienta | Qué es | Cuándo sí | Cuándo no |
|---|---|---|---|
| **Lightpanda** | Navegador sin interfaz escrito en Zig, sin motor gráfico. Habla CDP. | Mucho volumen con poca RAM: agentes, raspado, pruebas funcionales en CI. En nuestra suite: todo pasa con ~20 MiB. | Pruebas visuales o capturas; webs que dependen de APIs que aún no implementa. No tiene binario para Windows. |
| **Obscura** | Navegador sin interfaz en Rust con V8. Habla CDP; trae modo «stealth» y servidor MCP. | Agentes y raspado ligeros; probar compatibilidad. | Pruebas donde importan los eventos finos del DOM: en la 0.2.6 encontramos 3 diferencias con Chromium (ver `motores-resultados.md`). |

## IA y agentes

| Herramienta | Qué es | Cuándo sí | Cuándo no |
|---|---|---|---|
| **Playwright MCP** (`npx @playwright/mcp@latest`) | Servidor MCP que deja que un asistente de IA maneje un navegador (lee el árbol de accesibilidad, hace clic, escribe). | Explorar una app con la IA, que escriba pruebas mirando la página real, reproducir un error. | Como reemplazo de la suite: la IA explora, la suite **verifica** siempre igual. |
| **Agentes de Playwright** (`npx playwright init-agents`) | Tres agentes: *planner* (plan de pruebas), *generator* (escribe specs), *healer* (repara pruebas rotas). | Arrancar cobertura en una app sin pruebas; mantener selectores. | Sin revisar lo que generan: una prueba que pasa no siempre prueba lo correcto. |
| **Stagehand** | Librería (Browserbase) que mezcla código Playwright con acciones en lenguaje natural (`act`, `extract`). | Flujos que cambian mucho o webs de terceros. | Pruebas deterministas de tu propia app (cada corrida puede decidir distinto). |
| **browser-use** | Agente en Python que navega solo a partir de una instrucción. | Tareas exploratorias, RPA, demos. | Pruebas de regresión: no es determinista y cuesta tokens. |

## Datos, carga, entorno y reportes

| Herramienta | Qué es | Cuándo sí | Cuándo no |
|---|---|---|---|
| **k6** | Pruebas de carga y rendimiento con scripts JS (Grafana Labs). | ¿Aguanta 200 cajeros a la vez? Umbrales de latencia en CI. | Pruebas funcionales de pantalla. |
| **Faker** (`@faker-js/faker`) | Genera datos falsos realistas (nombres, DNI, direcciones). | Llenar formularios y semillas grandes. **Siempre con semilla fija** (`faker.seed(123)`). | Sin semilla: datos distintos en cada corrida = pruebas inestables. |
| **Testcontainers** | Levanta contenedores desechables (Postgres, Redis…) desde el código de la prueba. | Pruebas de integración con una base real y limpia en cada corrida. | Si no hay Docker en la máquina o en el CI. |
| **Allure Report** | Reporte de pruebas con historial, categorías y adjuntos; tiene reporter para Playwright. | Varios equipos o suites que quieren un reporte común con historia. | Equipos chicos: el reporte HTML de Playwright + nuestro portal alcanzan. |

## Monitoreo en producción

| Herramienta | Qué es | Cuándo sí | Cuándo no |
|---|---|---|---|
| **Prometheus + blackbox_exporter** | Prometheus guarda métricas; blackbox sondea URLs «desde afuera» (HTTP, TCP, ICMP). | Disponibilidad y latencia con historia, consultas (PromQL) y alertas. | Si no quieres mantener servidores: usa un servicio administrado. |
| **Grafana** | Tableros y alertas sobre Prometheus (y muchas otras fuentes). | Ver estado, disponibilidad % y avisar por webhook, correo, Telegram, Slack… | Para una sola URL sin historia: es mucho para tan poco. |
| **Uptime Kuma** | Monitor de disponibilidad autoalojado con interfaz web, muy fácil. | Un panel «arriba/caído» en 5 minutos, con avisos a Telegram/WhatsApp (vía integraciones) y página de estado. | Métricas detalladas o consultas propias. |
| **monitoreo/vigia.mjs** (de este kit) | 80 líneas de Node: sondea, calcula disponibilidad, avisa por webhook. | Entender la idea sin Docker. | Producción real. |
