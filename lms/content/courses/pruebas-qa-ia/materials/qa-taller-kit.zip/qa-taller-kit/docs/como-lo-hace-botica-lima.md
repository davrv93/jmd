# Así lo hace una botica real: el caso se reproduce solo y la batería corre en segundo plano

Lo que sigue está sacado del código de producción de un sistema de facturación para boticas
(Lima, 2026), con los nombres de clientes quitados. Es la versión «de verdad» de lo que hiciste
en el taller con Tienda Sol: grabación con consentimiento, reproducción paso a paso, spec
generado y el robot con su página de estado. Aquí lo mismo, pero con cajeras cobrando mientras
corre.

## 1. El mapa

```
 Cajera (POS en el navegador)                       Panel «Pruebas» (solo administradores)
 ┌───────────────────────────────┐                  ┌─────────────────────────────────────┐
 │ Se rompe una pantalla          │                  │ ▶ Preparar y correr matriz          │
 │ ViewErrorBoundary:             │                  │   motor: Lightpanda (rápido)        │
 │ «No se pudo abrir esta         │                  │ Casos por módulo ● ok ● falla ● pend│
 │  sección» + Detalle para       │                  │ Cada caso con ▶ → QaPlayback        │
 │  soporte: <error>              │                  └──────────────┬──────────────────────┘
 └───────────────────────────────┘                                  │ POST /qa/run {engine}
                                                                     ▼
                                                     Backend (Laravel, contenedor SIN Chrome)
                                                     deja storage/app/qa/matriz.job → 202
                                                     GET /qa/run/progress · /qa/run/stream (SSE 45 s)
                                                                     │
                                       cron cada minuto + flock      ▼
                                    qa-matriz.sh (en el HOST, tiene Chrome, node y Lightpanda)
                                    1 siembra botica-qa  2 copia specs del canon  3 corre runner.mjs
                                    4 php artisan qa:import report.json
                                    estado en matriz.estado.json: seed → run → import → done | error
```

Tres ideas que lo sostienen:

1. **El panel no ejecuta nada.** Deja un fichero de trabajo y vuelve a mirar. El backend es un
   contenedor sin navegador; lo que tiene navegador es el host.
2. **La traza no se escribe en los specs.** `e2e/lib/sesion.mjs` envuelve el `page` y anota un
   paso por cada `goto`, `click`, `type`, `waitForSelector` o comprobación: `{tipo: ir|click|input|
   campo|espera|ver|api, selector|texto, valor}`. Lo que un spec hace con `page.evaluate` no se
   traza, porque es cómputo, no una acción de usuario. Por eso la traza es «honesta, no exhaustiva».
3. **Un pendiente nunca se muestra como correcto.** El reporte distingue `ok`, `falla`, `error`,
   `pendiente` (sin escribir), `no_ejecutado` (la corrida no llegó) y `defecto_conocido` (rojo
   que ya se sabe, para que la matriz no quede roja para siempre y el rojo nuevo se vea).

## 2. El modal que reproduce el caso (QaPlayback)

Cada caso de la matriz que trae `pasos` muestra un botón ▶. Al pulsarlo:

- Se abre un modal grande con la **aplicación real dentro de un iframe del mismo origen**: comparte
  la sesión del administrador que mira el panel, así que se puede abrir sobre una empresa con datos
  reales.
- A la derecha, la lista de pasos del caso: 🧭 Ir a la vista · ⏳ Esperar · 👆 Pulsar «Cobrar» ·
  ⌨️ Escribir «5» en #efectivo · 🔌 POST /api/sales · 🔎 Comprobar «Efectivo insuficiente».
- Al avanzar (automático cada 1,1 s, o con ‹ ›), el modal **navega el iframe a la vista del paso y
  señala el elemento exacto** con un anillo y un cursor virtual con onda. Busca por selector y, si
  no, por el texto más corto que lo contiene.
- **No pulsa ni escribe.** Señala. Es una reproducción visual, no una ejecución: así puede usarse
  sobre producción sin tocar nada. Si no ubica el elemento (otro rol, otros datos, layout cambiado)
  lo dice: «No se pudo ubicar el elemento en esta pantalla», en vez de fingir.
- Debajo, las comprobaciones del caso con ✓ y ✗ y el detalle de la que falló.

Cuando algo se rompe en una pantalla, `ViewErrorBoundary` atrapa el error de render o de carga del
chunk, deja el menú usable, ofrece «Recargar» (limpia el service worker y las cachés antes, porque
una cajera quedó atascada recargando contra la misma caché) y muestra **«Detalle para soporte»**
con el mensaje del error. Soporte toma ese detalle, busca el caso de la matriz que cubre esa
pantalla y lo reproduce con ▶. Con lo que armaste en el taller (grabador con consentimiento +
`/reproducir`), ese «detalle» se convierte en la sesión completa del usuario: semilla, acciones y
la petición que falló.

## 3. La batería en segundo plano, y el cerco que la hace terminar siempre

El 18-09-2026 la matriz completa, con Chrome, llevó la carga de una máquina de 2 vCPU a 16: el DNS
interno de Docker dejó de responder, la web devolvió 502 a clientes reales y el SSH se cayó varios
minutos **con la botica cobrando**. De ahí salió la regla: que haya casos en rojo es aceptable; que
la corrida se cuelgue o tumbe la venta, no. Se cerca con cinco topes:

| Tope | Dónde | Valor | Qué evita |
|---|---|---|---|
| Memoria | `docker run --memory` | 400 MB | comerse la RAM de la venta |
| CPU | `docker run --cpus` | 1 | repetir la carga 16 |
| Carga previa | `/proc/loadavg` antes de arrancar | no arranca por encima de 4,0 | lanzar cuando la máquina ya no tiene aire |
| Tiempo por spec | `QA_SPEC_TIMEOUT_MS` en `runner.mjs` | 120 s con Lightpanda (180 s por defecto) | un spec colgado en el login se lleva la corrida |
| Tiempo total | `timeout -k 30` + `docker rm -f` pase lo que pase | 30 min | una corrida que no termina nunca |

Peor caso aritmético: 14 specs × 120 s = 28 min, dentro de los 30. Caso normal medido en el EC2:
**8 min 39 s** la matriz completa con Lightpanda y **1 min 20 s** la tanda rápida.

**El reporte se escribe spec a spec.** Antes se escribía al final. Si el tope global mataba la corrida
con diez specs hechos, no había reporte y el vigilante decía «el runner no dejó reporte»: diez specs
corridos y el panel vacío. Ahora cada spec que termina reescribe `report.json`, los que no llegaron
salen como `no_ejecutado` y el reporte lleva `completo: false`. Lo que corrió, queda; lo que no,
se dice. Se probó en negativo: un spec que duerme 10 minutos con tope de 20 s sale como `error`
y el reporte existe. Sin esa prueba, el cerco es una promesa.

**El panel mira sin estorbar.** `GET /qa/run/stream` manda el avance por SSE, pero cierra a los
45 s a propósito: cada conexión retiene un worker de PHP-FPM y hay cinco; dos pestañas abiertas
diez minutos dejaron sin workers al backend el 20-09-2026. El panel reconecta en bucle y, si el
flujo no abre en 8 s, cae al sondeo de `/qa/run/progress` cada 2,5 s. Un `flock` por instancia
impide dos corridas a la vez y el POST devuelve 409 si ya hay una.

**El 200 que afirma algo falso.** El fallo típico del motor nuevo no fue un 500: fue un `200` con una
lista vacía, un `null` clavado a mano, una bandera en `false`. Como no es error, nadie lo rebota y
nadie se entera. Por eso la matriz comprueba valores, no códigos: «el total es S/ 29.50», no «la
respuesta fue 200». Ante una pantalla vacía con datos en la base, sospecha de eso antes que de la
consulta.

## 4. Cómo lo llevas a Tienda Sol, paso a paso

Ya tienes del taller: consentimiento + grabación (`app/publico/js/grabador.js`), reproducción
(`/reproducir.html`), spec generado (`reproducir-<id>.spec.ts`) y el robot con su página de
estado (`robot/robot.mjs`). La versión de producción añade:

1. **Modal al error, no solo al consentimiento.** Captura `window.onerror`, `unhandledrejection` y
   toda respuesta ≥ 400. Cuando pase, muestra tu propio diálogo (nunca `alert`): «Ocurrió un error.
   ¿Enviar la grabación para que soporte lo reproduzca?» con la lista exacta de lo que va: ruta,
   sucursal, semilla, acciones, petición fallida. Sin «Sí», no se envía nada.
2. **Ticket con reproducción.** El `POST /api/sesiones` crea un ticket: id, hora, usuario, error,
   enlace a `/reproducir.html?id=…` y el spec generado adjunto. Soporte abre el ticket, mira la
   reproducción y corre el spec: rojo en la app con el bug, verde cuando lo arreglan.
3. **El spec entra a la matriz.** Guarda `reproducir-<id>.spec.ts` en `pruebas/specs/` y una fila en
   `docs/matriz.csv` con el ID del ticket. El bug del usuario pasa a ser un caso permanente: si
   vuelve, la matriz lo dice antes que el usuario.
4. **La batería corre en segundo plano.** Tu `robot/robot.mjs` ya corre la suite cada N minutos.
   Ponle el cerco: `--memory=400m --cpus=1` al contenedor, no arrancar con `os.loadavg()[0] > 4`,
   `timeout` por spec en `playwright.config.ts` y un `timeout` global al proceso. Y que escriba el
   historial **después de cada spec** (el reporter JSON de Playwright escribe al final: guarda
   también un `parcial.json` desde un reporter propio o corre spec a spec).
5. **El panel.** Un botón «Correr ahora» que encola (devuelve 202), un estado `encolado → corriendo
   → importando → listo | error` que el robot escribe en un fichero y la página lee cada 2,5 s, y el
   botón ▶ en cada caso rojo que abre `/reproducir.html` con la traza de esa corrida. Si ya hay una
   corrida, el botón se acopla a ella en vez de lanzar otra.
6. **Un pendiente nunca se muestra como correcto.** Pinta `no_ejecutado` en gris, no en verde, y
   añade `defecto_conocido` para los rojos que ya se saben, con su motivo escrito.

Referencias en el repo de la botica: `frontend/src/components/QaPlayback.jsx`,
`frontend/src/components/ViewErrorBoundary.jsx`, `frontend/src/views/TestResultsView.jsx`,
`frontend/e2e/lib/sesion.mjs`, `frontend/qa/runner.mjs`, `despliegue/qa-matriz.sh`,
`laravel/app/Http/Controllers/Api/QaController.php`, `PLAN_TRABAJO_MATRIZ_LIGHTPANDA_EC2.md`.
