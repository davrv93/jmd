# La «semilla frontend»: reproducir exactamente lo que vio el usuario

Un usuario te escribe: «me cobró mal». Con eso no puedes hacer nada. Lo que necesitas es poder
**volver a su pantalla, paso a paso**, y convertir eso en una prueba que falle hoy y pase cuando lo
arregles. A eso le llamamos la semilla frontend.

## Qué es

La **semilla frontend** es todo lo que hace falta para repetir una sesión tal cual ocurrió:

| Parte | Qué guarda Tienda Sol | Para qué sirve |
|---|---|---|
| Punto de partida | URL inicial, tamaño de pantalla, idioma, hora, versión de la app | Arrancar la prueba en las mismas condiciones |
| Acciones en orden | cada clic (con su localizador accesible: `button «Confirmar venta»`), cada valor escrito, cada navegación | Los pasos del spec, con `getByRole` / `getByLabel` |
| Lo que vio | la pantalla (DOM con los valores escritos) antes de cada clic, los avisos (`role=alert` / `role=status`) | Reproducción visual y el `expect` |
| Lo que pasó por debajo | peticiones al servidor con su estado y un resumen del cuerpo, errores de JavaScript | Ver que el POST envió `efectivo: 17.01` cuando la persona escribió 5 |

Flujo completo: **usuario acepta → grabación → QA la reproduce en `/reproducir.html` → genera
`reproducir-<id>.spec.ts` → la prueba sale en rojo → se corrige → sale en verde → queda en la suite
para siempre.** Es la diferencia entre «no puedo reproducirlo» y un caso de prueba real.

## Por qué el consentimiento informado (Ley 29733)

Grabar una sesión es tratar datos personales. En Perú, la Ley 29733 de Protección de Datos
Personales exige que la persona sepa **qué** se recoge, **para qué**, **cuánto tiempo** y **cómo
revocarlo**, y que lo acepte de forma libre e informada. Por eso Tienda Sol:

1. **Pregunta antes de grabar** (ventana «¿Nos ayudas a reproducir errores?»), con texto claro y dos
   opciones reales: «Sí, grabar esta sesión» / «No, gracias». Si no acepta, no se graba nada.
2. **Dice exactamente qué se guarda** (clics, lo escrito en el POS, pantallas, avisos, peticiones
   fallidas, errores de JavaScript) y qué **no** (la clave se guarda como «•••»).
3. **Dice la finalidad** (reproducir y corregir errores) y **el plazo** (24 h en memoria).
4. **Permite revocar** en cualquier momento con el botón «Dejar de grabar» del encabezado.
5. Guarda la elección en el navegador de la persona para no volver a preguntar.

A un navegador automatizado (Playwright, codegen) no se le pregunta: `navigator.webdriver` es
`true` y no hay persona que consienta. Así tus pruebas no ven el aviso.

## Qué NO se graba nunca

- **Contraseñas** (campos `type=password`): se enmascaran antes de salir del navegador.
- **Datos de tarjetas, DNI, direcciones** y cualquier dato que no haga falta para reproducir el
  error. Si tu app los pide, enmascáralos en `grabador.js` igual que la clave.
- El cuerpo de `POST /api/login`.

Regla: graba **acciones y pantallas**, no identidades. Si dudas, no lo grabes.

## Cómo se usa en el taller

```bash
cd app && node servidor.mjs --modo=prueba        # la tienda
# abre http://localhost:3000, acepta grabar, haz la venta de S/ 5
# abre http://localhost:3000/reproducir.html → elige la sesión → «Generar prueba Playwright»
# copia el archivo descargado a pruebas/specs/ y:
cd pruebas && npx playwright test specs/reproducir-*.spec.ts --project=chromium      # rojo: reproduce el bug
BUGS=0 npx playwright test specs/reproducir-*.spec.ts --project=chromium             # verde: con la app corregida
```

En la tienda web del taller (`https://jmd-learn.online/tienda-sol/`) funciona igual, dentro de tu
código: `…/tienda-sol/<código>/reproducir.html`. Para correr el spec contra la web usa
`BASE_URL=https://jmd-learn.online/tienda-sol/<código>/`.

En una app real, `/reproducir.html` y `/api/sesiones` van **detrás del login de QA**: solo el equipo
de calidad ve las grabaciones. Aquí están abiertos porque cada alumno tiene su propia tienda.
