# Verificación de la versión del taller

1 de noviembre de 2026, macOS arm64. Playwright 1.64.1; Chrome del sistema con `CANAL=chrome`.

| Corrida | Con bugs | Corregida |
|---|---|---|
| Chromium + API local, incluida visual | 20 pasan / 3 fallan | 23 pasan |
| Chromium + API multialumno local, incluida visual | 20 pasan / 3 fallan | 23 pasan |
| Lightpanda, sin visual | 11 pasan / 3 fallan | 14 pasan, 2.3 s |
| Obscura, sin visual | 11 pasan / 3 fallan | 13 pasan / 1 falla, 9.9 s |

Los fallos de negocio son VEN-001, VEN-002 y VEN-003. Obscura conserva el falso rojo documentado: no dispara change al perder el foco. No se cambió ni se omitió esa aserción. Las mediciones anteriores de RAM están en motores-resultados.md; en esta corrida no se volvió a medir memoria pico.

Se comprobaron también: dos visitantes con tokens, ventas, caos y semilla independientes; modo por tienda; rechazo de códigos inexistentes; límite de capacidad; expiración con TTL reducido para la prueba. El TTL normal es 30 minutos.

El monitoreo real local disparó «Tienda Sol caída» y el receptor recibió DISPARADA a las 2:12 a. m. y RESUELTA a las 2:13 a. m., hora de Lima. No se envió ningún mensaje externo.

Las 14 escenas se verificaron con el comprobador estático y una prueba de interacción bajo CSP/sandbox del LMS. Se capturaron a 1366×768 y 1920×1080 con Chrome; no hubo recursos externos, errores de JavaScript ni desbordes de la escena. Las réplicas usan desplazamiento interno en el catálogo, reporte y terminal.

No verificado: Windows, Linux ni binarios nativos de los motores. La comparación visual se prepara en cada equipo. Las escenas reproducen un subconjunto didáctico de las herramientas, no sustituyen sus funciones completas.

Las escenas no hacen llamadas de IA. No se comprobó un perfil Claude/GPT habilitado en el gateway; no se cambió su configuración ni Robo.
