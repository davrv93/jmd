# Claude Code — pruebas de Tienda Sol

Las reglas del proyecto están en AGENTS.md (mismo contenido para todos los asistentes):

@AGENTS.md
