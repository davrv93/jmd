"""Reto 1 · Pedirle tus datos a la API de JMD Learning SIN iniciar sesión.

Resultado esperado: 401 «inicia sesión» en cada ruta. La API no entrega nada sin una sesión válida.
Solo usa la biblioteca estándar de Python: no instalas nada.

    python3 01_jmd_sin_login.py
"""
import json
import time
import urllib.error
import urllib.request

API = "https://jmd-learn.online/api/v1"
UA = "TallerScrapingJMD/1.0 (alumno; tu-correo@ejemplo.com)"  # un bot educado dice quién es

for ruta in ["/me", "/courses", "/grades"]:
    pedido = urllib.request.Request(API + ruta, headers={"User-Agent": UA, "Accept": "application/json"})
    try:
        with urllib.request.urlopen(pedido, timeout=20) as r:
            print(f"GET {ruta:10} → {r.status}  (¿sin sesión y te respondió? revisa)")
    except urllib.error.HTTPError as e:
        cuerpo = json.loads(e.read() or b"{}")
        mensaje = cuerpo.get("error", {}).get("message", "")
        print(f"GET {ruta:10} → {e.code}  {mensaje}")
    time.sleep(1)  # pausa de 1 s entre pedidos, aunque falle

print("\nSin cookie ni token la API no te conoce: por eso responde 401.")
