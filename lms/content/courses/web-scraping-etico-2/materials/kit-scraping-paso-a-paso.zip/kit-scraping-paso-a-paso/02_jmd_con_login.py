"""Reto 2 · Iniciar sesión en la API de JMD Learning y descargar TUS datos.

1. POST /auth/login con tu correo y contraseña → la API devuelve un token.
2. Con ese token en la cabecera  Authorization: Bearer …  pides /me, /courses, cada curso, tu avance y tus notas.
3. Guarda todo en  mis_datos_jmd.json  y la lista de sesiones en  mis_sesiones.csv.

Solo usa la biblioteca estándar de Python: no instalas nada. La contraseña se escribe oculta (getpass).

    python3 02_jmd_con_login.py
    JMD_EMAIL=tu-correo@ejemplo.com python3 02_jmd_con_login.py     # para no escribir el correo cada vez
"""
import csv
import getpass
import json
import os
import time
import urllib.error
import urllib.request

API = "https://jmd-learn.online/api/v1"
UA = "TallerScrapingJMD/1.0 (alumno; tu-correo@ejemplo.com)"
PAUSA = 1.0  # segundos entre pedidos: no apures al servidor


def pedir(ruta, token=None, datos=None):
    cabeceras = {"User-Agent": UA, "Accept": "application/json"}
    if token:
        cabeceras["Authorization"] = "Bearer " + token
    cuerpo = None
    if datos is not None:
        cuerpo = json.dumps(datos).encode()
        cabeceras["Content-Type"] = "application/json"
    pedido = urllib.request.Request(API + ruta, data=cuerpo, headers=cabeceras)
    with urllib.request.urlopen(pedido, timeout=30) as r:
        time.sleep(PAUSA)
        return json.loads(r.read())


email = os.environ.get("JMD_EMAIL") or input("Correo de JMD Learning: ").strip()
clave = os.environ.get("JMD_PASS") or getpass.getpass("Contraseña (no se ve al escribir): ")

try:
    sesion = pedir("/auth/login", datos={"email": email, "password": clave})
except urllib.error.HTTPError as e:
    print("No se pudo iniciar sesión:", e.code, json.loads(e.read() or b"{}").get("error", {}).get("message", ""))
    raise SystemExit(1)
token = sesion["token"]
print("Sesión iniciada. Token recibido:", token[:6] + "…" + f" ({len(token)} caracteres)")

yo = pedir("/me", token)
cursos = pedir("/courses", token)
lista = cursos if isinstance(cursos, list) else cursos.get("courses", [])
print(f"Hola, {yo.get('name', '¿?')}. Tienes {len(lista)} curso(s).")

datos = {"yo": yo, "cursos": [], "notas": None}
filas = []
for c in lista:
    cid = c.get("id") or c.get("slug")
    detalle = pedir(f"/courses/{cid}", token)
    try:
        avance = pedir(f"/courses/{cid}/progress", token)
    except urllib.error.HTTPError:
        avance = None
    datos["cursos"].append({"curso": detalle, "avance": avance})
    for m in detalle.get("modules", []):
        for s in m.get("lessons", []):
            filas.append({"curso": detalle.get("title", cid), "modulo": m.get("title", ""),
                          "sesion": s.get("title", ""), "fecha": s.get("starts_at") or ""})
    print(f"  · {detalle.get('title', cid)}: {sum(len(m.get('lessons', [])) for m in detalle.get('modules', []))} sesiones")

try:
    datos["notas"] = pedir("/grades", token)
except urllib.error.HTTPError as e:
    print("Notas no disponibles:", e.code)

with open("mis_datos_jmd.json", "w", encoding="utf-8") as f:
    json.dump(datos, f, ensure_ascii=False, indent=2)
with open("mis_sesiones.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=["curso", "modulo", "sesion", "fecha"])
    w.writeheader()
    w.writerows(filas)
print(f"\nListo: mis_datos_jmd.json y mis_sesiones.csv ({len(filas)} sesiones).")
