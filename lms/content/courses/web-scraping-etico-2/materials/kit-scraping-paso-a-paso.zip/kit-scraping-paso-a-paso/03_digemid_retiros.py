"""Retos 3 y 4 · Retiros del mercado de DIGEMID (datos públicos) desde tu PC y desde un servidor.

DIGEMID publica sus alertas en un WordPress con la API REST abierta: JSON paginado, sin iniciar sesión.
Este script busca «retiro del mercado», recorre todas las páginas y guarda  retiros_digemid.csv  y  .json.

- Desde tu PC (internet de casa o del celular): responde 200 y descarga todo.
- Desde un servidor en la nube (AWS, como el EC2 del curso): responde 403 con «error code: 1005».
  Es Cloudflare bloqueando toda la red de AWS (por ASN). No es un captcha: ningún truco de cabeceras lo pasa,
  y saltarse un bloqueo así no es ético. La salida correcta es correrlo desde donde sí te dejan o pedir acceso.

    python3 03_digemid_retiros.py
"""
import csv
import html
import json
import re
import time
import urllib.error
import urllib.request

URL = "https://www.digemid.minsa.gob.pe/webDigemid/wp-json/wp/v2/posts"
# Con un User-Agent de navegador; con el de Python a secas, Cloudflare también te bloquea.
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Safari/537.36"
PAUSA = 2.0  # sitio del Estado: más despacio todavía


def limpiar(texto):
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", html.unescape(texto))).strip()


filas, pagina, paginas = [], 1, 1
while pagina <= paginas:
    consulta = f"{URL}?search=retiro%20del%20mercado&per_page=100&page={pagina}&_fields=id,date,title,link,excerpt"
    pedido = urllib.request.Request(consulta, headers={"User-Agent": UA, "Accept": "application/json"})
    try:
        with urllib.request.urlopen(pedido, timeout=30) as r:
            paginas = int(r.headers.get("X-WP-TotalPages", "1"))
            total = r.headers.get("X-WP-Total")
            lote = json.loads(r.read())
    except urllib.error.HTTPError as e:
        cuerpo = e.read()[:2000].decode("utf-8", "replace").strip()
        try:  # Cloudflare responde un JSON con «title» y «detail» si pediste JSON
            j = json.loads(cuerpo)
            cuerpo = f"{j.get('title', '')} · {j.get('detail', '')[:90]}"
        except ValueError:
            cuerpo = cuerpo[:120]
        print(f"Página {pagina} → {e.code}  {cuerpo}")
        if e.code == 403 and "1005" in cuerpo:
            print("Bloqueo de Cloudflare a la red de este servidor (ASN). Corre el script desde tu PC.")
        raise SystemExit(1)
    print(f"Página {pagina} de {paginas} → 200  ({len(lote)} registros; total {total})")
    for p in lote:
        filas.append({"fecha": p["date"][:10], "titulo": limpiar(p["title"]["rendered"]),
                      "producto": limpiar(p["excerpt"]["rendered"])[:200], "enlace": p["link"]})
    pagina += 1
    time.sleep(PAUSA)

with open("retiros_digemid.json", "w", encoding="utf-8") as f:
    json.dump(filas, f, ensure_ascii=False, indent=2)
with open("retiros_digemid.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=["fecha", "titulo", "producto", "enlace"])
    w.writeheader()
    w.writerows(filas)
print(f"\nListo: {len(filas)} registros en retiros_digemid.csv y retiros_digemid.json")
