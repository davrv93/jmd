// ==UserScript==
// @name         JMD Learning · descargar mis datos
// @namespace    https://jmd-learn.online/
// @version      1.0
// @description  Agrega un botón en jmd-learn.online que descarga tus cursos, sesiones, avance y notas (JSON y CSV) usando tu propia sesión.
// @author       Taller «Web scraping ético con IA» · JMD Learning
// @match        https://jmd-learn.online/*
// @grant        none
// @run-at       document-idle
// ==/UserScript==
(function () {
  "use strict";
  if (window.top !== window.self || document.getElementById("jmd-mis-datos")) return; // solo una vez, no en iframes

  var PAUSA_MS = 800; // entre pedidos, como una persona que mira
  var esperar = function (ms) { return new Promise(function (ok) { setTimeout(ok, ms); }); };

  // 1. El botón flotante y un panel para los mensajes
  var caja = document.createElement("div");
  caja.id = "jmd-mis-datos";
  caja.style.cssText = "position:fixed;right:16px;bottom:16px;z-index:99999;font:14px system-ui,sans-serif;" +
    "background:#fff;color:#17191c;border:1px solid #d3d6d2;border-radius:12px;padding:10px 12px;" +
    "box-shadow:0 8px 24px rgba(0,0,0,.15);max-width:300px";
  caja.innerHTML = '<button id="jmd-bajar" style="background:#17191c;color:#fff;border:0;border-radius:8px;' +
    'padding:8px 12px;font:600 13px system-ui;cursor:pointer">Descargar mis datos</button>' +
    '<div id="jmd-estado" style="margin-top:6px;color:#646a66;font-size:12.5px"></div>';
  document.body.appendChild(caja);
  var estado = function (t) { document.getElementById("jmd-estado").textContent = t; };

  // 2. Pedir a la API con la cookie de tu sesión (mismo sitio: credentials "include")
  async function api(ruta) {
    var r = await fetch("/api/v1" + ruta, { credentials: "include", headers: { Accept: "application/json" } });
    await esperar(PAUSA_MS);
    if (!r.ok) { var e = new Error("HTTP " + r.status); e.status = r.status; throw e; }
    return r.json();
  }

  function descargar(nombre, contenido, tipo) {
    var a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([contenido], { type: tipo }));
    a.download = nombre;
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 2000);
  }

  function csv(filas) {
    var cols = ["curso", "modulo", "sesion", "fecha"];
    var celda = function (v) { return '"' + String(v == null ? "" : v).replace(/"/g, '""') + '"'; };
    return "﻿" + [cols.join(",")].concat(filas.map(function (f) { return cols.map(function (c) { return celda(f[c]); }).join(","); })).join("\n");
  }

  // 3. Recorrer: yo → mis cursos → cada curso (sesiones y avance) → notas
  document.getElementById("jmd-bajar").addEventListener("click", async function () {
    var boton = this;
    boton.disabled = true;
    try {
      estado("Revisando tu sesión…");
      var yo = await api("/me");
      var cursos = await api("/courses");
      var lista = Array.isArray(cursos) ? cursos : (cursos.courses || []);
      var datos = { yo: yo, cursos: [], notas: null, descargado: new Date().toISOString() };
      var filas = [];
      for (var i = 0; i < lista.length; i++) {
        var id = lista[i].id || lista[i].slug;
        estado("Curso " + (i + 1) + " de " + lista.length + "…");
        var detalle = await api("/courses/" + id);
        var avance = null;
        try { avance = await api("/courses/" + id + "/progress"); } catch (e) { /* sin avance: seguimos */ }
        datos.cursos.push({ curso: detalle, avance: avance });
        (detalle.modules || []).forEach(function (m) {
          (m.lessons || []).forEach(function (s) {
            filas.push({ curso: detalle.title, modulo: m.title, sesion: s.title, fecha: s.starts_at || "" });
          });
        });
      }
      try { datos.notas = await api("/grades"); } catch (e) { /* sin notas: seguimos */ }
      descargar("mis_datos_jmd.json", JSON.stringify(datos, null, 2), "application/json");
      descargar("mis_sesiones.csv", csv(filas), "text/csv");
      estado("Listo: " + lista.length + " curso(s) y " + filas.length + " sesiones descargadas.");
    } catch (e) {
      estado(e.status === 401 ? "Primero inicia sesión en JMD Learning (la API respondió 401)." : "No se pudo: " + e.message);
    } finally {
      boton.disabled = false;
    }
  });
})();
