# Kit · Editor de video con Claude (Claude Code PRO, sesión 4)

Material para programar con Claude Code un editor de video sencillo, renderizarlo con
HyperFrames y probarlo. Aquí **no** está el código del editor: lo construyes tú con Claude
durante la clase.

## Qué trae

| Archivo | Qué es |
|---|---|
| `imagenes/sierra.jpg`, `imagenes/mar.jpg`, `imagenes/campo.jpg` | Tres ilustraciones de 1920 × 1080 |
| `musica/suave.mp3` | Una música suave de 30 segundos |
| `proyecto-ejemplo.json` | Un video de 15 s ya armado: muestra cómo se guarda la línea de tiempo |

Las imágenes y la música se hicieron con código para este curso. Puedes usarlas, cambiarlas
y compartirlas sin pedir permiso. Si prefieres, usa tus propias fotos y tu propia música.

## Lo que necesitas

- Claude Code con tu plan Pro.
- Node.js 22 o superior.
- FFmpeg (Mac: `brew install ffmpeg` · Windows: `winget install Gyan.FFmpeg`).
- Google Chrome.

Compruébalo con `npx hyperframes doctor`: Node.js, FFmpeg y FFprobe deben salir con ✓.

## El formato de `proyecto-ejemplo.json`

```json
{
  "titulo": "Tres paisajes",
  "ancho": 1920, "alto": 1080, "fps": 30,
  "clips": [
    { "id": "foto-1", "tipo": "imagen", "archivo": "imagenes/sierra.jpg", "inicio": 0, "duracion": 5 },
    { "id": "texto-1", "tipo": "texto", "texto": "Amanece en la sierra", "inicio": 0.5, "duracion": 4 },
    { "id": "musica-1", "tipo": "musica", "archivo": "musica/suave.mp3", "inicio": 0, "duracion": 15, "volumen": 0.7 }
  ]
}
```

- `tipo` es `imagen`, `texto` o `musica`.
- `inicio` y `duracion` van en segundos.
- El video dura hasta donde termina el último clip.

## Los pasos de la clase

1. Prepara la carpeta (en la terminal, dentro de esta carpeta):

   ```
   npx hyperframes init video --non-interactive
   claude
   ```

   Crea la carpeta `video` (el proyecto de HyperFrames) e instala en Claude Code los manuales
   (skills) de HyperFrames.

2. Pide a Claude **un plan** antes del código y apruébalo con tus cambios.
3. Pide el editor **pieza por pieza**: línea de tiempo y vista previa (`editor.html` y `lib.js`),
   agregar y guardar, y `exportar.js`.
4. Exporta, revisa y renderiza:

   ```
   node exportar.js proyecto.json video
   npx hyperframes check video
   npx hyperframes render video --quality draft -o salida/mi-video.mp4
   ```

5. Mira los cuadros:

   ```
   npx hyperframes snapshot video --at 2,7,12 -o cuadros
   ffmpeg -ss 7 -i salida/mi-video.mp4 -frames:v 1 cuadros/mp4-7s.png
   ```

6. QA y pruebas: pide a Claude los casos de QA en `QA.md`, pruébalos y luego las pruebas
   automáticas. Se corren con:

   ```
   node --test
   ```

Para la entrega final, renderiza sin `--quality draft`.

## Documentación

- HyperFrames: https://hyperframes.heygen.com/quickstart
- Código de HyperFrames (Apache 2.0): https://github.com/heygen-com/hyperframes
- Probador de Node (`node --test`): https://nodejs.org/api/test.html
